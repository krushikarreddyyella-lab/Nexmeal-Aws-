import React, { useState, useEffect, useRef } from 'react';
import { 
  UtensilsCrossed, 
  Menu,
  X,
  ChevronDown,
  ShieldAlert,
  Building2,
  Truck,
  Cpu,
  Code2,
} from 'lucide-react';
import { UserProfile } from '../types';
import { NexmealLogo } from './NexmealLogo';

interface Props {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  reviewCount: number;
  currentUser?: UserProfile;
  onOpenDonateModal: () => void;
  onOpenRoleSwitcher?: () => void;
  onOpenDeveloperModal?: () => void;
}

export const Navbar: React.FC<Props> = ({ 
  activeTab, 
  setActiveTab, 
  reviewCount,
  onOpenDonateModal,
  onOpenDeveloperModal,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [operationsOpen, setOperationsOpen] = useState(false);
  const operationsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 8);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Click outside listener for Operations dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (operationsRef.current && !operationsRef.current.contains(event.target as Node)) {
        setOperationsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileMenuOpen]);

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'discover', label: 'Discover' },
    { id: 'donor', label: 'For Donors' },
    { id: 'ngo', label: 'For NGOs' },
    { id: 'matches', label: 'AI Matching' },
    { id: 'impact', label: 'Impact' },
  ];

  const secondaryLinks = [
    { id: 'reviews', label: 'Review Queue', badge: reviewCount, icon: ShieldAlert },
    { id: 'recipients', label: 'NGO Directory', icon: Building2 },
    { id: 'pickups', label: 'Pickup Tracker', icon: Truck },
    { id: 'eval', label: 'Evaluation & Benchmarks', icon: Cpu },
  ];

  return (
    <>
      <header
        className={`sticky top-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#FAFAF6]/90 backdrop-blur-xl border-b border-stone-200/80 shadow-subtle'
            : 'bg-[#FAFAF6] border-b border-stone-200/60'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo & Brand Wordmark */}
            <div
              className="cursor-pointer group py-1"
              onClick={() => setActiveTab('home')}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === 'Enter' && setActiveTab('home')}
            >
              <NexmealLogo size="md" tagline={true} />
            </div>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center space-x-1" aria-label="Main Navigation">
              {navLinks.map((item) => {
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      setOperationsOpen(false);
                    }}
                    className={`relative px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-200 ${
                      isActive
                        ? 'text-[#103B2D] bg-[#E4F4EE]'
                        : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100/70'
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}

              {/* Accessible Interactive Operations Menu (Click & Hover enabled) */}
              <div 
                ref={operationsRef}
                className="relative"
                onMouseEnter={() => setOperationsOpen(true)}
                onMouseLeave={() => setOperationsOpen(false)}
              >
                <button
                  type="button"
                  onClick={() => setOperationsOpen((prev) => !prev)}
                  aria-expanded={operationsOpen}
                  aria-haspopup="true"
                  className={`px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                    operationsOpen || secondaryLinks.some((l) => l.id === activeTab)
                      ? 'text-[#103B2D] bg-[#E4F4EE]'
                      : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100/70'
                  }`}
                >
                  <span>Operations</span>
                  <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${operationsOpen ? 'rotate-180 text-[#103B2D]' : 'opacity-60'}`} />
                  {reviewCount > 0 && (
                    <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse ml-0.5" />
                  )}
                </button>

                {/* Dropdown Menu with instant click response and accessibility */}
                {operationsOpen && (
                  <div className="absolute top-full left-0 mt-1 w-64 p-2 rounded-2xl bg-white shadow-elevated border border-stone-200 z-50 animate-scale-in">
                    <div className="px-3 py-1.5 text-[10px] uppercase font-bold text-stone-400 tracking-wider border-b border-stone-100 mb-1">
                      Operations & Dispatch
                    </div>
                    {secondaryLinks.map((sub) => {
                      const IconComponent = sub.icon;
                      return (
                        <button
                          key={sub.id}
                          type="button"
                          onClick={() => {
                            setActiveTab(sub.id);
                            setOperationsOpen(false);
                          }}
                          className={`w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                            activeTab === sub.id
                              ? 'bg-[#E4F4EE] text-[#103B2D] font-bold'
                              : 'text-stone-700 hover:bg-stone-100/80 hover:text-stone-900'
                          }`}
                        >
                          <div className="flex items-center gap-2.5">
                            <IconComponent className="w-4 h-4 text-emerald-800 shrink-0" />
                            <span>{sub.label}</span>
                          </div>
                          {sub.badge && sub.badge > 0 ? (
                            <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-white">
                              {sub.badge}
                            </span>
                          ) : null}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            </nav>

            {/* Right Side: Primary Actions */}
            <div className="hidden sm:flex items-center gap-2.5">
              {/* Primary Donate CTA */}
              <button
                onClick={onOpenDonateModal}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#103B2D] hover:bg-[#0B261D] text-white text-xs font-bold shadow-card transition-all duration-200 hover:-translate-y-0.5 cursor-pointer"
              >
                <UtensilsCrossed className="w-3.5 h-3.5 text-emerald-300" />
                <span>Donate Surplus</span>
              </button>

              {/* About Developer Button (Placed on the right side of Donate Surplus as requested) */}
              {onOpenDeveloperModal && (
                <button
                  type="button"
                  onClick={onOpenDeveloperModal}
                  className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-white border border-stone-200/90 hover:border-emerald-300 text-stone-700 hover:text-[#103B2D] text-xs font-bold transition-all shadow-2xs hover:bg-[#E4F4EE]/50 cursor-pointer"
                  title="About Developer: KRUSHIKAR REDDY YELLA"
                >
                  <Code2 className="w-3.5 h-3.5 text-emerald-700" />
                  <span>About Developer</span>
                </button>
              )}
            </div>

            {/* Mobile Hamburger Button */}
            <div className="flex items-center gap-2 lg:hidden">
              {onOpenDeveloperModal && (
                <button
                  onClick={onOpenDeveloperModal}
                  className="px-2.5 py-1.5 rounded-xl bg-white border border-stone-200 text-stone-800 text-xs font-bold flex items-center gap-1"
                >
                  <Code2 className="w-3.5 h-3.5 text-emerald-700" />
                  <span className="hidden xs:inline">Developer</span>
                </button>
              )}
              <button
                onClick={onOpenDonateModal}
                className="px-3.5 py-1.5 rounded-xl bg-[#103B2D] text-white text-xs font-bold"
              >
                Donate
              </button>
              <button
                onClick={() => setMobileMenuOpen(true)}
                className="p-2.5 rounded-xl text-stone-700 hover:bg-stone-200/60 transition-colors"
                aria-label="Open mobile menu"
              >
                <Menu className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          {/* Backdrop */}
          <div 
            className="fixed inset-0 bg-stone-900/60 backdrop-blur-sm animate-fade-in"
            onClick={() => setMobileMenuOpen(false)}
          />

          {/* Drawer Panel */}
          <div className="fixed inset-y-0 right-0 max-w-xs w-full bg-[#FAFAF6] shadow-elevated p-6 flex flex-col justify-between overflow-y-auto animate-slide-up">
            <div className="space-y-6">
              {/* Drawer Header */}
              <div className="flex items-center justify-between pb-4 border-b border-stone-200">
                <NexmealLogo size="sm" tagline={false} />
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-2 rounded-xl text-stone-500 hover:bg-stone-200"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Main Links */}
              <div className="space-y-1">
                <span className="text-[10px] uppercase font-bold text-stone-400 px-3 block mb-1">Navigation</span>
                {navLinks.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full text-left px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-colors ${
                      activeTab === item.id
                        ? 'bg-[#103B2D] text-white'
                        : 'text-stone-700 hover:bg-stone-200/50'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              {/* Operations & Dispatch Links (Direct Mobile Access) */}
              <div className="space-y-1 pt-3 border-t border-stone-200">
                <span className="text-[10px] uppercase font-bold text-stone-400 px-3 block mb-1">Operations & Dispatch</span>
                {secondaryLinks.map((item) => {
                  const IconComponent = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setActiveTab(item.id);
                        setMobileMenuOpen(false);
                      }}
                      className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-semibold flex items-center justify-between ${
                        activeTab === item.id
                          ? 'bg-[#E4F4EE] text-[#103B2D] font-bold'
                          : 'text-stone-700 hover:bg-stone-200/50'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <IconComponent className="w-4 h-4 text-emerald-800 shrink-0" />
                        <span>{item.label}</span>
                      </div>
                      {item.badge && item.badge > 0 ? (
                        <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-white">
                          {item.badge}
                        </span>
                      ) : null}
                    </button>
                  );
                })}
              </div>

              {/* About Developer Button in Mobile Drawer */}
              {onOpenDeveloperModal && (
                <div className="pt-3 border-t border-stone-200">
                  <button
                    type="button"
                    onClick={() => {
                      setMobileMenuOpen(false);
                      onOpenDeveloperModal();
                    }}
                    className="w-full py-2.5 px-3 rounded-xl bg-white border border-stone-200 text-stone-800 text-xs font-bold flex items-center justify-between hover:bg-stone-50"
                  >
                    <div className="flex items-center gap-2">
                      <Code2 className="w-4 h-4 text-emerald-700" />
                      <span>About Developer</span>
                    </div>
                    <span className="text-[10px] text-stone-500 font-mono">KRUSHIKAR YELLA</span>
                  </button>
                </div>
              )}
            </div>

            {/* Drawer Footer CTA */}
            <div className="pt-6 border-t border-stone-200">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenDonateModal();
                }}
                className="w-full py-3.5 rounded-2xl bg-[#103B2D] text-white text-xs font-bold shadow-card flex items-center justify-center gap-2"
              >
                <UtensilsCrossed className="w-4 h-4 text-emerald-300" />
                <span>Register Surplus Food</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
