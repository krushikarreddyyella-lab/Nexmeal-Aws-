import React from 'react';

interface NexmealLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showWordmark?: boolean;
  tagline?: boolean;
  variant?: 'light' | 'dark' | 'monochrome';
}

export const NexmealLogo: React.FC<NexmealLogoProps> = ({
  className = '',
  size = 'md',
  showWordmark = true,
  tagline = false,
  variant = 'light',
}) => {
  const iconSizeMap = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-12 h-12',
    xl: 'w-16 h-16',
  };

  const wordmarkSizeMap = {
    sm: 'text-lg',
    md: 'text-xl',
    lg: 'text-2xl',
    xl: 'text-3xl',
  };

  const isDark = variant === 'dark';

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Refined Minimalist Vessel & Grain Logo Mark */}
      <div
        className={`relative ${iconSizeMap[size]} rounded-2xl flex items-center justify-center transition-transform duration-300 group-hover:scale-105 shrink-0 shadow-sm ${
          isDark
            ? 'bg-gradient-to-br from-[#103B2D] via-[#164E3D] to-[#0D2E23] border border-[#2D6A4F]/40'
            : 'bg-gradient-to-br from-[#103B2D] via-[#164E3D] to-[#0A261D] border border-emerald-800/30'
        }`}
      >
        <svg
          viewBox="0 0 36 36"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-3/5 h-3/5"
          aria-hidden="true"
        >
          <defs>
            {/* Champagne Gold Gradient */}
            <linearGradient id="nexmealGold" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#F5D77F" />
              <stop offset="100%" stopColor="#C5A059" />
            </linearGradient>
            {/* Forest Mint Gradient */}
            <linearGradient id="nexmealMint" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#A7F3D0" />
              <stop offset="100%" stopColor="#34D399" />
            </linearGradient>
          </defs>

          {/* Upward Sustenance Grain / Leaf Leaflet (Left) */}
          <path
            d="M18 5C16 8.5 14 11.5 14 14C14 16.2 15.8 18 18 18C18 13 18 8 18 5Z"
            fill="url(#nexmealMint)"
          />

          {/* Upward Sustenance Grain / Leaf Leaflet (Right - Champagne Gold Accent) */}
          <path
            d="M18 5C20 8.5 22 11.5 22 14C22 16.2 20.2 18 18 18C18 13 18 8 18 5Z"
            fill="url(#nexmealGold)"
          />

          {/* Nourishment Vessel / Bowl Silhouette (Deep Curved Vessel) */}
          <path
            d="M6 18.5C6 24.85 11.37 30 18 30C24.63 30 30 24.85 30 18.5H6Z"
            fill="#FAFAF6"
            fillOpacity="0.96"
          />

          {/* Subtle Bowl Base Ring / Pedestal */}
          <path
            d="M12 30.5H24"
            stroke="url(#nexmealGold)"
            strokeWidth="1.75"
            strokeLinecap="round"
          />

          {/* Circular Flow Arc (Connecting nourishment to rescue loop) */}
          <path
            d="M8.5 16C9.8 12.5 13.5 10 18 10"
            stroke="url(#nexmealMint)"
            strokeWidth="1.25"
            strokeLinecap="round"
            strokeDasharray="1.5 2.5"
          />
        </svg>
      </div>

      {/* Wordmark and Optional Tagline */}
      {showWordmark && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5 leading-none">
            <span
              className={`font-display font-extrabold tracking-tight ${wordmarkSizeMap[size]} ${
                isDark ? 'text-white' : 'text-[#17211C]'
              }`}
            >
              Nexmeal
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#C5A059]" />
          </div>
          {tagline && (
            <span
              className={`text-[11px] font-medium tracking-normal mt-1 ${
                isDark ? 'text-stone-400' : 'text-stone-500'
              }`}
            >
              Surplus today. Sustenance tomorrow.
            </span>
          )}
        </div>
      )}
    </div>
  );
};
