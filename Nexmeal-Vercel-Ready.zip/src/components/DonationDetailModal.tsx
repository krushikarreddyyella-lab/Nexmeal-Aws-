import React from 'react';
import { 
  X, 
  MapPin, 
  Clock, 
  Truck, 
  Sparkles, 
  ShieldCheck, 
  Thermometer, 
  Calendar, 
  Building2, 
  Phone,
  CheckCircle,
  AlertTriangle
} from 'lucide-react';
import { Donation } from '../types';
import { StatusBadge } from './StatusBadge';

interface Props {
  donation: Donation | null;
  onClose: () => void;
  onMatch: (donationId: string) => void;
  onTrackPickup?: (donationId: string) => void;
  onConfirmHandover?: (donationId: string) => void;
}

export const DonationDetailModal: React.FC<Props> = ({
  donation,
  onClose,
  onMatch,
  onTrackPickup,
  onConfirmHandover,
}) => {
  if (!donation) return null;

  const hoursRemaining = Math.max(
    0,
    (new Date(donation.pickup_deadline).getTime() - new Date().getTime()) / (3600 * 1000)
  );

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
      <div 
        className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-elevated border border-stone-200/80 my-8 transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Image Header */}
        <div className="relative h-64 sm:h-72 w-full bg-stone-100 overflow-hidden">
          <img
            src={donation.image_url || 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=1200&q=80'}
            alt={donation.food_title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
          
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2.5 rounded-full bg-black/40 hover:bg-black/60 text-white backdrop-blur-md transition-all border border-white/20"
            title="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="absolute bottom-4 left-4 right-4 text-white">
            <div className="flex items-center gap-2 mb-1.5 flex-wrap">
              <StatusBadge status={donation.status} />
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-white/20 backdrop-blur-md border border-white/20">
                {donation.food_category}
              </span>
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-500/80 backdrop-blur-md">
                {donation.dietary_type}
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold font-display text-white drop-shadow-sm leading-tight">
              {donation.food_title}
            </h2>
          </div>
        </div>

        {/* Modal Content */}
        <div className="p-6 sm:p-8 space-y-6 max-h-[calc(85vh-18rem)] overflow-y-auto">
          {/* Quick Stat Highlights */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-[#FAFAF6] p-3.5 rounded-2xl border border-stone-200/70 text-center">
              <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider block">Quantity</span>
              <span className="text-lg font-bold font-display text-[#103B2D]">
                {donation.quantity_value} {donation.quantity_unit}
              </span>
            </div>
            <div className="bg-[#FAFAF6] p-3.5 rounded-2xl border border-stone-200/70 text-center">
              <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider block">Window Left</span>
              <span className={`text-lg font-bold font-display ${hoursRemaining < 1.5 ? 'text-amber-600' : 'text-stone-800'}`}>
                {hoursRemaining > 0 ? `${hoursRemaining.toFixed(1)} hrs` : 'Expired'}
              </span>
            </div>
            <div className="bg-[#FAFAF6] p-3.5 rounded-2xl border border-stone-200/70 text-center">
              <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider block">Storage</span>
              <span className="text-xs font-bold font-mono text-stone-800 mt-1 block">
                {donation.storage_requirement.replace('_', ' ')}
              </span>
            </div>
            <div className="bg-[#FAFAF6] p-3.5 rounded-2xl border border-stone-200/70 text-center">
              <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider block">Handover OTP</span>
              <span className="text-base font-bold font-mono text-emerald-700 block tracking-wider">
                {donation.pickup_verification_code || 'Pending'}
              </span>
            </div>
          </div>

          {/* Donor & Facility Card */}
          <div className="bg-[#FAFAF6] p-5 rounded-2xl border border-stone-200/80 space-y-3">
            <div className="flex items-center justify-between border-b border-stone-200/60 pb-2.5">
              <div className="flex items-center gap-2.5">
                <Building2 className="w-5 h-5 text-emerald-700" />
                <div>
                  <h3 className="text-sm font-bold text-stone-900">{donation.donor_name}</h3>
                  <span className="text-xs text-stone-500">{donation.donor_type} • Verified Food Facility</span>
                </div>
              </div>
              <span className="text-xs font-mono text-stone-400">ID: {donation.id}</span>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-stone-600 pt-1">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-stone-400 shrink-0 mt-0.5" />
                <span>{donation.donor_address}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-stone-400 shrink-0" />
                <span>{donation.donor_contact}</span>
              </div>
            </div>
          </div>

          {/* Safety & Chain of Custody */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-500 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              Safety & Handling Protocols
            </h4>
            
            <div className="bg-white p-4 rounded-2xl border border-stone-200 text-xs text-stone-600 space-y-2">
              <p className="leading-relaxed">
                <strong className="text-stone-800">Handling Advisory: </strong>
                {donation.handling_instructions || 'Store and transport in accordance with standard food safety temperature control guidelines.'}
              </p>
              <div className="flex items-center gap-4 text-[11px] text-stone-500 pt-2 border-t border-stone-100 flex-wrap">
                <span>Prepared: <strong>{new Date(donation.preparation_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</strong></span>
                <span>•</span>
                <span>Deadline: <strong>{new Date(donation.pickup_deadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</strong></span>
                <span>•</span>
                <span className="text-emerald-700 font-medium">Deterministic Safety Gate: Validated</span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Actions Footer */}
        <div className="p-5 sm:p-6 bg-stone-50/80 border-t border-stone-200 flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl border border-stone-300 text-stone-700 text-xs font-semibold hover:bg-stone-100 transition-colors"
          >
            Close
          </button>

          <div className="flex items-center gap-2">
            {donation.status === 'PROPOSED' && (
              <button
                onClick={() => {
                  onClose();
                  onMatch(donation.id);
                }}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#103B2D] to-[#164E3D] hover:from-[#0B261D] hover:to-[#103B2D] text-white text-xs font-bold shadow-sm transition-all hover:shadow-md"
              >
                <Sparkles className="w-4 h-4 text-emerald-400" />
                Launch Strands AI Matching
              </button>
            )}

            {donation.status === 'ACCEPTED' && onTrackPickup && (
              <button
                onClick={() => {
                  onClose();
                  onTrackPickup(donation.id);
                }}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-sm transition-all"
              >
                <Truck className="w-4 h-4" />
                Track Courier Pickup
              </button>
            )}

            {donation.status === 'IN_TRANSIT' && onConfirmHandover && (
              <button
                onClick={() => {
                  onClose();
                  onConfirmHandover(donation.id);
                }}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm transition-all"
              >
                <CheckCircle className="w-4 h-4" />
                Confirm OTP Handover
              </button>
            )}

            {donation.status === 'COLLECTED' && (
              <span className="flex items-center gap-1.5 text-xs font-semibold text-emerald-800 bg-emerald-100 px-3.5 py-2 rounded-xl">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                Collection Completed & Impact Logged
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
