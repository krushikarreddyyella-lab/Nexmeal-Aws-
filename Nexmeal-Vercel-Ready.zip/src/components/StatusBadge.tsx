import React from 'react';
import { DonationStatus } from '../types';
import { Check, Truck, Clock, AlertCircle, XCircle } from 'lucide-react';

interface Props {
  status: DonationStatus | string;
}

export const StatusBadge: React.FC<Props> = ({ status }) => {
  const normStatus = (status || '').toUpperCase();

  switch (normStatus) {
    case 'COLLECTED':
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-green-50 text-green-700 ring-1 ring-green-200 shadow-2xs">
          <Check className="w-3 h-3 text-green-600 stroke-[2.5]" />
          <span>COLLECTED</span>
        </span>
      );

    case 'IN_TRANSIT':
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 ring-1 ring-amber-200 shadow-2xs animate-pulse">
          <Truck className="w-3 h-3 text-amber-600" />
          <span>IN TRANSIT</span>
        </span>
      );

    case 'ACCEPTED':
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200 shadow-2xs">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
          <span>ACCEPTED</span>
        </span>
      );

    case 'MATCHED':
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 ring-1 ring-indigo-200 shadow-2xs">
          <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
          <span>MATCHED</span>
        </span>
      );

    case 'PROPOSED':
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 ring-1 ring-blue-200 shadow-2xs">
          <Clock className="w-3 h-3 text-blue-500" />
          <span>PROPOSED</span>
        </span>
      );

    case 'REJECTED':
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-red-50 text-red-700 ring-1 ring-red-200 shadow-2xs">
          <XCircle className="w-3 h-3 text-red-500" />
          <span>REJECTED</span>
        </span>
      );

    case 'CANCELLED':
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-500 ring-1 ring-gray-200 line-through">
          <span>CANCELLED</span>
        </span>
      );

    case 'EXPIRED':
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-500 ring-1 ring-gray-200">
          <AlertCircle className="w-3 h-3 text-gray-400" />
          <span>EXPIRED</span>
        </span>
      );

    default:
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-stone-100 text-stone-700 ring-1 ring-stone-200">
          <span className="w-1.5 h-1.5 rounded-full bg-stone-400" />
          <span>{status.replace(/_/g, ' ')}</span>
        </span>
      );
  }
};
