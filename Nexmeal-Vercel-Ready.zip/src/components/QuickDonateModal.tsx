import React, { useState } from 'react';
import { 
  X, 
  UtensilsCrossed, 
  Building2, 
  MapPin, 
  Clock, 
  Calendar, 
  Sparkles, 
  CheckCircle, 
  AlertCircle,
  Thermometer,
  ShieldCheck,
  Copy,
  Check
} from 'lucide-react';
import { Donation } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Partial<Donation>) => Promise<Donation>;
  onSuccessNavigate: (donationId: string) => void;
}

export const QuickDonateModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onSubmit,
  onSuccessNavigate,
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [created, setCreated] = useState<Donation | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);

  const defaultPrepTime = new Date().toISOString().slice(0, 16);
  const defaultDeadline = new Date(Date.now() + 4 * 3600 * 1000).toISOString().slice(0, 16);

  const [form, setForm] = useState({
    donor_name: 'The Royal Palace Banquet',
    donor_type: 'Wedding/Event',
    donor_contact: '+91 99000 11111',
    donor_address: 'Palace Grounds Gate 4, Bellary Road, Bangalore',
    latitude: 12.998,
    longitude: 77.592,
    food_title: '',
    food_category: 'Cooked Meals',
    quantity_value: '25',
    quantity_unit: 'kg',
    storage_requirement: 'ROOM_TEMP',
    dietary_type: 'VEGETARIAN',
    preparation_time: defaultPrepTime,
    pickup_deadline: defaultDeadline,
    handling_instructions: 'Packaged in clean food-grade stainless vessels. Keep warm.',
  });

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.food_title.trim()) {
      setError('Please provide a title for the surplus food.');
      return;
    }
    if (!form.quantity_value || Number(form.quantity_value) <= 0) {
      setError('Please provide a valid quantity.');
      return;
    }

    setError(null);
    setLoading(true);

    try {
      const res = await onSubmit({
        ...form,
        quantity_value: Number(form.quantity_value),
        preparation_time: new Date(form.preparation_time).toISOString(),
        pickup_deadline: new Date(form.pickup_deadline).toISOString(),
      });
      setCreated(res);
    } catch (err: any) {
      setError(err?.message || 'Failed to register surplus food.');
    } finally {
      setLoading(false);
    }
  };

  const handleCopyCode = () => {
    if (created?.pickup_verification_code) {
      navigator.clipboard.writeText(created.pickup_verification_code);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    }
  };

  const handleResetAndClose = () => {
    setCreated(null);
    setError(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
      <div 
        className="bg-white rounded-3xl max-w-xl w-full overflow-hidden shadow-elevated border border-stone-200 my-8 transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 border-b border-stone-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <UtensilsCrossed className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold font-display text-stone-900">Register Surplus Food Batch</h3>
              <p className="text-xs text-stone-500">Fast 60-second dispatch registration</p>
            </div>
          </div>
          <button 
            onClick={handleResetAndClose} 
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {created ? (
          /* Success Screen */
          <div className="p-8 space-y-6 text-center animate-scale-in">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
              <CheckCircle className="w-8 h-8" />
            </div>

            <div className="space-y-1.5">
              <h4 className="text-xl font-bold font-display text-stone-900">
                Surplus Batch Successfully Registered!
              </h4>
              <p className="text-xs text-stone-500">
                "{created.food_title}" ({created.quantity_value} {created.quantity_unit}) is ready for AI matching.
              </p>
            </div>

            {/* Handover OTP Box */}
            <div className="bg-[#FAFAF6] p-5 rounded-2xl border border-stone-200 text-center space-y-2">
              <span className="text-[10px] uppercase font-bold text-stone-400 tracking-wider block">
                Pickup Handover Verification Code
              </span>
              <div className="flex items-center justify-center gap-3">
                <span className="text-3xl font-mono font-bold tracking-widest text-[#103B2D]">
                  {created.pickup_verification_code}
                </span>
                <button
                  onClick={handleCopyCode}
                  className="p-2 rounded-xl border border-stone-200 bg-white hover:bg-stone-50 text-stone-600"
                  title="Copy Code"
                >
                  {copiedCode ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-[11px] text-stone-400">
                Share this code with the authorized courier or NGO driver at pickup.
              </p>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={handleResetAndClose}
                className="flex-1 py-3 rounded-xl border border-stone-300 text-stone-700 text-xs font-semibold hover:bg-stone-50"
              >
                Close
              </button>
              <button
                onClick={() => {
                  const id = created.id;
                  handleResetAndClose();
                  onSuccessNavigate(id);
                }}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-[#103B2D] to-[#164E3D] text-white text-xs font-bold shadow-sm flex items-center justify-center gap-1.5"
              >
                <Sparkles className="w-4 h-4 text-emerald-300" />
                <span>Launch AI Matching</span>
              </button>
            </div>
          </div>
        ) : (
          /* Input Form */
          <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
            {error && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Food Title */}
            <div>
              <label className="text-xs font-bold text-stone-700 block mb-1">
                Food Title / Description *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Fresh North Indian Dinner Surplus (Pulao, Dal, Sabzi)"
                value={form.food_title}
                onChange={(e) => setForm({ ...form, food_title: e.target.value })}
                className="w-full text-xs py-2.5 px-3.5 rounded-xl border border-stone-300 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none"
              />
            </div>

            {/* Category & Quantity Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">Category</label>
                <select
                  value={form.food_category}
                  onChange={(e) => setForm({ ...form, food_category: e.target.value })}
                  className="w-full text-xs py-2.5 px-3 rounded-xl border border-stone-300 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none bg-white cursor-pointer"
                >
                  <option value="Cooked Meals">Cooked Meals</option>
                  <option value="Bakery">Bakery & Breads</option>
                  <option value="Produce">Fresh Produce</option>
                  <option value="Dairy">Dairy & Pastries</option>
                  <option value="Packaged">Packaged Goods</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">Quantity</label>
                <input
                  type="number"
                  min="1"
                  step="0.5"
                  required
                  value={form.quantity_value}
                  onChange={(e) => setForm({ ...form, quantity_value: e.target.value })}
                  className="w-full text-xs py-2.5 px-3.5 rounded-xl border border-stone-300 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">Unit</label>
                <select
                  value={form.quantity_unit}
                  onChange={(e) => setForm({ ...form, quantity_unit: e.target.value })}
                  className="w-full text-xs py-2.5 px-3 rounded-xl border border-stone-300 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none bg-white cursor-pointer"
                >
                  <option value="kg">kg (kilograms)</option>
                  <option value="servings">servings</option>
                  <option value="trays">trays</option>
                  <option value="boxes">boxes</option>
                </select>
              </div>
            </div>

            {/* Storage & Dietary */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">Storage Condition</label>
                <select
                  value={form.storage_requirement}
                  onChange={(e) => setForm({ ...form, storage_requirement: e.target.value })}
                  className="w-full text-xs py-2.5 px-3 rounded-xl border border-stone-300 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none bg-white cursor-pointer"
                >
                  <option value="ROOM_TEMP">Room Temp (20-25°C)</option>
                  <option value="HOT_HOLDING">Hot Holding (&gt;60°C)</option>
                  <option value="REFRIGERATED">Refrigerated (2-4°C)</option>
                  <option value="FROZEN">Deep Frozen (&lt;-18°C)</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">Dietary Classification</label>
                <select
                  value={form.dietary_type}
                  onChange={(e) => setForm({ ...form, dietary_type: e.target.value })}
                  className="w-full text-xs py-2.5 px-3 rounded-xl border border-stone-300 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none bg-white cursor-pointer"
                >
                  <option value="VEGETARIAN">Vegetarian</option>
                  <option value="NON_VEGETARIAN">Non-Vegetarian</option>
                  <option value="VEGAN">100% Vegan</option>
                </select>
              </div>
            </div>

            {/* Timing: Prep and Deadline */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">Preparation Time</label>
                <input
                  type="datetime-local"
                  required
                  value={form.preparation_time}
                  onChange={(e) => setForm({ ...form, preparation_time: e.target.value })}
                  className="w-full text-xs py-2.5 px-3 rounded-xl border border-stone-300 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">Safe Pickup Deadline *</label>
                <input
                  type="datetime-local"
                  required
                  value={form.pickup_deadline}
                  onChange={(e) => setForm({ ...form, pickup_deadline: e.target.value })}
                  className="w-full text-xs py-2.5 px-3 rounded-xl border border-stone-300 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none"
                />
              </div>
            </div>

            {/* Donor Entity Info */}
            <div className="bg-[#FAFAF6] p-3.5 rounded-2xl border border-stone-200/80 space-y-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-stone-500 block">
                Donor Facility Particulars
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <input
                  type="text"
                  placeholder="Facility / Restaurant Name"
                  value={form.donor_name}
                  onChange={(e) => setForm({ ...form, donor_name: e.target.value })}
                  className="bg-white py-2 px-3 rounded-xl border border-stone-300"
                />
                <input
                  type="text"
                  placeholder="Contact Phone"
                  value={form.donor_contact}
                  onChange={(e) => setForm({ ...form, donor_contact: e.target.value })}
                  className="bg-white py-2 px-3 rounded-xl border border-stone-300"
                />
              </div>
              <input
                type="text"
                placeholder="Pickup Address / Gate Number"
                value={form.donor_address}
                onChange={(e) => setForm({ ...form, donor_address: e.target.value })}
                className="w-full bg-white py-2 px-3 rounded-xl border border-stone-300 text-xs"
              />
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={handleResetAndClose}
                disabled={loading}
                className="flex-1 py-3 rounded-xl border border-stone-300 text-stone-700 text-xs font-semibold hover:bg-stone-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-[#103B2D] to-[#164E3D] hover:from-[#0B261D] hover:to-[#103B2D] text-white text-xs font-bold shadow-sm transition-all disabled:opacity-50"
              >
                {loading ? 'Registering...' : 'Register Surplus Lot'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
