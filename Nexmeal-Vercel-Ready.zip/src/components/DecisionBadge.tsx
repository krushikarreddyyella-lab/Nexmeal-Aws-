import React from 'react';
import { DeciderDecision } from '../types';
import { ShieldCheck, AlertTriangle, XCircle } from 'lucide-react';

interface Props {
  decision: DeciderDecision | string;
  confidence?: number;
}

export const DecisionBadge: React.FC<Props> = ({ decision, confidence }) => {
  const normDecision = (decision || '').toUpperCase();
  const pct = confidence !== undefined
    ? Math.round(confidence <= 1 ? confidence * 100 : confidence)
    : undefined;

  if (normDecision === 'APPROVE') {
    return (
      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-xs shadow-emerald-600/20">
        <ShieldCheck className="w-3.5 h-3.5 stroke-[2.5]" />
        <span>APPROVE</span>
        {pct !== undefined && (
          <span className="flex items-center gap-1 ml-1 pl-1.5 border-l border-white/30">
            <span className="font-mono text-[11px] tracking-tight">{pct}%</span>
            <span className="w-8 h-1.5 bg-black/20 rounded-full overflow-hidden inline-block align-middle">
              <span
                className="block h-full bg-white rounded-full"
                style={{ width: `${Math.min(100, Math.max(0, pct))}%` }}
              />
            </span>
          </span>
        )}
      </span>
    );
  }

  if (normDecision === 'HUMAN_REVIEW' || normDecision === 'HUMAN REVIEW') {
    return (
      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-xs shadow-amber-500/25 animate-pulse">
        <AlertTriangle className="w-3.5 h-3.5 stroke-[2.5]" />
        <span>HUMAN REVIEW</span>
        {pct !== undefined && (
          <span className="flex items-center gap-1 ml-1 pl-1.5 border-l border-white/30">
            <span className="font-mono text-[11px] tracking-tight">{pct}%</span>
            <span className="w-8 h-1.5 bg-black/20 rounded-full overflow-hidden inline-block align-middle">
              <span
                className="block h-full bg-white rounded-full"
                style={{ width: `${Math.min(100, Math.max(0, pct))}%` }}
              />
            </span>
          </span>
        )}
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-gradient-to-r from-rose-600 to-red-600 text-white shadow-xs shadow-rose-600/20">
      <XCircle className="w-3.5 h-3.5 stroke-[2.5]" />
      <span>REJECT</span>
      {pct !== undefined && (
        <span className="flex items-center gap-1 ml-1 pl-1.5 border-l border-white/30">
          <span className="font-mono text-[11px] tracking-tight">{pct}%</span>
          <span className="w-8 h-1.5 bg-black/20 rounded-full overflow-hidden inline-block align-middle">
            <span
              className="block h-full bg-white rounded-full"
              style={{ width: `${Math.min(100, Math.max(0, pct))}%` }}
            />
          </span>
        </span>
      )}
    </span>
  );
};
