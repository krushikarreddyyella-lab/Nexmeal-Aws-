import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Clock, 
  MapPin, 
  Sparkles, 
  Flame, 
  Pause, 
  Play,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import { Donation } from '../types';
import { StatusBadge } from './StatusBadge';

interface Props {
  donations: Donation[];
  onSelectDonation: (donation: Donation) => void;
  onNavigate: (tab: string, contextId?: string) => void;
}

export const FeaturedDonationCarousel: React.FC<Props> = ({
  donations,
  onSelectDonation,
  onNavigate,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const ROTATION_INTERVAL_MS = 5000; // 5 seconds rotation interval

  // Filter donations suitable for featured spotlight (active, proposed, accepted, in-transit)
  const items = donations.filter(
    (d) => d.status === 'PROPOSED' || d.status === 'ACCEPTED' || d.status === 'IN_TRANSIT'
  );

  const total = items.length;

  const nextSlide = useCallback(() => {
    if (total === 0) return;
    setIsTransitioning(true);
    setCurrentIndex((prev) => (prev + 1) % total);
    setTimeout(() => setIsTransitioning(false), 300);
  }, [total]);

  const prevSlide = useCallback(() => {
    if (total === 0) return;
    setIsTransitioning(true);
    setCurrentIndex((prev) => (prev - 1 + total) % total);
    setTimeout(() => setIsTransitioning(false), 300);
  }, [total]);

  const goToSlide = (idx: number) => {
    if (idx === currentIndex) return;
    setIsTransitioning(true);
    setCurrentIndex(idx);
    setTimeout(() => setIsTransitioning(false), 300);
  };

  // 5-second automatic rotation with pause-on-hover & reduced-motion support
  useEffect(() => {
    if (total <= 1) return;

    // Check system prefers-reduced-motion
    const prefersReducedMotion = window.matchMedia(
      '(prefers-reduced-motion: reduce)'
    ).matches;

    if (prefersReducedMotion || isPaused) {
      return;
    }

    const timer = setInterval(() => {
      nextSlide();
    }, ROTATION_INTERVAL_MS);

    return () => clearInterval(timer);
  }, [isPaused, total, nextSlide, ROTATION_INTERVAL_MS]);

  if (total === 0) {
    return null;
  }

  const current = items[currentIndex] || items[0];

  // Calculate deadline countdown
  const hoursRemaining = Math.max(
    0,
    (new Date(current.pickup_deadline).getTime() - new Date().getTime()) /
      (3600 * 1000)
  );
  const timeFormatted =
    hoursRemaining < 1
      ? `${Math.max(1, Math.round(hoursRemaining * 60))}m remaining`
      : `${hoursRemaining.toFixed(1)}h remaining`;

  return (
    <div
      className="relative mx-auto max-w-md lg:max-w-none select-none space-y-4"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onTouchStart={() => setIsPaused(true)}
      onTouchEnd={() => setIsPaused(false)}
      role="region"
      aria-roledescription="carousel"
      aria-label="Featured Live Surplus Lots"
    >
      {/* Background ambient lighting */}
      <div className="absolute -inset-4 bg-gradient-to-tr from-emerald-500/20 via-amber-400/10 to-teal-500/10 rounded-3xl blur-2xl -z-10" />

      {/* 1. Main Clean Food Photo Viewport (No "Next in Xs" display on photo as requested) */}
      <div className="rounded-3xl overflow-hidden shadow-elevated border-4 border-white aspect-[4/3] sm:aspect-[16/11] relative bg-stone-900 group">
        <img
          key={current.id}
          src={
            current.image_url ||
            'https://images.unsplash.com/photo-1555244162-803834f70033?auto=format&fit=crop&w=1200&q=80'
          }
          alt={current.food_title}
          onError={(e) => {
            (e.target as HTMLImageElement).src =
              'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=1200&q=80';
          }}
          className={`w-full h-full object-cover transition-all duration-700 ease-out group-hover:scale-105 ${
            isTransitioning ? 'opacity-85 scale-[1.02]' : 'opacity-100 scale-100'
          }`}
        />

        {/* Subtle Vignette for Contrast */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-black/20 pointer-events-none" />

        {/* Top Badges Bar: Only clean Status & Quantity (Next display removed as requested) */}
        <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10">
          <div className="flex items-center gap-2">
            <StatusBadge status={current.status} />
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-black/60 text-white backdrop-blur-md border border-white/15">
              {current.quantity_value} {current.quantity_unit}
            </span>
          </div>
        </div>

        {/* Navigation Arrow Overlays (Desktop & Mobile accessible) */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            prevSlide();
          }}
          aria-label="Previous surplus lot"
          className="absolute left-3.5 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 hover:bg-black/80 text-white backdrop-blur-md flex items-center justify-center transition-all opacity-85 hover:opacity-100 z-20 border border-white/25 hover:scale-110 shadow-md"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <button
          onClick={(e) => {
            e.stopPropagation();
            nextSlide();
          }}
          aria-label="Next surplus lot"
          className="absolute right-3.5 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 hover:bg-black/80 text-white backdrop-blur-md flex items-center justify-center transition-all opacity-85 hover:opacity-100 z-20 border border-white/25 hover:scale-110 shadow-md"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* 2. Live Handover Window & Details Card (Located downside of the photo) */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 shadow-card border border-stone-200/90 space-y-4 animate-fade-in">
        {/* Handover Window Header */}
        <div className="flex items-center justify-between pb-3 border-b border-stone-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-200/60">
              <Flame className="w-4 h-4 text-amber-500 animate-pulse" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-stone-400 block tracking-wider">
                Consignment Window
              </span>
              <span className="text-xs font-bold text-stone-800">
                Live Handover Window Active
              </span>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] uppercase font-bold text-stone-400 block tracking-wider">
              Safe Pickup Window
            </span>
            <span className="font-mono text-xs font-bold px-2.5 py-0.5 rounded-full bg-amber-100/80 text-amber-900 border border-amber-300/60 inline-block">
              {timeFormatted}
            </span>
          </div>
        </div>

        {/* Title, Donor Organization & Location */}
        <div className="space-y-1.5">
          <div className="flex items-start justify-between gap-3">
            <h3 className="font-bold font-display text-base sm:text-lg text-[#17211C] leading-snug">
              {current.food_title}
            </h3>
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-stone-100 text-stone-600 shrink-0 border border-stone-200">
              {current.dietary_type}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-stone-600 pt-1">
            <span className="font-semibold text-emerald-800 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              {current.donor_name}
            </span>
            <span className="text-stone-300">•</span>
            <span className="text-stone-500">{current.donor_type}</span>
            <span className="text-stone-300">•</span>
            <span className="text-stone-600 font-medium flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
              {current.donor_address}
            </span>
          </div>
        </div>

        {/* Quick Action Buttons */}
        <div className="pt-2 flex items-center gap-2 border-t border-stone-100">
          <button
            onClick={() => onSelectDonation(current)}
            className="flex-1 py-2 px-4 rounded-xl border border-stone-300 hover:border-stone-400 bg-white hover:bg-stone-50 text-stone-800 text-xs font-bold transition-all text-center"
          >
            Inspect Details
          </button>
          <button
            onClick={() => onNavigate('matches', current.id)}
            className="flex-1 py-2 px-4 rounded-xl bg-[#103B2D] hover:bg-[#0B261D] text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-sm hover:shadow"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
            <span>Match AI</span>
          </button>
        </div>
      </div>

      {/* 3. Dots which represent window placed DOWNSIDE of Live Handover Window as requested */}
      <div className="flex items-center justify-between px-3 py-2 rounded-2xl bg-white border border-stone-200/80 shadow-2xs">
        <span className="text-[11px] font-medium text-stone-500 flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
          <span>Active Consignments</span>
        </span>

        {/* Window Dots Indicator */}
        <div className="flex items-center gap-2">
          {items.map((_, idx) => (
            <button
              key={idx}
              onClick={() => goToSlide(idx)}
              aria-label={`Switch to consignment window ${idx + 1}`}
              className={`transition-all duration-300 rounded-full cursor-pointer ${
                idx === currentIndex
                  ? 'w-7 h-2 bg-[#103B2D] shadow-xs'
                  : 'w-2 h-2 bg-stone-300 hover:bg-stone-400'
              }`}
            />
          ))}
        </div>

        <span className="text-[11px] font-mono text-stone-600 bg-stone-100 px-2 py-0.5 rounded-md font-semibold">
          {currentIndex + 1} of {total}
        </span>
      </div>
    </div>
  );
};
