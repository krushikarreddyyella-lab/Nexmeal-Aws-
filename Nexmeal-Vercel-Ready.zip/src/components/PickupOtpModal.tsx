import React, { useState } from 'react';
import { X, CheckCircle, ShieldCheck, KeyRound, AlertCircle, Loader2 } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  donationId: string;
  expectedCode?: string;
  onConfirm: (donationId: string, code: string) => Promise<void>;
}

export const PickupOtpModal: React.FC<Props> = ({
  isOpen,
  onClose,
  donationId,
  expectedCode,
  onConfirm,
}) => {
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim()) {
      setError('Please enter the 4-digit verification code.');
      return;
    }
    setError(null);
    setLoading(true);
    try {
      await onConfirm(donationId, code.trim());
      setCode('');
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Verification failed. Please check the code.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
      <div 
        className="bg-white rounded-3xl max-w-md w-full overflow-hidden shadow-elevated border border-stone-200 my-8 p-6 sm:p-8 space-y-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-2 border-b border-stone-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-800">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold font-display text-stone-900">Confirm Collection Handshake</h3>
              <p className="text-xs text-stone-500">Chain-of-custody OTP verification</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100">
            <X className="w-5 h-5" />
          </button>
        </div>

        {expectedCode && (
          <div className="bg-[#FAFAF6] p-4 rounded-2xl border border-stone-200 text-center space-y-1">
            <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider block">
              Registered Handshake Code (Donor side)
            </span>
            <span className="text-2xl font-bold font-mono tracking-widest text-[#103B2D]">
              {expectedCode}
            </span>
            <p className="text-[11px] text-stone-400">
              Obtain this code from the donor staff at physical pickup to verify handover authenticity.
            </p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs font-bold text-stone-700 block mb-1.5">
              Enter 4-Digit Handshake Code
            </label>
            <input
              type="text"
              maxLength={6}
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="e.g. 4821"
              autoFocus
              className="w-full text-center text-2xl tracking-widest font-mono py-3 px-4 rounded-xl border border-stone-300 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none transition-all"
            />
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="flex items-center gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              disabled={loading}
              className="flex-1 py-3 rounded-xl border border-stone-300 text-stone-700 text-xs font-semibold hover:bg-stone-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading || !code.trim()}
              className="flex-1 py-3 rounded-xl bg-gradient-to-r from-[#103B2D] to-[#164E3D] hover:from-[#0B261D] hover:to-[#103B2D] text-white text-xs font-bold shadow-sm transition-all disabled:opacity-50 flex items-center justify-center gap-1.5"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Verifying...
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4" />
                  Confirm Handover
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
