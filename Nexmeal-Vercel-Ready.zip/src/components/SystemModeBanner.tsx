import React, { useState } from 'react';
import { ShieldCheck, Cpu, Sparkles, ChevronDown, ChevronUp } from 'lucide-react';

interface Props {
  isLiveBedrock: boolean;
}

export const SystemModeBanner: React.FC<Props> = ({ isLiveBedrock }) => {
  const [showDetails, setShowDetails] = useState(false);

  return (
    <div className="bg-slate-900 text-slate-200 border-b border-slate-800 text-xs py-1.5 px-4 sm:px-6 lg:px-8 select-none transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Left Side: System status + Safety Guardrails */}
        <div className="flex items-center gap-2.5 sm:gap-3">
          <div className="flex items-center gap-1.5">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="font-semibold text-white tracking-tight">System Active</span>
          </div>

          <span className="text-slate-700 hidden sm:inline">|</span>

          <div className="hidden sm:flex items-center gap-1.5 text-slate-300">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span className="font-medium text-slate-400">Safety Guardrails:</span>
            <span className="font-semibold text-emerald-400 uppercase tracking-wider text-[10px] bg-emerald-950/60 border border-emerald-800/60 px-1.5 py-0.2 rounded">
              ENFORCED
            </span>
          </div>
        </div>

        {/* Right Side: Strands Decider + Bedrock Status */}
        <div className="flex items-center gap-2.5 sm:gap-3">
          <div className="hidden md:flex items-center gap-1.5 text-slate-300">
            <Cpu className="w-3.5 h-3.5 text-teal-400 shrink-0" />
            <span className="text-slate-400">Classifier:</span>
            <span className="font-medium text-slate-200">Strands Decider 2B</span>
          </div>

          <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-800/90 border border-slate-700/80 text-[11px]">
            <Sparkles className="w-3 h-3 text-amber-400 shrink-0" />
            <span className="hidden sm:inline text-slate-400">Bedrock:</span>
            {isLiveBedrock ? (
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                AWS Live
              </span>
            ) : (
              <span className="text-sky-300 font-medium">Simulation</span>
            )}
          </div>

          {/* Mobile expand button to view details if needed */}
          <button
            type="button"
            onClick={() => setShowDetails(!showDetails)}
            className="sm:hidden p-0.5 text-slate-400 hover:text-white transition-colors"
            aria-label="Toggle system details"
          >
            {showDetails ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Mobile expanded drawer */}
      {showDetails && (
        <div className="sm:hidden mt-1.5 pt-1.5 border-t border-slate-800 flex flex-col gap-1.5 animate-slide-down text-[11px] text-slate-300">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>Safety Guardrails:</span>
            <span className="font-semibold text-emerald-400">ENFORCED</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-teal-400 shrink-0" />
            <span>Classifier:</span>
            <span className="font-semibold text-white">Strands Decider 2B</span>
          </div>
        </div>
      )}
    </div>
  );
};
