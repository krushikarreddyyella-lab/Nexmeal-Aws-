import React from 'react';
import { X, UserCheck, Building2, HeartHandshake, Shield, Truck, Check } from 'lucide-react';
import { UserProfile, UserRole } from '../types';
import { mockUserProfiles } from '../api/mockData';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onSelectUser: (user: UserProfile) => void;
}

export const RoleSwitcherModal: React.FC<Props> = ({
  isOpen,
  onClose,
  currentUser,
  onSelectUser,
}) => {
  if (!isOpen) return null;

  const getRoleIcon = (role: UserRole) => {
    switch (role) {
      case 'donor':
        return Building2;
      case 'ngo':
        return HeartHandshake;
      case 'coordinator':
        return Shield;
      case 'driver':
        return Truck;
      default:
        return UserCheck;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
      <div 
        className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-elevated border border-stone-200 p-6 sm:p-8 space-y-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-stone-100">
          <div>
            <h3 className="text-base font-bold font-display text-stone-900">Switch Active Perspective</h3>
            <p className="text-xs text-stone-500">Test Nexmeal from different participant roles</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-2.5">
          {mockUserProfiles.map((user) => {
            const Icon = getRoleIcon(user.role);
            const isSelected = currentUser.id === user.id;

            return (
              <div
                key={user.id}
                onClick={() => {
                  onSelectUser(user);
                  onClose();
                }}
                className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-center justify-between ${
                  isSelected
                    ? 'bg-emerald-50/80 border-emerald-400 ring-1 ring-emerald-400 shadow-sm'
                    : 'bg-[#FAFAF6] border-stone-200/80 hover:bg-stone-100/80 hover:border-stone-300'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    isSelected ? 'bg-emerald-600 text-white' : 'bg-stone-200 text-stone-700'
                  }`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-stone-900">{user.name}</span>
                      <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded-full font-bold ${
                        user.role === 'donor'
                          ? 'bg-blue-100 text-blue-800'
                          : user.role === 'ngo'
                          ? 'bg-emerald-100 text-emerald-800'
                          : user.role === 'coordinator'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-purple-100 text-purple-800'
                      }`}>
                        {user.role}
                      </span>
                    </div>
                    <span className="text-xs text-stone-500">{user.entityName}</span>
                  </div>
                </div>

                {isSelected && (
                  <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center">
                    <Check className="w-4 h-4" />
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <p className="text-[11px] text-stone-400 text-center pt-2 border-t border-stone-100">
          Switching roles dynamically reconfigures context for donation registration, NGO intake, and coordinator audit approvals.
        </p>
      </div>
    </div>
  );
};
