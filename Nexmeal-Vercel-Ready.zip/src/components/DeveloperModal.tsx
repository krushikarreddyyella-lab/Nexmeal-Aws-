import React, { useState } from 'react';
import { 
  X, 
  Mail, 
  Linkedin, 
  ExternalLink, 
  Check, 
  Copy, 
  Code2, 
  Sparkles, 
  Award, 
  ShieldCheck,
  Heart
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const DeveloperModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const email = 'krushikarreddyyella23@gmail.com';
  const linkedinUrl = 'https://www.linkedin.com/in/krushikar-yella-8830ba378';
  const linkedinName = 'KRUSHIKAR YELLA';
  const developerName = 'KRUSHIKAR REDDY YELLA';

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-sm animate-fade-in"
      onClick={onClose}
    >
      <div 
        className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-elevated border border-stone-200 relative animate-scale-in"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Decorative Top Accent Banner */}
        <div className="h-24 bg-gradient-to-r from-[#103B2D] via-[#164E3D] to-[#0B261D] relative p-6 flex items-start justify-between">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-emerald-300 text-[11px] font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Developer Profile</span>
          </div>

          <button
            onClick={onClose}
            aria-label="Close modal"
            className="w-8 h-8 rounded-full bg-black/30 hover:bg-black/50 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Profile Avatar Overlay */}
        <div className="px-6 sm:px-8 pb-8 pt-0 relative">
          <div className="-mt-12 flex items-end justify-between mb-4">
            <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-[#103B2D] via-[#1b5e48] to-[#C5A059] p-1 shadow-elevated">
              <div className="w-full h-full bg-[#103B2D] rounded-xl flex items-center justify-center text-white text-2xl font-bold font-display tracking-wider border border-white/20">
                KY
              </div>
            </div>
          </div>

          {/* Developer Details */}
          <div className="space-y-1.5">
            <h2 className="text-2xl font-bold font-display text-stone-900 tracking-tight">
              {developerName}
            </h2>
            <p className="text-xs text-stone-600 leading-relaxed pt-1">
              Developer of <strong>Nexmeal</strong>: an autonomous food-rescue platform combining rigid deterministic safety guardrails, Strands Decider 2B policy classification, and Amazon Bedrock explainable dispatch.
            </p>
          </div>

          {/* Contact & Social Links Cards */}
          <div className="mt-6 space-y-3">
            {/* Official Email Card */}
            <div className="p-3.5 rounded-2xl bg-[#FAFAF6] border border-stone-200/80 flex items-center justify-between gap-3 hover:border-emerald-300 transition-colors">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-[#103B2D] flex items-center justify-center shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <span className="text-[10px] uppercase font-bold text-stone-400 block tracking-wider">
                    Official Email
                  </span>
                  <a 
                    href={`mailto:${email}`}
                    className="text-xs sm:text-sm font-bold text-stone-900 hover:text-emerald-800 truncate block transition-colors"
                  >
                    {email}
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={handleCopyEmail}
                  title="Copy email address"
                  className="p-2 rounded-xl border border-stone-200 hover:bg-white text-stone-600 hover:text-stone-900 transition-all flex items-center gap-1 text-xs font-semibold"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-emerald-700 text-[11px]">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span className="text-[11px] hidden sm:inline">Copy</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* LinkedIn Card */}
            <div className="p-3.5 rounded-2xl bg-[#FAFAF6] border border-stone-200/80 flex items-center justify-between gap-3 hover:border-blue-300 transition-colors">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
                  <Linkedin className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <span className="text-[10px] uppercase font-bold text-stone-400 block tracking-wider">
                    LinkedIn Profile
                  </span>
                  <span className="text-xs sm:text-sm font-bold text-stone-900 block truncate">
                    {linkedinName}
                  </span>
                </div>
              </div>

              <a
                href={linkedinUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="py-2 px-3.5 rounded-xl bg-[#0077B5] hover:bg-[#006097] text-white text-xs font-bold transition-all flex items-center gap-1.5 shadow-xs shrink-0"
              >
                <span>Connect</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Tech Stack Credential Highlights */}
          <div className="mt-6 pt-5 border-t border-stone-100">
            <div className="grid grid-cols-2 gap-2 text-center text-xs">
              <div className="p-2.5 rounded-xl bg-stone-50 border border-stone-200/60">
                <span className="text-[10px] uppercase font-bold text-stone-400 block">System Engineering</span>
                <span className="font-semibold text-stone-800 text-[11px]">React • TypeScript • FastAPI</span>
              </div>
              <div className="p-2.5 rounded-xl bg-stone-50 border border-stone-200/60">
                <span className="text-[10px] uppercase font-bold text-stone-400 block">AI Integration</span>
                <span className="font-semibold text-stone-800 text-[11px]">Strands Decider 2B & Bedrock</span>
              </div>
            </div>
          </div>

          {/* Action Footer */}
          <div className="mt-6">
            <button
              onClick={onClose}
              className="w-full py-3 rounded-2xl bg-[#103B2D] hover:bg-[#0B261D] text-white text-xs font-bold transition-all shadow-card"
            >
              Close Profile
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
