import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  MapPin, 
  Clock, 
  Sparkles, 
  Building2, 
  UtensilsCrossed, 
  SlidersHorizontal, 
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  ArrowUpDown
} from 'lucide-react';
import { Donation } from '../types';
import { StatusBadge } from '../components/StatusBadge';

interface Props {
  donations: Donation[];
  initialCategory?: string;
  onNavigate: (tab: string, contextId?: string) => void;
  onSelectDonation: (donation: Donation) => void;
  onOpenDonateModal: () => void;
}

export const DiscoverPage: React.FC<Props> = ({
  donations,
  initialCategory,
  onNavigate,
  onSelectDonation,
  onOpenDonateModal,
}) => {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory || 'ALL');
  const [selectedDiet, setSelectedDiet] = useState<string>('ALL');
  const [selectedStorage, setSelectedStorage] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'deadline' | 'quantity' | 'newest'>('deadline');

  const categories = ['ALL', 'Cooked Meals', 'Bakery', 'Produce', 'Dairy', 'Packaged'];
  const dietaryTypes = ['ALL', 'VEGETARIAN', 'NON_VEGETARIAN', 'VEGAN'];

  // Filter & Sort Logic
  const filteredDonations = useMemo(() => {
    return donations.filter((d) => {
      // Search filter
      const matchesSearch =
        !search ||
        d.food_title.toLowerCase().includes(search.toLowerCase()) ||
        d.donor_name.toLowerCase().includes(search.toLowerCase()) ||
        d.donor_address.toLowerCase().includes(search.toLowerCase());

      // Category filter
      const matchesCategory =
        selectedCategory === 'ALL' || d.food_category.toLowerCase() === selectedCategory.toLowerCase();

      // Dietary filter
      const matchesDiet =
        selectedDiet === 'ALL' || (d.dietary_type || '').toUpperCase() === selectedDiet;

      // Storage filter
      const matchesStorage =
        selectedStorage === 'ALL' || (d.storage_requirement || '').toUpperCase() === selectedStorage;

      return matchesSearch && matchesCategory && matchesDiet && matchesStorage;
    }).sort((a, b) => {
      if (sortBy === 'deadline') {
        return new Date(a.pickup_deadline).getTime() - new Date(b.pickup_deadline).getTime();
      }
      if (sortBy === 'quantity') {
        return b.quantity_value - a.quantity_value;
      }
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    });
  }, [donations, search, selectedCategory, selectedDiet, selectedStorage, sortBy]);

  const resetFilters = () => {
    setSearch('');
    setSelectedCategory('ALL');
    setSelectedDiet('ALL');
    setSelectedStorage('ALL');
    setSortBy('deadline');
  };

  return (
    <div className="space-y-8 pb-12 animate-fade-in">
      {/* Page Header */}
      <div className="space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#E4F4EE] text-[#103B2D] text-xs font-semibold">
          <UtensilsCrossed className="w-3.5 h-3.5" />
          <span>Real-time Surplus Food Discovery</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold font-display text-stone-900 tracking-tight">
          Discover Surplus Food Lots
        </h1>
        <p className="text-sm text-stone-500 max-w-2xl">
          Search and filter verified surplus batches from banquet halls, corporate cafeterias, and restaurants ready for NGO allocation and dispatch.
        </p>
      </div>

      {/* Search and Filters Bar */}
      <div className="bg-white p-5 rounded-3xl border border-stone-200/80 shadow-subtle space-y-4">
        {/* Top Search Input & Sort Selector */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <div className="flex-1 flex items-center gap-3 px-4 py-3 rounded-2xl bg-[#FAFAF6] border border-stone-200/80">
            <Search className="w-4 h-4 text-stone-400 shrink-0" />
            <input
              type="text"
              placeholder="Search by meal name, donor facility, location, or keyword..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="bg-transparent text-xs sm:text-sm text-stone-800 placeholder:text-stone-400 outline-none w-full"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="text-xs text-stone-400 hover:text-stone-700"
              >
                Clear
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <div className="flex items-center gap-2 px-3.5 py-3 rounded-2xl bg-[#FAFAF6] border border-stone-200/80 text-xs">
              <ArrowUpDown className="w-4 h-4 text-stone-400 shrink-0" />
              <span className="text-stone-400 font-semibold hidden md:inline">Sort:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-transparent font-bold text-stone-800 outline-none cursor-pointer"
              >
                <option value="deadline">Approaching Deadline First</option>
                <option value="quantity">Largest Quantity (kg)</option>
                <option value="newest">Recently Registered</option>
              </select>
            </div>

            {(selectedCategory !== 'ALL' || selectedDiet !== 'ALL' || selectedStorage !== 'ALL' || search) && (
              <button
                onClick={resetFilters}
                className="p-3 rounded-2xl border border-stone-200 hover:bg-stone-50 text-stone-500 hover:text-stone-800 transition-colors"
                title="Reset all filters"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Category Pills (Swiggy / Zomato style) */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-1">
          <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider shrink-0 mr-1">
            Category:
          </span>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-[#103B2D] text-white shadow-xs'
                  : 'bg-[#FAFAF6] text-stone-600 hover:bg-stone-200/60 border border-stone-200/60'
              }`}
            >
              {cat === 'ALL' ? 'All Categories' : cat}
            </button>
          ))}
        </div>

        {/* Secondary Filter Tags */}
        <div className="flex items-center gap-2 flex-wrap pt-1 text-xs">
          <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider mr-1">Dietary:</span>
          {dietaryTypes.map((dt) => (
            <button
              key={dt}
              onClick={() => setSelectedDiet(dt)}
              className={`px-3 py-1 rounded-lg text-[11px] font-medium transition-all ${
                selectedDiet === dt
                  ? 'bg-emerald-100 text-emerald-800 font-bold border border-emerald-300'
                  : 'bg-stone-100 text-stone-500 hover:text-stone-800'
              }`}
            >
              {dt.replace('_', ' ')}
            </button>
          ))}

          <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider ml-3 mr-1">Storage:</span>
          {['ALL', 'ROOM_TEMP', 'REFRIGERATED', 'HOT_HOLDING', 'FROZEN'].map((st) => (
            <button
              key={st}
              onClick={() => setSelectedStorage(st)}
              className={`px-3 py-1 rounded-lg text-[11px] font-medium transition-all ${
                selectedStorage === st
                  ? 'bg-amber-100 text-amber-800 font-bold border border-amber-300'
                  : 'bg-stone-100 text-stone-500 hover:text-stone-800'
              }`}
            >
              {st.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Results Header */}
      <div className="flex items-center justify-between text-xs text-stone-500">
        <span>Showing <strong>{filteredDonations.length}</strong> surplus food consignments</span>
        <span>Verified Food Safety Protocol</span>
      </div>

      {/* Grid of Food Listings */}
      {filteredDonations.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-stone-200/80 shadow-subtle space-y-4 max-w-md mx-auto">
          <div className="w-12 h-12 rounded-2xl bg-stone-100 text-stone-400 flex items-center justify-center mx-auto">
            <Search className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <h3 className="font-bold font-display text-stone-800 text-base">No surplus food lots found</h3>
            <p className="text-xs text-stone-500">
              No active listings match your selected search and category filters.
            </p>
          </div>
          <button
            onClick={resetFilters}
            className="px-5 py-2.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold transition-colors"
          >
            Clear All Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDonations.map((don) => {
            const hoursRemaining = Math.max(
              0,
              (new Date(don.pickup_deadline).getTime() - new Date().getTime()) / (3600 * 1000)
            );
            const isUrgent = hoursRemaining > 0 && hoursRemaining < 1.5;

            return (
              <div
                key={don.id}
                className="bg-white rounded-3xl overflow-hidden border border-stone-200/80 shadow-subtle hover:shadow-card transition-all duration-300 flex flex-col justify-between group hover:-translate-y-1"
              >
                <div>
                  {/* Photo Header */}
                  <div className="relative h-48 w-full bg-stone-100 overflow-hidden">
                    <img
                      src={don.image_url || 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80'}
                      alt={don.food_title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    
                    <div className="absolute top-3 left-3 flex items-center gap-1.5 flex-wrap">
                      <StatusBadge status={don.status} />
                      {isUrgent && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500 text-white animate-pulse">
                          Urgent Window
                        </span>
                      )}
                    </div>

                    <div className="absolute bottom-3 right-3 px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-black/70 text-white backdrop-blur-md">
                      {don.quantity_value} {don.quantity_unit}
                    </div>

                    <div className="absolute bottom-3 left-3 px-2 py-0.5 rounded-md text-[10px] font-semibold bg-white/90 text-stone-800 backdrop-blur-md">
                      {don.food_category}
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-5 space-y-3">
                    <h3 className="font-bold font-display text-base text-stone-900 line-clamp-1 group-hover:text-emerald-800 transition-colors">
                      {don.food_title}
                    </h3>

                    <div className="space-y-1.5 text-xs text-stone-500">
                      <div className="flex items-center gap-2">
                        <Building2 className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                        <span className="font-semibold text-stone-800 truncate">{don.donor_name}</span>
                        <span className="text-stone-300">•</span>
                        <span className="text-[11px] text-stone-400">{don.donor_type}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <Clock className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                        <span className={isUrgent ? 'text-amber-700 font-bold' : ''}>
                          Pickup Deadline: {hoursRemaining > 0 ? `${hoursRemaining.toFixed(1)} hrs left` : 'Expired'}
                        </span>
                      </div>

                      <div className="flex items-start gap-2">
                        <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0 mt-0.5" />
                        <span className="truncate">{don.donor_address}</span>
                      </div>
                    </div>

                    {don.handling_instructions && (
                      <p className="text-[11px] text-stone-400 line-clamp-1 italic bg-stone-50 p-2 rounded-xl">
                        "{don.handling_instructions}"
                      </p>
                    )}
                  </div>
                </div>

                {/* Card Action Footer */}
                <div className="p-5 pt-0 flex items-center gap-2.5 border-t border-stone-100 mt-2">
                  <button
                    onClick={() => onSelectDonation(don)}
                    className="flex-1 py-2.5 rounded-xl border border-stone-200 text-stone-700 hover:bg-stone-50 text-xs font-semibold transition-colors"
                  >
                    View Details
                  </button>

                  <button
                    onClick={() => onNavigate('matches', don.id)}
                    className="flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#103B2D] hover:bg-[#0B261D] text-white text-xs font-bold shadow-xs transition-colors"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Match AI</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
