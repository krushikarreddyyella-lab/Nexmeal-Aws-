import React, { useState, useEffect } from 'react';
import {
  Building2,
  ShieldCheck,
  ShieldAlert,
  Plus,
  Phone,
  Mail,
  MapPin,
  Truck,
  Snowflake,
  Clock,
  Star,
  Search,
  Filter,
  X,
  CheckCircle,
  Users,
  Compass,
  Sparkles
} from 'lucide-react';
import { Recipient } from '../types';
import { api } from '../api/client';

export const RecipientDirectoryPage: React.FC = () => {
  const [recipients, setRecipients] = useState<Recipient[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('ALL');

  const [formData, setFormData] = useState({
    name: '',
    organization_type: 'Community Kitchen',
    contact_person: '',
    contact_phone: '',
    contact_email: '',
    address: '',
    latitude: 12.9716,
    longitude: 77.5946,
    is_verified: true,
    daily_capacity_kg: 100,
    has_cold_storage: true,
    has_transportation: true,
    accepted_categories: 'Cooked Meals, Bakery, Produce',
    operating_hours_start: '08:00',
    operating_hours_end: '20:00',
  });

  const loadRecipients = async () => {
    try {
      setLoading(true);
      const data = await api.listRecipients();
      setRecipients(data);
    } catch (err) {
      console.error('Failed to load recipients:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRecipients();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.createRecipient(formData);
      setShowAddModal(false);
      // Reset form
      setFormData({
        name: '',
        organization_type: 'Community Kitchen',
        contact_person: '',
        contact_phone: '',
        contact_email: '',
        address: '',
        latitude: 12.9716,
        longitude: 77.5946,
        is_verified: true,
        daily_capacity_kg: 100,
        has_cold_storage: true,
        has_transportation: true,
        accepted_categories: 'Cooked Meals, Bakery, Produce',
        operating_hours_start: '08:00',
        operating_hours_end: '20:00',
      });
      loadRecipients();
    } catch (err: any) {
      alert(`Error creating recipient: ${err.message}`);
    }
  };

  const filteredRecipients = recipients.filter((rec) => {
    const matchesSearch =
      rec.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.contact_person.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType =
      typeFilter === 'ALL' || rec.organization_type === typeFilter;
    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-8 pb-16">
      {/* Header Banner */}
      <div className="relative overflow-hidden bg-gradient-to-br from-white via-stone-50 to-blue-50/30 p-6 sm:p-10 rounded-3xl border border-stone-200/80 shadow-sm backdrop-blur-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200/80 text-blue-800 text-xs font-semibold">
              <Users className="w-3.5 h-3.5 text-blue-600" />
              <span>Verified Partner Network</span>
            </div>

            <h1 className="text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight leading-tight">
              NGO & Community Kitchen Directory
            </h1>

            <p className="text-sm sm:text-base text-slate-600 font-normal leading-relaxed">
              Verified grassroots partners, shelter homes, and community kitchens connected to autonomous surplus matching and food-rescue logistics.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-white hover:bg-stone-50 text-slate-900 border border-stone-300 font-semibold text-sm shadow-sm hover:shadow transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4 text-emerald-600" />
              <span>Register New Partner</span>
            </button>
          </div>
        </div>

        {/* Ambient glow */}
        <div className="absolute -top-24 -right-24 w-80 h-80 bg-blue-200/20 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-stone-200/80 shadow-sm flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by NGO name, neighborhood, or contact person..."
            className="w-full pl-10 pr-4 py-2.5 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none transition-all placeholder:text-slate-400"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Organization Type Filter Pills */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 rounded-xl bg-stone-100 border border-stone-200/60 text-xs">
          {['ALL', 'Community Kitchen', 'Shelter', 'Food Bank', 'NGO'].map((type) => {
            const isActive = typeFilter === type;
            return (
              <button
                key={type}
                onClick={() => setTypeFilter(type)}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {type}
              </button>
            );
          })}
        </div>
      </div>

      {/* Directory Grid (Zomato-inspired Cards) */}
      {loading ? (
        <div className="py-24 text-center space-y-3 bg-white rounded-3xl border border-stone-200/80">
          <div className="w-10 h-10 border-3 border-emerald-600/20 border-t-emerald-600 rounded-full animate-spin mx-auto" />
          <p className="text-sm text-slate-500 font-medium">Loading verified recipient directory...</p>
        </div>
      ) : filteredRecipients.length === 0 ? (
        <div className="py-20 text-center space-y-4 bg-white rounded-3xl border border-stone-200/80 p-8">
          <div className="w-16 h-16 rounded-3xl bg-stone-100 text-slate-400 flex items-center justify-center mx-auto">
            <Building2 className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold text-slate-900">No organizations found</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              No recipient partners matched your criteria. Try adjusting your search query or add a new organization.
            </p>
          </div>
          <button
            onClick={() => {
              setSearchQuery('');
              setTypeFilter('ALL');
            }}
            className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-slate-700 rounded-xl text-xs font-semibold transition-all"
          >
            Clear Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredRecipients.map((rec) => {
            const currentUsed = rec.current_capacity_used_kg || 0;
            const dailyCapacity = rec.daily_capacity_kg || 1;
            const availableCapacity = Math.max(0, dailyCapacity - currentUsed);
            const usagePercent = Math.min(
              100,
              Math.round((currentUsed / dailyCapacity) * 100)
            );

            // Accepted categories split
            const categoryTags = rec.accepted_categories
              ? rec.accepted_categories
                  .split(',')
                  .map((c) => c.trim())
                  .filter(Boolean)
              : ['Cooked Meals'];

            // Reliability calculation
            const rawScore = rec.reliability_score ?? 0.96;
            const displayScore =
              rawScore <= 1 ? (rawScore * 100).toFixed(0) : rawScore.toFixed(0);

            return (
              <div
                key={rec.id}
                className="bg-white rounded-3xl border border-stone-200/80 shadow-sm hover:shadow-xl hover:-translate-y-0.5 transition-all duration-300 p-6 flex flex-col justify-between group relative overflow-hidden"
              >
                {/* Top Header Row */}
                <div className="space-y-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="inline-block text-[11px] font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md border border-blue-200/60 uppercase tracking-wider">
                        {rec.organization_type}
                      </div>
                      <h2 className="text-lg font-bold text-slate-900 tracking-tight group-hover:text-emerald-700 transition-colors">
                        {rec.name}
                      </h2>
                    </div>

                    {rec.is_verified ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 shrink-0">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Verified</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-800 bg-rose-50 px-2.5 py-1 rounded-full border border-rose-200 shrink-0">
                        <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
                        <span>Unverified</span>
                      </span>
                    )}
                  </div>

                  {/* Reliability Score & Hours */}
                  <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                    <div className="flex items-center gap-1 text-amber-600 font-semibold">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                      <span>{displayScore}% Reliability</span>
                    </div>

                    <div className="flex items-center gap-1 text-slate-500 font-medium text-[11px]">
                      <Clock className="w-3 h-3 text-slate-400" />
                      <span>
                        {rec.operating_hours_start || '08:00'} -{' '}
                        {rec.operating_hours_end || '20:00'}
                      </span>
                    </div>
                  </div>

                  {/* Capacity Bar */}
                  <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200/60 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-500 font-medium">Daily Intake Capacity</span>
                      <span className="font-bold text-slate-900">
                        {currentUsed.toFixed(0)}{' '}
                        <span className="text-slate-400 font-normal">/</span>{' '}
                        {dailyCapacity.toFixed(0)} kg
                      </span>
                    </div>

                    <div className="w-full h-2 bg-stone-200 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          usagePercent > 80
                            ? 'bg-gradient-to-r from-amber-500 to-orange-500'
                            : 'bg-gradient-to-r from-emerald-500 to-teal-500'
                        }`}
                        style={{ width: `${usagePercent}%` }}
                      />
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-500 font-medium">
                      <span>{usagePercent}% Allocated</span>
                      <span className="text-emerald-700 font-semibold font-mono">
                        {availableCapacity.toFixed(0)} kg free today
                      </span>
                    </div>
                  </div>

                  {/* Logistics Capabilities */}
                  <div className="flex flex-wrap gap-2 text-xs">
                    <span
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl border text-[11px] font-semibold ${
                        rec.has_cold_storage
                          ? 'bg-blue-50 text-blue-700 border-blue-200'
                          : 'bg-stone-50 text-slate-400 border-stone-200'
                      }`}
                    >
                      <Snowflake className="w-3 h-3" />
                      {rec.has_cold_storage ? 'Cold Storage Unit' : 'No Freezers'}
                    </span>

                    <span
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl border text-[11px] font-semibold ${
                        rec.has_transportation
                          ? 'bg-purple-50 text-purple-700 border-purple-200'
                          : 'bg-stone-50 text-slate-400 border-stone-200'
                      }`}
                    >
                      <Truck className="w-3 h-3" />
                      {rec.has_transportation ? 'Fleet Dispatch' : 'No Transport'}
                    </span>
                  </div>

                  {/* Accepted Food Category Pills */}
                  <div className="space-y-1.5">
                    <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">
                      Accepted Food Categories
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {categoryTags.slice(0, 3).map((cat, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-0.5 rounded-md bg-stone-100 text-slate-700 border border-stone-200 text-[10px] font-medium"
                        >
                          {cat}
                        </span>
                      ))}
                      {categoryTags.length > 3 && (
                        <span className="px-2 py-0.5 rounded-md bg-stone-50 text-slate-400 text-[10px] font-medium">
                          +{categoryTags.length - 3} more
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Contact Footer */}
                <div className="pt-4 mt-4 border-t border-stone-100 space-y-1.5 text-xs text-slate-500">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{rec.address}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">
                      {rec.contact_phone}{' '}
                      <span className="text-slate-400 font-normal">
                        ({rec.contact_person})
                      </span>
                    </span>
                  </div>
                  {rec.contact_email && (
                    <div className="flex items-center gap-2">
                      <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="truncate font-mono text-[11px]">
                        {rec.contact_email}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add Recipient Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-stone-200 animate-in fade-in zoom-in-95 duration-200 my-8">
            <div className="flex items-center justify-between pb-4 border-b border-stone-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-slate-900 tracking-tight">
                    Register Partner Organization
                  </h2>
                  <p className="text-xs text-slate-500">
                    Onboard community kitchens, food banks, and verified shelters.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-stone-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Organization / Entity Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none transition-all"
                  placeholder="e.g. Care & Share Community Kitchen"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Organization Type <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={formData.organization_type}
                    onChange={(e) =>
                      setFormData({ ...formData, organization_type: e.target.value })
                    }
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none transition-all text-slate-800"
                  >
                    <option value="Community Kitchen">Community Kitchen</option>
                    <option value="Shelter">Shelter Home</option>
                    <option value="Food Bank">Food Bank</option>
                    <option value="NGO">NGO Relief Hub</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Daily Capacity (kg) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    min="10"
                    required
                    value={formData.daily_capacity_kg}
                    onChange={(e) =>
                      setFormData({ ...formData, daily_capacity_kg: Number(e.target.value) })
                    }
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none transition-all"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Contact Person <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.contact_person}
                    onChange={(e) =>
                      setFormData({ ...formData, contact_person: e.target.value })
                    }
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none transition-all"
                    placeholder="e.g. Sister Maria Joseph"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Contact Phone <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.contact_phone}
                    onChange={(e) =>
                      setFormData({ ...formData, contact_phone: e.target.value })
                    }
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none transition-all"
                    placeholder="+91 98450 00000"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Contact Email
                </label>
                <input
                  type="email"
                  value={formData.contact_email}
                  onChange={(e) =>
                    setFormData({ ...formData, contact_email: e.target.value })
                  }
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none transition-all"
                  placeholder="coordinator@carekitchen.org"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Physical Address / Distribution Center <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none transition-all"
                  placeholder="Street address, landmark, area"
                />
              </div>

              {/* Operating Hours */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Opens At
                  </label>
                  <input
                    type="time"
                    value={formData.operating_hours_start}
                    onChange={(e) =>
                      setFormData({ ...formData, operating_hours_start: e.target.value })
                    }
                    className="w-full px-3 py-2 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Closes At
                  </label>
                  <input
                    type="time"
                    value={formData.operating_hours_end}
                    onChange={(e) =>
                      setFormData({ ...formData, operating_hours_end: e.target.value })
                    }
                    className="w-full px-3 py-2 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Capabilities Checkboxes */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <label className="flex items-center gap-3 p-3 rounded-xl border border-stone-200 hover:bg-stone-50 cursor-pointer transition-colors">
                  <input
                    type="checkbox"
                    checked={formData.has_cold_storage}
                    onChange={(e) =>
                      setFormData({ ...formData, has_cold_storage: e.target.checked })
                    }
                    className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <div className="text-xs">
                    <span className="font-semibold text-slate-900 block">Cold Storage Available</span>
                    <span className="text-[11px] text-slate-500">Freezers or walk-in chillers</span>
                  </div>
                </label>

                <label className="flex items-center gap-3 p-3 rounded-xl border border-stone-200 hover:bg-stone-50 cursor-pointer transition-colors">
                  <input
                    type="checkbox"
                    checked={formData.has_transportation}
                    onChange={(e) =>
                      setFormData({ ...formData, has_transportation: e.target.checked })
                    }
                    className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <div className="text-xs">
                    <span className="font-semibold text-slate-900 block">Transport Fleet</span>
                    <span className="text-[11px] text-slate-500">Can dispatch vehicle for pickup</span>
                  </div>
                </label>
              </div>

              {/* Modal Actions */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-5 py-2.5 text-xs font-semibold text-slate-600 hover:bg-stone-100 rounded-xl transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 text-xs font-bold bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
                >
                  Save Organization Partner
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
