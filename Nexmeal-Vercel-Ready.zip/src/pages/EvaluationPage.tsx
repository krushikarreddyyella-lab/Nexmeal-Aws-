import React, { useState, useEffect } from 'react';
import {
  Cpu,
  Play,
  CheckCircle,
  XCircle,
  Clock,
  Zap,
  AlertTriangle,
  BarChart3,
  ChevronDown,
  ChevronUp,
  Sparkles,
  ShieldCheck,
  Info,
  RefreshCw,
  ArrowRight,
  TrendingUp,
  CheckCircle2,
  Calendar,
  Layers
} from 'lucide-react';
import { BenchmarkResults, BenchmarkCase } from '../types';
import { api } from '../api/client';
import { DecisionBadge } from '../components/DecisionBadge';

export const EvaluationPage: React.FC = () => {
  const [results, setResults] = useState<BenchmarkResults | null>(null);
  const [testCases, setTestCases] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [expandedCaseId, setExpandedCaseId] = useState<string | null>(null);
  const [filter, setFilter] = useState<string>('ALL');

  const handleRunBenchmark = async () => {
    try {
      setLoading(true);
      const [benchmarkRes, casesList] = await Promise.all([
        api.runBenchmark(),
        api.getBenchmarkTestCases(),
      ]);
      setResults(benchmarkRes);
      setTestCases(casesList);
    } catch (err) {
      console.error('Failed to run benchmark suite:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    handleRunBenchmark();
  }, []);

  const toggleExpand = (caseId: string) => {
    setExpandedCaseId((prev) => (prev === caseId ? null : caseId));
  };

  const filteredCases = results?.cases
    ? filter === 'ALL'
      ? results.cases
      : results.cases.filter((c) => c.decider_decision === filter)
    : [];

  return (
    <div className="space-y-8 pb-12">
      {/* Header Section */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-white via-white to-stone-50/60 p-6 sm:p-10 border border-stone-200/80 shadow-sm">
        {/* Subtle decorative glow */}
        <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-amber-500/5 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-96 h-96 rounded-full bg-emerald-500/5 blur-3xl pointer-events-none" />

        <div className="relative flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-200/80">
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
              <span>Strands Decider 2B vs Heuristic Baseline</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="p-3 bg-gradient-to-br from-amber-500 to-orange-500 text-white rounded-2xl shadow-sm">
                <Cpu className="w-7 h-7" />
              </div>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-slate-900">
                Evaluation & Benchmarks
              </h1>
            </div>
            <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
              Empirical assessment of Strands Decider 2B accuracy, baseline comparison, and Decider vs Bedrock inference latency.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={handleRunBenchmark}
              disabled={loading}
              className="flex items-center gap-2 px-6 py-3.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white rounded-xl text-sm font-semibold shadow-sm hover:shadow-md transition-all disabled:opacity-60"
            >
              <Play className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              <span>{loading ? 'Executing Evaluation Suite...' : 'Run Benchmark'}</span>
            </button>
          </div>
        </div>
      </div>

      {results && (
        <div className="space-y-8">
          {/* Accuracy Comparison Section (Apple Keynote Style) */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
                  Model Accuracy Comparison
                </h2>
                <p className="text-xs sm:text-sm text-slate-500">
                  Direct evaluation of Decider 2B policy classifications against standard heuristic thresholds.
                </p>
              </div>
              <div className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
                <span>+{results.metrics.accuracy_improvement_percent}% Improvement</span>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              {/* Card 1: Decider 2B Accuracy */}
              <div className="relative group bg-white p-7 rounded-3xl border border-emerald-200/90 shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden flex flex-col justify-between">
                <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-emerald-500 to-teal-500" />
                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
                        <Cpu className="w-5 h-5" />
                      </div>
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                        Strands Decider 2B Accuracy
                      </span>
                    </div>
                    <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                      Primary Model
                    </span>
                  </div>

                  <div className="mt-6 flex items-baseline gap-2">
                    <span className="text-5xl sm:text-6xl font-extrabold tracking-tight text-emerald-600 font-sans">
                      {results.metrics.decider_accuracy_percent}
                    </span>
                    <span className="text-2xl font-bold text-emerald-600">%</span>
                  </div>

                  <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                    Zero safety violations. Correctly identifies tight pickup deadlines and borderline travel radiuses to prevent food spoilage.
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-stone-100 flex items-center justify-between text-xs">
                  <span className="text-slate-500">Evaluation Dataset</span>
                  <span className="font-mono text-slate-700 font-semibold">
                    {results.metrics.total_cases_evaluated} Curated Ground-Truth Cases
                  </span>
                </div>
              </div>

              {/* Card 2: Baseline Accuracy */}
              <div className="relative group bg-white p-7 rounded-3xl border border-stone-200/90 shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden flex flex-col justify-between">
                <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-stone-400 to-slate-500" />
                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="p-2 rounded-xl bg-stone-100 text-slate-600">
                        <BarChart3 className="w-5 h-5" />
                      </div>
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                        Heuristic Rule Baseline Accuracy
                      </span>
                    </div>
                    <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-stone-100 text-slate-700">
                      Comparative Baseline
                    </span>
                  </div>

                  <div className="mt-6 flex items-baseline gap-2">
                    <span className="text-5xl sm:text-6xl font-extrabold tracking-tight text-slate-700 font-sans">
                      {results.metrics.baseline_accuracy_percent}
                    </span>
                    <span className="text-2xl font-bold text-slate-500">%</span>
                  </div>

                  <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                    Rigid proximity threshold heuristic fails to account for tight collection deadlines and fleet capability constraints.
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-stone-100 flex items-center justify-between text-xs">
                  <span className="text-slate-500">Decider Delta</span>
                  <span className="font-semibold text-emerald-600">
                    +{results.metrics.accuracy_improvement_percent}% Accuracy Gain Over Baseline
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Latency, Safety Rules & Adaptation Metrics Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {/* Metric 1: Decider Latency */}
            <div className="bg-white p-6 rounded-2xl border border-stone-200/90 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Avg Decider 2B Latency
                </span>
                <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
                  <Zap className="w-4 h-4" />
                </div>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-mono">
                  {results.metrics.avg_decider_latency_ms}
                </span>
                <span className="text-sm font-semibold text-emerald-600">ms (sub-5ms)</span>
              </div>
              <p className="text-xs text-slate-500">
                Ultra-low latency policy evaluation executed locally on edge hardware.
              </p>
            </div>

            {/* Metric 2: Bedrock Latency */}
            <div className="bg-white p-6 rounded-2xl border border-stone-200/90 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Avg Bedrock Latency
                </span>
                <div className="p-2 rounded-lg bg-purple-50 text-purple-600">
                  <Sparkles className="w-4 h-4" />
                </div>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-mono">
                  {results.metrics.avg_bedrock_latency_ms}
                </span>
                <span className="text-sm font-semibold text-purple-600">ms</span>
              </div>
              <p className="text-xs text-slate-500">
                Cloud LLM generative narrative and justification synthesis.
              </p>
            </div>

            {/* Metric 3: Safety Guardrail Compliance */}
            <div className="bg-white p-6 rounded-2xl border border-stone-200/90 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Safety Rule Compliance
                </span>
                <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
                  <ShieldCheck className="w-4 h-4" />
                </div>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl sm:text-4xl font-extrabold text-emerald-600 font-mono">
                  100%
                </span>
                <span className="text-sm font-semibold text-emerald-700">Strict (0 Violations)</span>
              </div>
              <p className="text-xs text-slate-500">
                Zero safety breaches allowed through across all {results.metrics.total_cases_evaluated} stress scenarios.
              </p>
            </div>

            {/* Metric 4: Fallback Adaptation Rate */}
            <div className="bg-white p-6 rounded-2xl border border-stone-200/90 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Failure Recovery Rate
                </span>
                <div className="p-2 rounded-lg bg-amber-50 text-amber-600">
                  <RefreshCw className="w-4 h-4" />
                </div>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl sm:text-4xl font-extrabold text-amber-600 font-mono">
                  100%
                </span>
                <span className="text-sm font-semibold text-amber-700">Autonomous Re-route</span>
              </div>
              <p className="text-xs text-slate-500">
                Successfully re-indexes and allocates to secondary partner upon primary NGO decline.
              </p>
            </div>
          </div>

          {/* Observations & Findings Card */}
          <div className="bg-white rounded-3xl border border-stone-200 shadow-sm p-6 sm:p-8 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-amber-50 text-amber-600 rounded-xl">
                <Info className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-bold text-slate-900">
                  Evaluation Methodology & Empirical Observations
                </h3>
                <p className="text-xs text-slate-500">
                  Qualitative summary of model performance across safety boundaries.
                </p>
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-stone-50 border border-stone-200/80 text-sm text-slate-700 leading-relaxed font-sans">
              {results.observations}
            </div>

            {/* Architectural Highlights */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
              <div className="p-4 rounded-xl bg-white border border-stone-200 text-xs space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-slate-900">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Deterministic Pre-Filter</span>
                </div>
                <p className="text-slate-500 leading-relaxed">
                  Hard safety guardrails guarantee zero food safety violations before model inference.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-white border border-stone-200 text-xs space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-slate-900">
                  <AlertTriangle className="w-4 h-4 text-amber-600" />
                  <span>Nuanced Edge Routing</span>
                </div>
                <p className="text-slate-500 leading-relaxed">
                  Decider 2B escalates urgent deadlines and borderline distances to HUMAN_REVIEW rather than unsafe auto-approval.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-white border border-stone-200 text-xs space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-slate-900">
                  <Clock className="w-4 h-4 text-indigo-600" />
                  <span>Dual Latency Tiering</span>
                </div>
                <p className="text-slate-500 leading-relaxed">
                  Decider 2B delivers instant sub-5ms policy triage, while Bedrock delivers in-depth reasoning asynchronously.
                </p>
              </div>
            </div>
          </div>

          {/* Test Cases Table & Details */}
          <div className="bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-stone-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <h2 className="text-base sm:text-lg font-bold text-slate-900">
                  Repeatable Scenario Benchmark Suite ({results.cases.length} Cases)
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Detailed evaluation breakdown with ground truth comparison, confidence scores, latencies, and adaptive fallback tests.
                </p>
              </div>

              {/* Filter Tabs */}
              <div className="flex items-center gap-1 bg-stone-100 p-1 rounded-xl text-xs font-semibold">
                {['ALL', 'APPROVE', 'HUMAN_REVIEW', 'REJECT'].map((f) => (
                  <button
                    key={f}
                    onClick={() => setFilter(f)}
                    className={`px-3 py-1.5 rounded-lg transition-all ${
                      filter === f
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {f === 'ALL' ? `All (${results.cases.length})` : f.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-stone-50/80 text-slate-500 font-bold uppercase tracking-wider text-[11px] border-b border-stone-100">
                  <tr>
                    <th className="py-3.5 px-4">Case ID</th>
                    <th className="py-3.5 px-4">Scenario Description</th>
                    <th className="py-3.5 px-4">Ground Truth</th>
                    <th className="py-3.5 px-4">Hard Safety Gate</th>
                    <th className="py-3.5 px-4">Decider 2B Decision</th>
                    <th className="py-3.5 px-4">Baseline Decision</th>
                    <th className="py-3.5 px-4">Decider Latency</th>
                    <th className="py-3.5 px-4 text-center">Correctness</th>
                    <th className="py-3.5 px-4 text-center">Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 font-sans">
                  {filteredCases.map((c) => {
                    const isExpanded = expandedCaseId === c.case_id;

                    return (
                      <React.Fragment key={c.case_id}>
                        <tr
                          onClick={() => toggleExpand(c.case_id)}
                          className="hover:bg-stone-50/80 cursor-pointer transition-colors"
                        >
                          <td className="py-4 px-4 font-mono font-bold text-slate-800">
                            {c.case_id}
                          </td>
                          <td className="py-4 px-4 max-w-xs">
                            <span className="font-semibold text-slate-900 block text-xs">
                              {c.name}
                            </span>
                            <span className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                              {c.explanation_preview}
                            </span>
                          </td>
                          <td className="py-4 px-4">
                            <span className="px-2 py-0.5 rounded font-mono font-semibold bg-stone-100 text-slate-800 border border-stone-200 text-[10px]">
                              {c.ground_truth}
                            </span>
                          </td>
                          <td className="py-4 px-4">
                            {c.safety_passed ? (
                              <span className="inline-flex items-center gap-1 text-emerald-700 font-medium">
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                                <span>Passed</span>
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-rose-700 font-medium">
                                <XCircle className="w-3.5 h-3.5 text-rose-600" />
                                <span>Blocked</span>
                              </span>
                            )}
                          </td>
                          <td className="py-4 px-4">
                            <DecisionBadge decision={c.decider_decision} confidence={c.decider_confidence} />
                          </td>
                          <td className="py-4 px-4">
                            <span className="px-2 py-0.5 rounded font-mono text-[10px] bg-stone-100 text-slate-600 border border-stone-200">
                              {c.baseline_decision}
                            </span>
                          </td>
                          <td className="py-4 px-4 font-mono text-slate-600 whitespace-nowrap">
                            {c.decider_latency_ms} ms
                          </td>
                          <td className="py-4 px-4 text-center">
                            {c.is_correct ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                                <CheckCircle className="w-3 h-3 text-emerald-600" />
                                MATCH
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800">
                                <XCircle className="w-3 h-3 text-rose-600" />
                                MISMATCH
                              </span>
                            )}
                          </td>
                          <td className="py-4 px-4 text-center text-slate-400">
                            {isExpanded ? (
                              <ChevronUp className="w-4 h-4 mx-auto text-slate-600" />
                            ) : (
                              <ChevronDown className="w-4 h-4 mx-auto" />
                            )}
                          </td>
                        </tr>

                        {/* Expandable Explanation Details */}
                        {isExpanded && (
                          <tr className="bg-stone-50/60">
                            <td colSpan={9} className="py-4 px-6 border-b border-stone-100">
                              <div className="space-y-3 bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs">
                                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                                  <div className="flex items-center gap-2">
                                    <Sparkles className="w-4 h-4 text-amber-500" />
                                    <span className="font-bold text-slate-800">
                                      Decision Explanation & Rationale:
                                    </span>
                                  </div>
                                  <div className="flex items-center gap-4 text-slate-500 font-mono text-[11px]">
                                    <span>Decider Latency: <strong className="text-slate-800">{c.decider_latency_ms} ms</strong></span>
                                    <span>Bedrock Latency: <strong className="text-slate-800">{c.bedrock_latency_ms} ms</strong></span>
                                    <span>Confidence: <strong className="text-slate-800">{Math.round(c.decider_confidence * 100)}%</strong></span>
                                  </div>
                                </div>
                                <p className="text-xs text-slate-700 leading-relaxed font-sans">
                                  {c.explanation_preview}
                                </p>
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Test Conditions Card */}
          <div className="bg-white rounded-2xl border border-stone-200 shadow-sm p-6">
            <div className="flex items-center gap-2 pb-3 border-b border-stone-100 text-sm font-bold text-slate-900">
              <Calendar className="w-4 h-4 text-slate-500" />
              <span>Test Conditions & Evaluation Environment</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 pt-4 text-xs">
              <div>
                <span className="text-slate-400 uppercase tracking-wider text-[10px] font-semibold block">
                  Model Tested
                </span>
                <span className="font-mono font-bold text-slate-800 text-sm mt-0.5 block">
                  {results.test_conditions.model_tested}
                </span>
              </div>
              <div>
                <span className="text-slate-400 uppercase tracking-wider text-[10px] font-semibold block">
                  Confidence Threshold
                </span>
                <span className="font-mono font-bold text-slate-800 text-sm mt-0.5 block">
                  {Math.round(results.test_conditions.confidence_threshold * 100)}% Auto-Approval
                </span>
              </div>
              <div>
                <span className="text-slate-400 uppercase tracking-wider text-[10px] font-semibold block">
                  Deterministic Safety
                </span>
                <span className="font-semibold text-emerald-700 text-sm mt-0.5 block">
                  Strict Pre-Gate (Zero Violations)
                </span>
              </div>
              <div>
                <span className="text-slate-400 uppercase tracking-wider text-[10px] font-semibold block">
                  Run Timestamp
                </span>
                <span className="font-mono text-slate-600 text-xs mt-0.5 block">
                  {results.test_conditions.timestamp}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EvaluationPage;
