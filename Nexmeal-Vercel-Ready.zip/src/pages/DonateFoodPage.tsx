import React, { useState } from 'react';
import {
  Utensils,
  Clock,
  MapPin,
  ShieldAlert,
  Sparkles,
  CheckCircle2,
  Phone,
  Building,
  Thermometer,
  Layers,
  ArrowRight,
  Copy,
  Check,
  RotateCcw,
  Soup,
  Croissant,
  Carrot,
  Milk,
  Package,
  Calendar,
  AlertCircle
} from 'lucide-react';
import { api } from '../api/client';

interface Props {
  onSuccess: (donationId: string) => void;
}

export const DonateFoodPage: React.FC<Props> = ({ onSuccess }) => {
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);
  const [success, setSuccess] = useState<{
    id: string;
    code: string;
    title: string;
    quantity: string;
    donor: string;
  } | null>(null);

  // Form State with sensible defaults for quick testing
  const now = new Date();
  const defaultPrep = new Date(now.getTime() - 60 * 60 * 1000).toISOString().slice(0, 16);
  const defaultDeadline = new Date(now.getTime() + 3.5 * 60 * 60 * 1000).toISOString().slice(0, 16);

  const [form, setForm] = useState({
    donor_name: 'The Orchid Grand Hotel',
    donor_type: 'Restaurant',
    donor_contact: '+91 98450 99881',
    donor_address: '22 Residency Road, Ashok Nagar, Bengaluru',
    latitude: 12.9716,
    longitude: 77.5946,
    food_title: 'Surplus Banquet Rice, Dal Tadka & Mix Veg Curries',
    food_category: 'Cooked Meals',
    quantity_value: '35',
    quantity_unit: 'kg',
    storage_requirement: 'ROOM_TEMP',
    dietary_type: 'VEGETARIAN',
    preparation_time: defaultPrep,
    pickup_deadline: defaultDeadline,
    handling_instructions:
      'Kept warm in food-grade insulated catering containers. Ready for immediate pickup at loading bay 2.',
  });

  const categories = [
    { id: 'Cooked Meals', label: 'Cooked Meals', icon: Soup, desc: 'Hot trays, curries & rice' },
    { id: 'Bakery', label: 'Bakery & Bread', icon: Croissant, desc: 'Artisan loaves & pastries' },
    { id: 'Produce', label: 'Fresh Produce', icon: Carrot, desc: 'Fruits, veggies & greens' },
    { id: 'Dairy', label: 'Dairy & Desserts', icon: Milk, desc: 'Milk, cheese, yogurt' },
    { id: 'Packaged', label: 'Packaged / Dry', icon: Package, desc: 'Canned & boxed staples' },
  ];

  const storageOptions = [
    {
      id: 'ROOM_TEMP',
      label: 'Room Temp',
      temp: '20°C - 25°C',
      desc: 'Bakery, dry goods, fresh items',
    },
    {
      id: 'REFRIGERATED',
      label: 'Refrigerated',
      temp: '2°C - 5°C',
      desc: 'Dairy, prepped salads, meats',
    },
    {
      id: 'FROZEN',
      label: 'Deep Frozen',
      temp: '-18°C',
      desc: 'Frozen meals & ingredients',
    },
    {
      id: 'HOT_HOLDING',
      label: 'Hot Holding',
      temp: '> 60°C',
      desc: 'Insulated banquet chafing sets',
    },
  ];

  const dietaryOptions = [
    { id: 'VEGETARIAN', label: 'Vegetarian', badgeColor: 'border-emerald-600 text-emerald-700' },
    { id: 'NON_VEGETARIAN', label: 'Non-Vegetarian', badgeColor: 'border-rose-600 text-rose-700' },
    { id: 'VEGAN', label: '100% Vegan', badgeColor: 'border-teal-600 text-teal-700' },
    { id: 'EGGETARIAN', label: 'Eggetarian', badgeColor: 'border-amber-600 text-amber-700' },
  ];

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2500);
  };

  const handleReset = () => {
    const currentNow = new Date();
    setForm({
      donor_name: '',
      donor_type: 'Restaurant',
      donor_contact: '',
      donor_address: '',
      latitude: 12.9716,
      longitude: 77.5946,
      food_title: '',
      food_category: 'Cooked Meals',
      quantity_value: '',
      quantity_unit: 'kg',
      storage_requirement: 'ROOM_TEMP',
      dietary_type: 'VEGETARIAN',
      preparation_time: new Date(currentNow.getTime() - 60 * 60 * 1000).toISOString().slice(0, 16),
      pickup_deadline: new Date(currentNow.getTime() + 3.5 * 60 * 60 * 1000).toISOString().slice(0, 16),
      handling_instructions: '',
    });
    setSuccess(null);
    setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    try {
      // Validate deadline in future
      const prepDate = new Date(form.preparation_time);
      const deadlineDate = new Date(form.pickup_deadline);

      if (deadlineDate <= new Date()) {
        throw new Error('Pickup deadline must be in the future.');
      }
      if (deadlineDate <= prepDate) {
        throw new Error('Pickup deadline must be after preparation time.');
      }

      const created = await api.createDonation({
        ...form,
        quantity_value: Number(form.quantity_value) || 0,
        latitude: Number(form.latitude) || 12.9716,
        longitude: Number(form.longitude) || 77.5946,
        preparation_time: new Date(form.preparation_time).toISOString(),
        pickup_deadline: new Date(form.pickup_deadline).toISOString(),
      });

      const verificationCode =
        created.pickup_verification_code ||
        `FB-${Math.floor(1000 + Math.random() * 9000)}`;

      setSuccess({
        id: created.id,
        code: verificationCode,
        title: created.food_title || form.food_title,
        quantity: `${created.quantity_value || form.quantity_value} ${created.quantity_unit || form.quantity_unit}`,
        donor: created.donor_name || form.donor_name,
      });
    } catch (err: any) {
      setError(err.message || 'Failed to register donation.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-16">
      {/* Header Banner */}
      <div className="relative overflow-hidden bg-gradient-to-br from-white via-stone-50 to-emerald-50/40 p-6 sm:p-10 rounded-3xl border border-stone-200/80 shadow-sm backdrop-blur-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200/80 text-emerald-800 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>AI Surplus Rescue Pipeline</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight">
              Register Surplus Food
            </h1>
            <p className="text-sm sm:text-base text-slate-600 font-normal">
              Connect surplus food from your commercial kitchen, hotel, or cafeteria directly to verified shelters and community kitchens within minutes.
            </p>
          </div>

          <div className="hidden sm:flex w-16 h-16 rounded-3xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white items-center justify-center shadow-lg shadow-emerald-600/20 shrink-0">
            <Utensils className="w-8 h-8" />
          </div>
        </div>
      </div>

      {/* Error Alert */}
      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl flex items-start gap-3 text-rose-800 text-sm shadow-xs animate-shake">
          <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          <div>
            <h4 className="font-semibold text-rose-900">Validation Error</h4>
            <p className="mt-0.5 text-rose-700">{error}</p>
          </div>
        </div>
      )}

      {/* Success Modal / Banner */}
      {success && (
        <div className="p-8 bg-gradient-to-br from-emerald-50 via-teal-50 to-white border-2 border-emerald-500 rounded-3xl shadow-xl space-y-6">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-md shadow-emerald-600/30">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-900 tracking-tight">
                  Surplus Registered Successfully!
                </h3>
                <p className="text-xs text-slate-600 mt-0.5">
                  Decider 2B is ready to score recipient compatibility and optimize routing.
                </p>
              </div>
            </div>

            <button
              onClick={handleReset}
              className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1 font-medium px-3 py-1.5 rounded-lg border border-stone-200 bg-white shadow-xs"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Register Another</span>
            </button>
          </div>

          {/* Verification Code Showcase */}
          <div className="bg-white p-6 rounded-2xl border border-emerald-200/80 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-800">
                Pickup Handshake Verification Code
              </span>
              <p className="text-xs text-slate-500 mt-0.5">
                Share this secure one-time PIN with the verified driver upon food pickup.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="font-mono text-2xl sm:text-3xl font-extrabold tracking-widest text-emerald-700 bg-emerald-50 px-5 py-2.5 rounded-xl border border-emerald-200">
                {success.code}
              </div>
              <button
                type="button"
                onClick={() => handleCopyCode(success.code)}
                className="p-3 bg-stone-100 hover:bg-stone-200 text-slate-700 rounded-xl transition-colors cursor-pointer"
                title="Copy verification code"
              >
                {copiedCode ? (
                  <Check className="w-5 h-5 text-emerald-600" />
                ) : (
                  <Copy className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>

          {/* Summary Box */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs bg-white/70 p-4 rounded-xl border border-stone-200">
            <div>
              <span className="text-slate-400 block font-medium">Food Item</span>
              <span className="font-semibold text-slate-800 text-sm truncate block mt-0.5">
                {success.title}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block font-medium">Batch Quantity</span>
              <span className="font-semibold text-slate-800 text-sm block mt-0.5">
                {success.quantity}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block font-medium">Donor Facility</span>
              <span className="font-semibold text-slate-800 text-sm truncate block mt-0.5">
                {success.donor}
              </span>
            </div>
          </div>

          {/* Primary CTA button */}
          <button
            type="button"
            onClick={() => onSuccess(success.id)}
            className="w-full py-4 px-6 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-2xl text-base font-bold shadow-lg shadow-emerald-600/30 hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Sparkles className="w-5 h-5" />
            <span>Proceed to AI Matching & Route Optimization</span>
            <ArrowRight className="w-5 h-5 ml-1" />
          </button>
        </div>
      )}

      {/* Main Form (Swiggy/Zomato Card Style) */}
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Section 1: Donor Profile */}
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200/80 shadow-sm space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b border-stone-100">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <Building className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 tracking-tight">
                Donor & Dispatch Profile
              </h2>
              <p className="text-xs text-slate-500">
                Facility details for transport routing and pickup authorization.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Donor Entity / Business Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={form.donor_name}
                onChange={(e) => setForm({ ...form, donor_name: e.target.value })}
                className="w-full px-4 py-3 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none transition-all placeholder:text-slate-400"
                placeholder="e.g. The Grand Residency Hotel"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Donor Category / Facility Type <span className="text-rose-500">*</span>
              </label>
              <select
                value={form.donor_type}
                onChange={(e) => setForm({ ...form, donor_type: e.target.value })}
                className="w-full px-4 py-3 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none transition-all text-slate-800"
              >
                <option value="Restaurant">Restaurant / Bistro</option>
                <option value="Hostel">College / University Hostel</option>
                <option value="Wedding/Event">Wedding / Banquet Event</option>
                <option value="Cafeteria">Corporate Cafeteria</option>
                <option value="Supermarket">Supermarket / Grocery</option>
                <option value="Bakery">Commercial Bakery</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Contact Phone Number <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5 pointer-events-none" />
                <input
                  type="text"
                  required
                  value={form.donor_contact}
                  onChange={(e) => setForm({ ...form, donor_contact: e.target.value })}
                  className="w-full pl-10 pr-4 py-3 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none transition-all placeholder:text-slate-400"
                  placeholder="+91 98450 12345"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Pickup Address & Dispatch Dock <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5 pointer-events-none" />
                <input
                  type="text"
                  required
                  value={form.donor_address}
                  onChange={(e) => setForm({ ...form, donor_address: e.target.value })}
                  className="w-full pl-10 pr-4 py-3 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none transition-all placeholder:text-slate-400"
                  placeholder="Street address, gate or dock number"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Section 2: Food Particulars & Dietary */}
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200/80 shadow-sm space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b border-stone-100">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <Soup className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 tracking-tight">
                Food Details & Dietary Classification
              </h2>
              <p className="text-xs text-slate-500">
                Categorization and portion sizing for appropriate recipient matching.
              </p>
            </div>
          </div>

          {/* Item Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Food Item Title / Description <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={form.food_title}
              onChange={(e) => setForm({ ...form, food_title: e.target.value })}
              className="w-full px-4 py-3 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none transition-all placeholder:text-slate-400"
              placeholder="e.g. Steamed Basmati Rice, Paneer Butter Masala, Chapati"
            />
          </div>

          {/* Category Radio Cards */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-2">
              Food Category <span className="text-rose-500">*</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {categories.map((cat) => {
                const Icon = cat.icon;
                const isSelected = form.food_category === cat.id;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setForm({ ...form, food_category: cat.id })}
                    className={`p-3.5 rounded-2xl border text-left transition-all flex flex-col justify-between cursor-pointer ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50/70 shadow-sm ring-2 ring-emerald-600/20'
                        : 'border-stone-200 hover:border-stone-300 hover:bg-stone-50/60 bg-white'
                    }`}
                  >
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center mb-2 ${
                        isSelected
                          ? 'bg-emerald-600 text-white'
                          : 'bg-stone-100 text-slate-600'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="font-bold text-xs text-slate-900">{cat.label}</div>
                      <div className="text-[10px] text-slate-500 line-clamp-1 mt-0.5">
                        {cat.desc}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quantity & Dietary Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {/* Quantity */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Quantity & Measure <span className="text-rose-500">*</span>
              </label>
              <div className="flex gap-2">
                <input
                  type="number"
                  step="0.5"
                  min="0.5"
                  required
                  value={form.quantity_value}
                  onChange={(e) => setForm({ ...form, quantity_value: e.target.value })}
                  className="w-2/3 px-4 py-3 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none transition-all"
                  placeholder="35"
                />
                <select
                  value={form.quantity_unit}
                  onChange={(e) => setForm({ ...form, quantity_unit: e.target.value })}
                  className="w-1/3 px-3 py-3 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none transition-all text-slate-800 font-semibold"
                >
                  <option value="kg">kg</option>
                  <option value="servings">servings</option>
                  <option value="trays">trays</option>
                  <option value="boxes">boxes</option>
                </select>
              </div>
            </div>

            {/* Dietary Preference Cards */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Dietary Type <span className="text-rose-500">*</span>
              </label>
              <div className="grid grid-cols-2 gap-2">
                {dietaryOptions.map((opt) => {
                  const isSelected = form.dietary_type === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setForm({ ...form, dietary_type: opt.id })}
                      className={`px-3 py-2.5 rounded-xl border text-xs font-semibold flex items-center justify-between cursor-pointer transition-all ${
                        isSelected
                          ? 'border-slate-900 bg-slate-900 text-white shadow-xs'
                          : 'border-stone-200 hover:border-stone-300 bg-white text-slate-700'
                      }`}
                    >
                      <span>{opt.label}</span>
                      <span
                        className={`w-2 h-2 rounded-full ${
                          isSelected ? 'bg-emerald-400' : 'bg-stone-300'
                        }`}
                      />
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Section 3: Storage & Handling */}
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200/80 shadow-sm space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b border-stone-100">
            <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
              <Thermometer className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 tracking-tight">
                Storage & Food Handling
              </h2>
              <p className="text-xs text-slate-500">
                Safety temperature control requirements enforced by Decider 2B.
              </p>
            </div>
          </div>

          {/* Storage Requirement Radio Cards */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-2">
              Temperature & Storage Requirement <span className="text-rose-500">*</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              {storageOptions.map((opt) => {
                const isSelected = form.storage_requirement === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setForm({ ...form, storage_requirement: opt.id })}
                    className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50/70 shadow-sm ring-2 ring-emerald-600/20'
                        : 'border-stone-200 hover:border-stone-300 bg-white hover:bg-stone-50/60'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="font-bold text-xs text-slate-900">{opt.label}</div>
                      <span className="font-mono text-[10px] text-emerald-800 bg-emerald-100/80 px-1.5 py-0.5 rounded">
                        {opt.temp}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 mt-1 line-clamp-1">
                      {opt.desc}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Handling Instructions */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Special Handling Instructions & Container Notes
            </label>
            <textarea
              rows={3}
              value={form.handling_instructions}
              onChange={(e) => setForm({ ...form, handling_instructions: e.target.value })}
              className="w-full min-h-[100px] px-4 py-3 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none transition-all placeholder:text-slate-400"
              placeholder="e.g. In stainless steel containers with sealed lids; recipient should bring food-grade carriers..."
            />
          </div>
        </div>

        {/* Section 4: Time Critical Windows */}
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200/80 shadow-sm space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b border-stone-100">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 tracking-tight">
                Timing & Safety Expiration Windows
              </h2>
              <p className="text-xs text-slate-500">
                Precision timestamps for safe food transfer and temperature hazard reduction.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Preparation Timestamp (When Prepared) <span className="text-rose-500">*</span>
              </label>
              <input
                type="datetime-local"
                required
                value={form.preparation_time}
                onChange={(e) => setForm({ ...form, preparation_time: e.target.value })}
                className="w-full px-4 py-3 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none transition-all text-slate-800"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                Food must not exceed 4 hours at ambient temperature.
              </span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Safe Pickup Deadline <span className="text-rose-500">*</span>
              </label>
              <input
                type="datetime-local"
                required
                value={form.pickup_deadline}
                onChange={(e) => setForm({ ...form, pickup_deadline: e.target.value })}
                className="w-full px-4 py-3 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none transition-all text-slate-800"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                Target collection cutoff before safety degradation.
              </span>
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={submitting}
            className="w-full py-4 px-6 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-2xl text-base font-bold shadow-lg shadow-emerald-600/25 hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-2.5 disabled:opacity-50 cursor-pointer"
          >
            {submitting ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Validating Safety & Registering Batch...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                <span>Submit Surplus & Run AI Match Evaluation</span>
                <ArrowRight className="w-5 h-5" />
              </>
            )}
          </button>
          <p className="text-center text-xs text-slate-400 mt-3 font-normal">
            By submitting, you confirm food was prepared according to FSSAI / local health standards.
          </p>
        </div>
      </form>
    </div>
  );
};
