import React, { useState } from 'react';
import { 
  Building2, 
  PlusCircle, 
  UtensilsCrossed, 
  CheckCircle, 
  Clock, 
  Truck, 
  Sparkles, 
  Copy, 
  Check, 
  ArrowRight,
  TrendingUp,
  MapPin,
  Calendar
} from 'lucide-react';
import { Donation, UserProfile } from '../types';
import { StatusBadge } from '../components/StatusBadge';

interface Props {
  donations: Donation[];
  currentUser: UserProfile;
  onNavigate: (tab: string, contextId?: string) => void;
  onOpenDonateModal: () => void;
  onSelectDonation: (donation: Donation) => void;
}

export const DonorDashboardPage: React.FC<Props> = ({
  donations,
  currentUser,
  onNavigate,
  onOpenDonateModal,
  onSelectDonation,
}) => {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  // Filter donations for this donor or all if not matched
  const donorDonations = donations.filter((d) => 
    !currentUser.entityName || d.donor_name.toLowerCase().includes(currentUser.entityName.toLowerCase()) || true
  );

  const completed = donorDonations.filter((d) => d.status === 'COLLECTED');
  const activePipeline = donorDonations.filter((d) => 
    d.status === 'PROPOSED' || d.status === 'MATCHED' || d.status === 'ACCEPTED' || d.status === 'IN_TRANSIT'
  );

  const totalKgDonated = completed.reduce((sum, d) => sum + d.quantity_value, 0);
  const mealsGenerated = Math.floor(totalKgDonated / 0.4);

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  return (
    <div className="space-y-8 pb-12 animate-fade-in">
      {/* Donor Banner Header */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200/80 shadow-subtle flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-100 text-blue-800 text-xs font-bold">
            <Building2 className="w-3.5 h-3.5" />
            <span>Donor Operations Hub • {currentUser.entityName}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold font-display text-stone-900 tracking-tight">
            Surplus Dispatch & ESG Contribution
          </h1>
          <p className="text-xs sm:text-sm text-stone-500 max-w-xl">
            Monitor active surplus batches, view real-time Strands Decider 2B matching to vetted NGOs, and track courier collection.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onOpenDonateModal}
            className="flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-[#103B2D] hover:bg-[#0B261D] text-white text-xs font-bold shadow-card transition-all hover:-translate-y-0.5"
          >
            <PlusCircle className="w-4 h-4 text-emerald-300" />
            <span>Register Surplus Food</span>
          </button>
        </div>
      </div>

      {/* Donor Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-subtle space-y-1">
          <div className="flex items-center justify-between text-stone-400 text-xs font-bold uppercase tracking-wider">
            <span>Verified Rescued Food</span>
            <UtensilsCrossed className="w-4 h-4 text-emerald-700" />
          </div>
          <div className="text-3xl font-bold font-display text-[#103B2D] pt-1">
            {totalKgDonated.toFixed(0)} <span className="text-sm font-normal text-stone-400">kg</span>
          </div>
          <p className="text-[11px] text-stone-500">Across {completed.length} completed physical collections</p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-subtle space-y-1">
          <div className="flex items-center justify-between text-stone-400 text-xs font-bold uppercase tracking-wider">
            <span>Wholesome Meals Created</span>
            <CheckCircle className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-3xl font-bold font-display text-amber-600 pt-1">
            {mealsGenerated} <span className="text-sm font-normal text-stone-400">meals</span>
          </div>
          <p className="text-[11px] text-stone-500">Delivered directly to local shelters & kitchens</p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-subtle space-y-1">
          <div className="flex items-center justify-between text-stone-400 text-xs font-bold uppercase tracking-wider">
            <span>Active Surplus In Pipeline</span>
            <Clock className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-3xl font-bold font-display text-teal-700 pt-1">
            {activePipeline.length} <span className="text-sm font-normal text-stone-400">batches</span>
          </div>
          <p className="text-[11px] text-stone-500">Routing or scheduled for courier arrival</p>
        </div>
      </div>

      {/* Active Surplus Consignments */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200/80 shadow-subtle space-y-6">
        <div className="flex items-center justify-between border-b border-stone-100 pb-4">
          <div>
            <h2 className="text-lg font-bold font-display text-stone-900">
              Registered Surplus Batches
            </h2>
            <p className="text-xs text-stone-500">Real-time status tracking and pickup handshake codes</p>
          </div>
          <button
            onClick={() => onNavigate('donate')}
            className="text-xs font-bold text-emerald-800 hover:text-emerald-950 flex items-center gap-1"
          >
            <span>New Batch</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {donorDonations.length === 0 ? (
          <div className="p-8 text-center text-stone-400 text-xs space-y-3">
            <p>No donation consignments currently registered.</p>
            <button
              onClick={onOpenDonateModal}
              className="px-4 py-2 rounded-xl bg-stone-900 text-white text-xs font-semibold"
            >
              Register First Surplus Batch
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {donorDonations.map((don) => {
              const hoursRemaining = Math.max(
                0,
                (new Date(don.pickup_deadline).getTime() - new Date().getTime()) / (3600 * 1000)
              );

              return (
                <div
                  key={don.id}
                  className="p-5 rounded-2xl bg-[#FAFAF6] border border-stone-200/80 hover:border-stone-300 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="flex items-start gap-4">
                    <img
                      src={don.image_url || 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80'}
                      alt={don.food_title}
                      className="w-16 h-16 rounded-xl object-cover shrink-0 border border-stone-200"
                    />
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-bold font-display text-sm text-stone-900">{don.food_title}</h3>
                        <StatusBadge status={don.status} />
                      </div>
                      <div className="flex items-center gap-3 text-xs text-stone-500 flex-wrap">
                        <span>Quantity: <strong>{don.quantity_value} {don.quantity_unit}</strong></span>
                        <span>•</span>
                        <span>Category: <strong>{don.food_category}</strong></span>
                        <span>•</span>
                        <span>Window: <strong>{hoursRemaining > 0 ? `${hoursRemaining.toFixed(1)}h left` : 'Expired'}</strong></span>
                      </div>
                      <p className="text-[11px] text-stone-400 flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-stone-400" />
                        <span>{don.donor_address}</span>
                      </p>
                    </div>
                  </div>

                  {/* Actions & Verification Code */}
                  <div className="flex items-center gap-3 shrink-0 self-end md:self-center">
                    {don.pickup_verification_code && (
                      <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-xl border border-stone-200 shadow-xs">
                        <div className="text-right">
                          <span className="text-[9px] font-bold text-stone-400 uppercase block tracking-wider">Handover OTP</span>
                          <span className="text-sm font-mono font-bold text-[#103B2D] tracking-wider">
                            {don.pickup_verification_code}
                          </span>
                        </div>
                        <button
                          onClick={() => handleCopy(don.pickup_verification_code!)}
                          className="p-1 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100"
                          title="Copy Handover Code"
                        >
                          {copiedCode === don.pickup_verification_code ? (
                            <Check className="w-4 h-4 text-emerald-600" />
                          ) : (
                            <Copy className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    )}

                    <button
                      onClick={() => onSelectDonation(don)}
                      className="px-3.5 py-2 rounded-xl border border-stone-300 text-stone-700 hover:bg-white text-xs font-semibold transition-colors"
                    >
                      Inspect
                    </button>

                    {don.status === 'PROPOSED' && (
                      <button
                        onClick={() => onNavigate('matches', don.id)}
                        className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#103B2D] hover:bg-[#0B261D] text-white text-xs font-bold shadow-xs transition-colors"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
                        <span>Match AI</span>
                      </button>
                    )}

                    {don.status === 'ACCEPTED' && (
                      <button
                        onClick={() => onNavigate('pickups', don.id)}
                        className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs transition-colors"
                      >
                        <Truck className="w-3.5 h-3.5" />
                        <span>Track Driver</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
