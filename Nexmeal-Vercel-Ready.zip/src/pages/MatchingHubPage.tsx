import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  MapPin, 
  Clock, 
  Truck, 
  ShieldCheck, 
  ShieldX, 
  ArrowRight, 
  Zap, 
  Brain,
  RotateCw,
  Building2,
  Check,
  Snowflake,
  Info,
  CheckCircle2,
  Copy,
  Terminal,
  Activity,
  FileCode,
  AlertOctagon,
  HelpCircle,
  Shuffle,
  Shield,
  KeyRound,
  Layers,
  ChevronRight,
  TrendingUp,
  Cpu
} from 'lucide-react';
import { 
  Donation, 
  MatchCandidate, 
  DecisionEngineResult, 
  AdaptationScenario, 
  CandidateActionType 
} from '../types';
import { api } from '../api/client';
import { StatusBadge } from '../components/StatusBadge';
import { DecisionBadge } from '../components/DecisionBadge';

interface Props {
  initialDonationId?: string;
  onNavigate: (tab: string, id?: string) => void;
}

export const MatchingHubPage: React.FC<Props> = ({ initialDonationId, onNavigate }) => {
  const [donations, setDonations] = useState<Donation[]>([]);
  const [selectedDonationId, setSelectedDonationId] = useState<string>(initialDonationId || '');
  const [engineResult, setEngineResult] = useState<DecisionEngineResult | null>(null);
  const [activeScenario, setActiveScenario] = useState<AdaptationScenario>('NORMAL');
  const [evaluating, setEvaluating] = useState<boolean>(false);
  const [accepting, setAccepting] = useState<string | null>(null);
  const [acceptResult, setAcceptResult] = useState<{ code?: string; message: string; donationId?: string } | null>(null);
  const [activeTerminalTab, setActiveTerminalTab] = useState<'logs' | 'vector'>('logs');
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [copiedVector, setCopiedVector] = useState<boolean>(false);
  const [actionExecuted, setActionExecuted] = useState<string | null>(null);

  // Load donations
  useEffect(() => {
    api.listDonations().then((dons) => {
      setDonations(dons);
      if (!selectedDonationId && dons.length > 0) {
        // Prioritize proposed or active donations
        const active = dons.find((d) => d.status === 'PROPOSED' || d.status === 'MATCHED') || dons[0];
        setSelectedDonationId(active.id);
      }
    }).catch((err) => {
      console.error('Failed to load donations:', err);
    });
  }, []);

  useEffect(() => {
    if (initialDonationId) {
      setSelectedDonationId(initialDonationId);
    }
  }, [initialDonationId]);

  // Execute AI Decision Engine
  const runDecisionEngine = async (donId: string, scenario: AdaptationScenario = activeScenario) => {
    if (!donId) return;
    try {
      setEvaluating(true);
      setAcceptResult(null);
      setActionExecuted(null);
      const result = await api.evaluateDecisionEngine(donId, scenario);
      setEngineResult(result);
    } catch (err: any) {
      console.error('Failed to run AI Decision Engine:', err);
    } finally {
      setEvaluating(false);
    }
  };

  useEffect(() => {
    if (selectedDonationId) {
      runDecisionEngine(selectedDonationId, activeScenario);
    }
  }, [selectedDonationId, activeScenario]);

  // Handle Scenario Switch
  const handleSelectScenario = (scenario: AdaptationScenario) => {
    setActiveScenario(scenario);
    setActionExecuted(null);
  };

  // Handle Accept or Next Step execution
  const handleExecuteNextStep = async () => {
    if (!engineResult) return;
    const { nextStep, selectedCandidate } = engineResult;
    
    if (nextStep.actionType === 'NAVIGATE_REVIEW_QUEUE') {
      onNavigate('reviews');
      return;
    }
    
    if (nextStep.actionType === 'REQUEST_DATA') {
      setActionExecuted('Automated push notification & SMS dispatched to donor requesting holding temperature and prep time.');
      return;
    }

    if (nextStep.actionType === 'VIEW_AUDIT') {
      onNavigate('donor');
      return;
    }

    if (selectedCandidate) {
      try {
        setAccepting(selectedCandidate.id);
        const res = await api.acceptMatch(selectedCandidate.id);
        setAcceptResult({
          code: nextStep.otpCode || res.pickup_verification_code,
          message: res.message || `Surplus allocation verified for ${selectedCandidate.recipient.name}!`,
          donationId: selectedDonationId,
        });
        setActionExecuted(`Handover Protocol Confirmed: Logistics slot locked with code ${nextStep.otpCode || res.pickup_verification_code}.`);
      } catch (err: any) {
        alert(`Error executing dispatch: ${err.message || 'Unknown error'}`);
      } finally {
        setAccepting(null);
      }
    }
  };

  const copyToClipboard = (text: string, type: 'code' | 'vector') => {
    navigator.clipboard.writeText(text);
    if (type === 'code') {
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    } else {
      setCopiedVector(true);
      setTimeout(() => setCopiedVector(false), 2000);
    }
  };

  const currentDonation = donations.find((d) => d.id === selectedDonationId);

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-16 font-sans">
      {/* 1. Decision Center Header & Engine Telemetry */}
      <div className="bg-white rounded-3xl border border-stone-200/90 p-6 sm:p-8 shadow-sm relative overflow-hidden">
        {/* Subtle accent glow */}
        <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-emerald-500/5 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-96 h-96 rounded-full bg-amber-500/5 blur-3xl pointer-events-none" />

        <div className="relative flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="space-y-2.5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold">
                <Brain className="w-3.5 h-3.5 text-emerald-600 animate-pulse" />
                <span>Strands Decider 2B • Policy Classification Engine</span>
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-stone-100 border border-stone-200 text-slate-700 text-xs font-mono font-medium">
                <Zap className="w-3 h-3 text-amber-500" />
                <span>Inference: {engineResult?.telemetry.decider_latency_ms || 3.2} ms</span>
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-stone-100 border border-stone-200 text-slate-700 text-xs font-mono font-medium">
                <Cpu className="w-3 h-3 text-cyan-600" />
                <span>Bedrock Latency: {engineResult?.telemetry.bedrock_latency_ms || 46.5} ms</span>
              </span>
            </div>

            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900">
              AI Decision Center
            </h1>
            <p className="text-sm sm:text-base text-slate-600 max-w-2xl leading-relaxed">
              Transparent, visible food-rescue decisioning. Inspect candidate action spaces, deterministic safety gates, 
              multi-axis policy factor weights, and real-time execution logs.
            </p>
          </div>

          {/* Consignment Selector & Run Trigger */}
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <div className="bg-stone-50 border border-stone-200 rounded-2xl p-2 flex items-center gap-2 shadow-xs">
              <span className="text-xs font-semibold text-slate-500 pl-1">Target Surplus:</span>
              <select
                value={selectedDonationId}
                onChange={(e) => setSelectedDonationId(e.target.value)}
                className="bg-white border border-stone-200 text-slate-800 text-xs sm:text-sm font-semibold rounded-xl px-3 py-2 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none max-w-xs truncate"
              >
                {donations.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.food_title} ({d.quantity_value} {d.quantity_unit}) - [{d.status}]
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={() => runDecisionEngine(selectedDonationId, activeScenario)}
              disabled={evaluating || !selectedDonationId}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-semibold text-sm shadow-sm hover:shadow-md transition-all duration-300 disabled:opacity-50"
            >
              <RotateCw className={`w-4 h-4 ${evaluating ? 'animate-spin' : ''}`} />
              <span>{evaluating ? 'Evaluating Engine...' : 'Re-Run Decider 2B'}</span>
            </button>
          </div>
        </div>

        {/* Selected Donation Metadata Bar */}
        {currentDonation && (
          <div className="mt-6 pt-5 border-t border-stone-100 flex flex-wrap items-center justify-between gap-4 text-xs">
            <div className="flex items-center gap-3">
              <span className="font-bold text-slate-900 text-sm truncate max-w-md">{currentDonation.food_title}</span>
              <StatusBadge status={currentDonation.status} />
              <span className="text-slate-500 hidden sm:inline">•</span>
              <span className="text-slate-600 hidden sm:inline">{currentDonation.donor_name} ({currentDonation.donor_address})</span>
            </div>
            <div className="flex items-center gap-4 text-slate-600">
              <span className="font-semibold text-slate-900">{currentDonation.quantity_value} {currentDonation.quantity_unit}</span>
              <span>•</span>
              <span className="inline-flex items-center gap-1">
                <Snowflake className="w-3.5 h-3.5 text-cyan-600" />
                {currentDonation.storage_requirement}
              </span>
              <span>•</span>
              <span>Deadline: {new Date(currentDonation.pickup_deadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
          </div>
        )}
      </div>

      {/* 2. PILLAR 2: DYNAMIC SITUATION SIMULATOR (AN AGENT THAT ADAPTS) */}
      <div className="bg-gradient-to-br from-stone-900 via-slate-900 to-stone-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl border border-stone-800 relative overflow-hidden">
        {/* Glow indicator */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="space-y-4 relative">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/30 text-emerald-300 text-xs font-semibold mb-2">
                <Shuffle className="w-3.5 h-3.5 animate-spin" style={{ animationDuration: '6s' }} />
                <span>Pillar 2: Dynamic Situational Adaptation</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
                <span>Agent Adaptation Simulator</span>
              </h2>
              <p className="text-xs sm:text-sm text-stone-300 mt-1 max-w-2xl leading-relaxed">
                Test how the agent reacts to live disruptions. When an NGO declines, traffic delays arrival, or data is missing, 
                watch the agent autonomously pivot to a safe alternative rather than blindly repeating its first answer.
              </p>
            </div>

            <div className="flex items-center gap-2 self-start md:self-auto">
              <span className="text-xs text-stone-400 font-mono">Agent Status:</span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>Live Adaptive Loop Active</span>
              </span>
            </div>
          </div>

          {/* Interactive Simulation Triggers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
            {/* Scenario 1: Normal */}
            <button
              onClick={() => handleSelectScenario('NORMAL')}
              className={`p-4 rounded-2xl text-left border transition-all duration-200 flex flex-col justify-between gap-3 ${
                activeScenario === 'NORMAL'
                  ? 'bg-emerald-950/60 border-emerald-400 ring-2 ring-emerald-400/20 text-white shadow-lg shadow-emerald-950/50'
                  : 'bg-stone-800/60 border-stone-700/80 hover:bg-stone-800 text-stone-300'
              }`}
            >
              <div className="flex items-center justify-between w-full">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">Baseline</span>
                {activeScenario === 'NORMAL' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
              </div>
              <div>
                <p className="font-semibold text-sm text-white">Normal Baseline</p>
                <p className="text-xs text-stone-400 mt-1 leading-relaxed">
                  All systems nominal. Ample pickup buffer, verified partner available.
                </p>
              </div>
              <span className="text-[11px] font-mono text-emerald-300/80">Expected: APPROVE</span>
            </button>

            {/* Scenario 2: NGO Declines */}
            <button
              onClick={() => handleSelectScenario('NGO_DECLINED')}
              className={`p-4 rounded-2xl text-left border transition-all duration-200 flex flex-col justify-between gap-3 ${
                activeScenario === 'NGO_DECLINED'
                  ? 'bg-amber-950/70 border-amber-400 ring-2 ring-amber-400/20 text-white shadow-lg shadow-amber-950/50'
                  : 'bg-stone-800/60 border-stone-700/80 hover:bg-stone-800 text-stone-300'
              }`}
            >
              <div className="flex items-center justify-between w-full">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-400">Dynamic Fallback</span>
                {activeScenario === 'NGO_DECLINED' && <CheckCircle2 className="w-4 h-4 text-amber-400" />}
              </div>
              <div>
                <p className="font-semibold text-sm text-white">Primary NGO Declines</p>
                <p className="text-xs text-stone-400 mt-1 leading-relaxed">
                  Van breakdown at Robin Hood Army. Agent immediately falls back to 2nd-best NGO.
                </p>
              </div>
              <span className="text-[11px] font-mono text-amber-300/80">Action: ROUTE_SECONDARY</span>
            </button>

            {/* Scenario 3: Traffic Delay */}
            <button
              onClick={() => handleSelectScenario('TRAFFIC_DELAY')}
              className={`p-4 rounded-2xl text-left border transition-all duration-200 flex flex-col justify-between gap-3 ${
                activeScenario === 'TRAFFIC_DELAY'
                  ? 'bg-orange-950/70 border-orange-400 ring-2 ring-orange-400/20 text-white shadow-lg shadow-orange-950/50'
                  : 'bg-stone-800/60 border-stone-700/80 hover:bg-stone-800 text-stone-300'
              }`}
            >
              <div className="flex items-center justify-between w-full">
                <span className="text-xs font-bold uppercase tracking-wider text-orange-400">Risk Escalation</span>
                {activeScenario === 'TRAFFIC_DELAY' && <CheckCircle2 className="w-4 h-4 text-orange-400" />}
              </div>
              <div>
                <p className="font-semibold text-sm text-white">Pickup Traffic Delay</p>
                <p className="text-xs text-stone-400 mt-1 leading-relaxed">
                  Ring Road gridlock shrinks pickup window to 40 mins. Agent stops blind dispatch.
                </p>
              </div>
              <span className="text-[11px] font-mono text-orange-300/80">Action: ESCALATE_HUMAN_REVIEW</span>
            </button>

            {/* Scenario 4: Missing Information */}
            <button
              onClick={() => handleSelectScenario('MISSING_DATA')}
              className={`p-4 rounded-2xl text-left border transition-all duration-200 flex flex-col justify-between gap-3 ${
                activeScenario === 'MISSING_DATA'
                  ? 'bg-rose-950/70 border-rose-400 ring-2 ring-rose-400/20 text-white shadow-lg shadow-rose-950/50'
                  : 'bg-stone-800/60 border-stone-700/80 hover:bg-stone-800 text-stone-300'
              }`}
            >
              <div className="flex items-center justify-between w-full">
                <span className="text-xs font-bold uppercase tracking-wider text-rose-400">Safety Quarantine</span>
                {activeScenario === 'MISSING_DATA' && <CheckCircle2 className="w-4 h-4 text-rose-400" />}
              </div>
              <div>
                <p className="font-semibold text-sm text-white">Missing Safety Data</p>
                <p className="text-xs text-stone-400 mt-1 leading-relaxed">
                  Donor omitted storage requirement & prep time. Section 6 rule quarantines listing.
                </p>
              </div>
              <span className="text-[11px] font-mono text-rose-300/80">Action: HOLD_FOR_MISSING_DATA</span>
            </button>
          </div>

          {/* Active Scenario Banner */}
          {engineResult && (
            <div className="mt-2 p-3.5 rounded-xl bg-stone-800/80 border border-stone-700 flex items-start gap-3 text-xs">
              <Activity className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div className="space-y-0.5">
                <span className="font-semibold text-white">Simulation Scenario Active:</span>{' '}
                <span className="text-stone-300">{engineResult.scenarioDescription}</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 3. PILLAR 1: VISIBLE AI DECISION ENGINE (CANDIDATE ACTION SPACE) */}
      {engineResult && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">
                <Layers className="w-3.5 h-3.5 text-emerald-600" />
                <span>Pillar 1: Available Action Space</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
                Candidate Actions Matrix
              </h2>
              <p className="text-xs sm:text-sm text-slate-500">
                All potential operational actions evaluated by the agent's policy arbitration engine.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500 font-medium">Selected Policy Action:</span>
              <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 font-mono text-xs font-bold border border-emerald-300">
                {engineResult.selectedAction}
              </span>
            </div>
          </div>

          {/* Action Space Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {engineResult.candidateActions.map((cand) => {
              const isSelected = cand.status === 'SELECTED';
              const isDisqualified = cand.status === 'DISQUALIFIED';

              return (
                <div
                  key={cand.action}
                  className={`p-5 rounded-3xl border transition-all duration-300 relative flex flex-col justify-between ${
                    isSelected
                      ? 'bg-gradient-to-b from-emerald-50/90 to-teal-50/40 border-emerald-400 shadow-md ring-2 ring-emerald-500/20'
                      : isDisqualified
                      ? 'bg-stone-50/60 border-stone-200/60 opacity-60'
                      : 'bg-white border-stone-200 hover:border-stone-300 shadow-xs'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="font-mono text-[11px] font-bold tracking-wider text-slate-500 uppercase truncate">
                        {cand.action}
                      </span>
                      {isSelected ? (
                        <span className="px-2.5 py-0.5 rounded-full bg-emerald-600 text-white font-bold text-[10px] tracking-wide uppercase shadow-xs flex items-center gap-1">
                          <Check className="w-3 h-3" />
                          <span>Selected</span>
                        </span>
                      ) : isDisqualified ? (
                        <span className="px-2 py-0.5 rounded-full bg-stone-200 text-slate-600 font-medium text-[10px] uppercase">
                          Disqualified
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-medium text-[10px] uppercase">
                          Candidate
                        </span>
                      )}
                    </div>

                    <h3 className={`text-base font-bold tracking-tight mb-2 ${isSelected ? 'text-emerald-950' : 'text-slate-800'}`}>
                      {cand.label}
                    </h3>

                    <p className="text-xs text-slate-600 leading-relaxed mb-4">
                      {cand.reason}
                    </p>
                  </div>

                  {/* Preference Score Bar */}
                  {cand.score !== undefined && (
                    <div className="pt-3 border-t border-stone-200/60">
                      <div className="flex items-center justify-between text-[11px] mb-1">
                        <span className="text-slate-500 font-medium">Policy Confidence</span>
                        <span className="font-mono font-bold text-slate-800">
                          {Math.round(cand.score * 100)}%
                        </span>
                      </div>
                      <div className="h-1.5 w-full bg-stone-200 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-500 ${
                            isSelected
                              ? 'bg-emerald-600'
                              : isDisqualified
                              ? 'bg-stone-300'
                              : 'bg-slate-400'
                          }`}
                          style={{ width: `${Math.round(cand.score * 100)}%` }}
                        />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 4. SELECTED DECISION & MULTI-TIER EXPLANATION HERO CARD */}
      {engineResult && (
        <div className="bg-white rounded-3xl border border-stone-200 p-6 sm:p-8 shadow-sm space-y-8">
          {/* Main Selected Decision Banner */}
          <div className="p-6 rounded-2xl bg-gradient-to-r from-stone-50 via-stone-50 to-emerald-50/30 border border-stone-200 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <DecisionBadge
                  decision={engineResult.selectedDecision}
                  confidence={engineResult.confidence}
                />
                <span className="text-xs text-slate-500 font-mono">
                  Confidence: {Math.round(engineResult.confidence * 100)}% (tau = 0.72)
                </span>
              </div>

              <h3 className="text-2xl font-bold tracking-tight text-slate-900">
                {engineResult.selectedDecision === 'APPROVE' && engineResult.selectedCandidate
                  ? `Approved for Dispatch: ${engineResult.selectedCandidate.recipient.name}`
                  : engineResult.selectedDecision === 'HUMAN_REVIEW'
                  ? 'Coordinator Review Required (Urgent Pickup Window)'
                  : 'Consignment Quarantined / Safety Violation'}
              </h3>

              {engineResult.selectedCandidate && (
                <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600">
                  <span className="inline-flex items-center gap-1 font-semibold text-slate-800">
                    <Building2 className="w-3.5 h-3.5 text-slate-500" />
                    {engineResult.selectedCandidate.recipient.organization_type}
                  </span>
                  <span>•</span>
                  <span className="inline-flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-500" />
                    {engineResult.selectedCandidate.distance_km.toFixed(1)} km away
                  </span>
                  <span>•</span>
                  <span className="inline-flex items-center gap-1">
                    <Truck className="w-3.5 h-3.5 text-slate-500" />
                    {engineResult.selectedCandidate.recipient.has_transportation ? 'Fleet Transport Ready' : 'Local Handover'}
                  </span>
                </div>
              )}
            </div>

            {/* Quick Action Button in Hero */}
            <div className="shrink-0 flex items-center">
              <button
                onClick={handleExecuteNextStep}
                disabled={accepting !== null}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm shadow-md shadow-emerald-600/20 hover:shadow-lg transition-all"
              >
                <span>{engineResult.nextStep.actionLabel}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Action Executed Banner */}
          {actionExecuted && (
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-900 flex items-center gap-3 text-xs sm:text-sm animate-fade-in">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span className="font-semibold">{actionExecuted}</span>
            </div>
          )}

          {/* Bedrock Dispatch Explanation Blockquote */}
          <div className="rounded-2xl bg-stone-50 border border-stone-200/80 p-5 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-500">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>Amazon Bedrock Natural Language Rationale</span>
            </div>
            <p className="text-sm text-slate-700 italic leading-relaxed">
              "{engineResult.explanation}"
            </p>
            <div className="pt-2 text-xs font-mono text-slate-500">
              Generated Notification: <span className="font-sans text-slate-600">{engineResult.notification}</span>
            </div>
          </div>

          {/* Multi-Tier Explanation: 7 Deterministic Safety Gates */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-lg font-bold tracking-tight text-slate-900 flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-600" />
                  <span>The 7 Deterministic Safety Guardrails</span>
                </h4>
                <p className="text-xs text-slate-500">
                  Strict physical constraints that hard-block allocation before AI ranking. Zero tolerance for violations.
                </p>
              </div>

              <span className={`px-3 py-1 rounded-full text-xs font-bold border ${
                engineResult.deterministicSafetyPassed
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                  : 'bg-rose-50 text-rose-800 border-rose-200'
              }`}>
                {engineResult.deterministicSafetyPassed ? 'ALL 7 GATES PASSED' : 'SAFETY GATE TRIPPED'}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
              {Object.entries(engineResult.safetyGates).map(([key, gate]) => (
                <div
                  key={key}
                  className={`p-3.5 rounded-2xl border transition-all ${
                    gate.passed
                      ? 'bg-white border-emerald-200/70 hover:border-emerald-300'
                      : 'bg-rose-50/60 border-rose-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[11px] font-bold text-slate-700 truncate">{gate.label}</span>
                    {gate.passed ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 leading-snug">
                    {gate.detail}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Strands Decider 2B Multi-Axis Factor Weighting */}
          <div className="space-y-4 pt-4 border-t border-stone-100">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-lg font-bold tracking-tight text-slate-900 flex items-center gap-2">
                  <Cpu className="w-5 h-5 text-teal-600" />
                  <span>Strands Decider 2B Multi-Axis Policy Weights</span>
                </h4>
                <p className="text-xs text-slate-500">
                  Each axis is weighted at 25%. A aggregate score &ge; 0.72 permits autonomous dispatch.
                </p>
              </div>

              <span className="text-xs font-mono font-bold text-slate-700">
                Total Score: {(engineResult.confidence * 100).toFixed(1)}%
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {engineResult.policyWeights.map((pw) => (
                <div key={pw.name} className="p-4 rounded-2xl bg-stone-50 border border-stone-200/70 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-800">{pw.name}</span>
                    <span className="font-mono text-slate-500">
                      Score: {Math.round(pw.score * 100)}% &times; {(pw.weight * 100).toFixed(0)}% = +{(pw.contribution * 100).toFixed(1)}%
                    </span>
                  </div>
                  <div className="h-2 w-full bg-stone-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full transition-all duration-500"
                      style={{ width: `${Math.round(pw.score * 100)}%` }}
                    />
                  </div>
                  <p className="text-[11px] text-slate-500">{pw.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* 5. ACTIONABLE NEXT STEP COMPONENT */}
          <div className="p-6 rounded-3xl bg-gradient-to-br from-stone-900 to-slate-900 text-white border border-stone-800 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                  Execution Pipeline • Next Step
                </span>
                <h4 className="text-xl font-bold tracking-tight text-white mt-0.5">
                  {engineResult.nextStep.title}
                </h4>
                <p className="text-xs sm:text-sm text-stone-300 mt-1 max-w-2xl leading-relaxed">
                  {engineResult.nextStep.description}
                </p>
              </div>

              {/* OTP Code Display if available */}
              {engineResult.nextStep.otpCode && (
                <div className="flex items-center gap-2 bg-stone-800/90 border border-stone-700 px-4 py-2.5 rounded-2xl shrink-0">
                  <KeyRound className="w-4 h-4 text-emerald-400" />
                  <div className="text-left">
                    <span className="block text-[10px] uppercase tracking-wider text-stone-400 font-semibold">Handover OTP</span>
                    <span className="font-mono text-xl font-extrabold text-emerald-300 tracking-widest">
                      {engineResult.nextStep.otpCode}
                    </span>
                  </div>
                  <button
                    onClick={() => copyToClipboard(engineResult.nextStep.otpCode!, 'code')}
                    className="p-1.5 text-stone-400 hover:text-white rounded-lg transition-colors ml-1"
                    title="Copy OTP"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                  {copiedCode && <span className="text-[10px] text-emerald-400">Copied!</span>}
                </div>
              )}
            </div>

            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                onClick={handleExecuteNextStep}
                disabled={accepting !== null}
                className="px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs tracking-wide uppercase transition-all shadow-md"
              >
                {engineResult.nextStep.actionLabel}
              </button>
              {engineResult.selectedDecision === 'APPROVE' && (
                <button
                  onClick={() => onNavigate('pickups', selectedDonationId)}
                  className="px-5 py-3 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 font-semibold text-xs transition-all"
                >
                  Track in Pickup Tracker
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 6. ACTUAL DECIDER OUTPUT & LIVE EXECUTION LOGS TERMINAL */}
      {engineResult && (
        <div className="bg-stone-950 rounded-3xl border border-stone-800 p-6 sm:p-7 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-stone-800 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-stone-800 text-emerald-400">
                <Terminal className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                  <span>Decider 2B Execution Logs & State Vector</span>
                  <span className="text-[10px] font-mono font-medium px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800">
                    Telemetry Active
                  </span>
                </h3>
                <p className="text-xs text-stone-400">
                  Inspect raw microsecond execution trace and input state vector passed to the decision engine.
                </p>
              </div>
            </div>

            {/* Toggle Terminal Tabs */}
            <div className="flex items-center gap-1 bg-stone-900 p-1 rounded-xl border border-stone-800 self-start">
              <button
                onClick={() => setActiveTerminalTab('logs')}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition-all ${
                  activeTerminalTab === 'logs'
                    ? 'bg-stone-800 text-emerald-400 shadow-xs'
                    : 'text-stone-400 hover:text-white'
                }`}
              >
                Execution Trace ({engineResult.executionLogs.length})
              </button>
              <button
                onClick={() => setActiveTerminalTab('vector')}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition-all ${
                  activeTerminalTab === 'vector'
                    ? 'bg-stone-800 text-emerald-400 shadow-xs'
                    : 'text-stone-400 hover:text-white'
                }`}
              >
                State Vector JSON
              </button>
            </div>
          </div>

          {/* Terminal Content */}
          {activeTerminalTab === 'logs' ? (
            <div className="space-y-2 max-h-80 overflow-y-auto pr-2 font-mono text-xs">
              {engineResult.executionLogs.map((log, idx) => (
                <div
                  key={idx}
                  className="flex items-start gap-3 p-2.5 rounded-xl bg-stone-900/60 border border-stone-800/80 hover:bg-stone-900 transition-colors"
                >
                  <span className="text-stone-500 text-[11px] shrink-0 font-bold">
                    +{log.elapsed_ms.toFixed(2)}ms
                  </span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold tracking-wider shrink-0 ${
                    log.phase === 'GATE_EVALUATION' ? 'bg-cyan-950 text-cyan-400 border border-cyan-800' :
                    log.phase === 'SPATIAL_INDEX' ? 'bg-indigo-950 text-indigo-400 border border-indigo-800' :
                    log.phase === 'POLICY_SCORING' ? 'bg-purple-950 text-purple-400 border border-purple-800' :
                    log.phase === 'ADAPTATION_TRIGGER' ? 'bg-amber-950 text-amber-400 border border-amber-800' :
                    log.phase === 'DECISION_ARBITRATION' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                    'bg-stone-800 text-stone-300'
                  }`}>
                    {log.phase}
                  </span>
                  <span className={`leading-relaxed ${
                    log.status === 'fail' ? 'text-rose-400 font-semibold' :
                    log.status === 'warn' ? 'text-amber-400 font-semibold' :
                    log.status === 'pass' ? 'text-emerald-300' :
                    'text-stone-300'
                  }`}>
                    {log.message}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="relative font-mono text-xs">
              <button
                onClick={() => copyToClipboard(JSON.stringify(engineResult.stateVector, null, 2), 'vector')}
                className="absolute top-3 right-3 p-2 rounded-lg bg-stone-800 text-stone-400 hover:text-white transition-colors"
                title="Copy JSON"
              >
                <Copy className="w-4 h-4" />
              </button>
              {copiedVector && (
                <span className="absolute top-4 right-12 text-[10px] text-emerald-400">Copied!</span>
              )}
              <pre className="p-4 rounded-2xl bg-stone-900 border border-stone-800 text-emerald-300 max-h-80 overflow-y-auto leading-relaxed">
                {JSON.stringify(engineResult.stateVector, null, 2)}
              </pre>
            </div>
          )}
        </div>
      )}

      {/* 7. ALL EVALUATED CANDIDATE RECIPIENTS BREAKDOWN */}
      {engineResult && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold tracking-tight text-slate-900">
                All Evaluated Recipient Candidates ({engineResult.allCandidates.length})
              </h3>
              <p className="text-xs text-slate-500">
                Full list of community partners in the geodesic sector ranked by policy score.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {engineResult.allCandidates.map((c) => (
              <div
                key={c.id}
                className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs hover:shadow-md transition-all space-y-3 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-xs font-semibold text-slate-500">{c.recipient.organization_type}</span>
                    <DecisionBadge
                      decision={c.decider_output.decision}
                      confidence={c.decider_output.confidence}
                    />
                  </div>

                  <h4 className="font-bold text-slate-900 text-base">{c.recipient.name}</h4>
                  <p className="text-xs text-slate-500 mt-0.5">{c.recipient.address}</p>

                  <div className="mt-3 pt-3 border-t border-stone-100 grid grid-cols-2 gap-2 text-xs text-slate-600">
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-semibold">Distance</span>
                      <span className="font-semibold text-slate-800">{c.distance_km.toFixed(1)} km</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-semibold">Daily Intake</span>
                      <span className="font-semibold text-slate-800">{c.recipient.daily_capacity_kg} kg</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-stone-100 flex items-center justify-between">
                  <span className={`text-[11px] font-semibold ${c.safety_result.passed ? 'text-emerald-700' : 'text-rose-600'}`}>
                    {c.safety_result.passed ? 'Safety Checks: PASS' : 'Safety Checks: FAIL'}
                  </span>
                  {c.decider_output.decision === 'APPROVE' && (
                    <button
                      onClick={() => {
                        api.acceptMatch(c.id).then((res) => {
                          setAcceptResult({
                            code: res.pickup_verification_code,
                            message: `Match confirmed with ${c.recipient.name}!`,
                            donationId: selectedDonationId,
                          });
                        });
                      }}
                      className="px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold transition-colors"
                    >
                      Assign
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
