import React, { useState } from 'react';
import { 
  Sparkles, 
  ArrowRight, 
  Clock, 
  MapPin, 
  ShieldCheck, 
  UtensilsCrossed, 
  Leaf, 
  Truck, 
  HeartHandshake, 
  Search, 
  CheckCircle2, 
  Building2, 
  Users, 
  TrendingUp, 
  Zap, 
  ChevronRight,
  Flame,
  Award,
  Filter
} from 'lucide-react';
import { Donation, ImpactMetrics } from '../types';
import { StatusBadge } from '../components/StatusBadge';
import { FeaturedDonationCarousel } from '../components/FeaturedDonationCarousel';

interface Props {
  donations: Donation[];
  impact: ImpactMetrics | null;
  onNavigate: (tab: string, contextId?: string) => void;
  onOpenDonateModal: () => void;
  onSelectDonation: (donation: Donation) => void;
  onSelectCategory: (category: string) => void;
}

export const HomePage: React.FC<Props> = ({
  donations,
  impact,
  onNavigate,
  onOpenDonateModal,
  onSelectDonation,
  onSelectCategory,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('Bangalore Central');
  const [selectedCategoryTab, setSelectedCategoryTab] = useState('ALL');

  // Categories with authentic photography & metadata
  const categories = [
    {
      id: 'Cooked Meals',
      name: 'Hot Cooked Meals',
      count: '6 active batches',
      image: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80',
      description: 'Steam-table banquets, biryani, curries & warm meals from hotels, hostels & cafeterias.',
      tag: 'Urgent Pickup',
    },
    {
      id: 'Bakery',
      name: 'Artisan Bakery',
      count: '2 active batches',
      image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=800&q=80',
      description: 'Freshly baked sourdough, baguettes, croissants & tea breads from city bakeries.',
      tag: 'Day-end Surplus',
    },
    {
      id: 'Produce',
      name: 'Fresh Farm Produce',
      count: '2 partners',
      image: 'https://images.unsplash.com/photo-1610348725531-843dff563e2c?auto=format&fit=crop&w=800&q=80',
      description: 'Crisp whole fruits, vegetables, and greens from market vendors and wholesalers.',
      tag: 'High Nutrition',
    },
    {
      id: 'Dairy',
      name: 'Chilled Desserts & Dairy',
      count: '2 active batches',
      image: 'https://images.unsplash.com/photo-1579372786545-d24232daf58c?auto=format&fit=crop&w=800&q=80',
      description: 'Catering pastries, chilled desserts, and dairy delicacies under cold chain preservation.',
      tag: 'Cold Chain',
    },
  ];

  // Filtered active donations for the multi-item live grid
  const activeDonations = donations
    .filter((d) => d.status !== 'COLLECTED' && d.status !== 'EXPIRED' && d.status !== 'CANCELLED')
    .filter((d) => {
      if (selectedCategoryTab === 'ALL') return true;
      return d.food_category === selectedCategoryTab;
    })
    .filter((d) => {
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      return (
        d.food_title.toLowerCase().includes(q) ||
        d.donor_name.toLowerCase().includes(q) ||
        d.donor_address.toLowerCase().includes(q) ||
        d.donor_type.toLowerCase().includes(q)
      );
    });

  return (
    <div className="space-y-20 sm:space-y-28 pb-16">
      {/* 1. CINEMATIC HERO SECTION */}
      <section className="relative overflow-hidden pt-6 sm:pt-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Text Column */}
          <div className="lg:col-span-7 space-y-6 sm:space-y-8 animate-fade-in">
            {/* Pill Tag */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#E4F4EE] border border-[#C2E5D7] text-[#103B2D] text-xs font-semibold shadow-xs">
              <span className="w-2 h-2 rounded-full bg-[#10B981] animate-ping" />
              <span>AI-Powered Food Rescue Network</span>
              <span className="text-stone-300">•</span>
              <span className="font-mono text-[11px] text-[#164E3D]">Strands Decider 2B</span>
            </div>

            {/* Headline with exact tagline */}
            <div className="space-y-3">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold font-display text-[#17211C] tracking-tight leading-[1.08]">
                Surplus today. <br className="hidden sm:inline" />
                <span className="text-gradient-forest">Sustenance tomorrow.</span>
              </h1>
              <p className="text-base sm:text-lg text-stone-600 max-w-xl font-normal leading-relaxed pt-1">
                Nexmeal seamlessly connects restaurants, college hostels, cafeterias, luxury hotels, and wedding banquets with verified nearby community kitchens—routing surplus meals before pickup deadlines with explainable AI decisions.
              </p>
            </div>

            {/* Primary Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 pt-1">
              <button
                onClick={onOpenDonateModal}
                className="flex items-center justify-center gap-2 px-7 py-4 rounded-2xl bg-[#103B2D] hover:bg-[#0B261D] text-white text-sm font-bold shadow-card hover:shadow-elevated transition-all duration-300 hover:-translate-y-0.5"
              >
                <UtensilsCrossed className="w-4 h-4 text-emerald-300" />
                <span>Donate Surplus Food</span>
                <ArrowRight className="w-4 h-4 text-emerald-300" />
              </button>

              <button
                onClick={() => onNavigate('discover')}
                className="flex items-center justify-center gap-2 px-7 py-4 rounded-2xl bg-white hover:bg-stone-100 text-[#17211C] text-sm font-bold border border-stone-300/80 shadow-subtle transition-all duration-200"
              >
                <Search className="w-4 h-4 text-stone-500" />
                <span>Discover Food Nearby</span>
              </button>
            </div>

            {/* Micro Social-Proof Telemetry */}
            <div className="pt-4 flex items-center gap-6 sm:gap-8 border-t border-stone-200/80 text-xs text-stone-600">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                <span>7 Deterministic Safety Gates</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-700" />
                <span>Zero-Spill Deadline Tracking</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-teal-700" />
                <span>Verified Handover OTP</span>
              </div>
            </div>
          </div>

          {/* Right Photographic Visual Column: 2-Second Auto-Rotating Featured Carousel */}
          <div className="lg:col-span-5 relative">
            <FeaturedDonationCarousel
              donations={donations}
              onSelectDonation={onSelectDonation}
              onNavigate={onNavigate}
            />
          </div>
        </div>
      </section>

      {/* 2. LOCATION & FOOD DISCOVERY SEARCH BAR */}
      <section className="bg-white p-4 sm:p-5 rounded-3xl border border-stone-200/80 shadow-card">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
          {/* Location Picker */}
          <div className="md:col-span-3 flex items-center gap-2.5 px-3.5 py-3 rounded-2xl bg-[#FAFAF6] border border-stone-200/70">
            <MapPin className="w-4 h-4 text-emerald-700 shrink-0" />
            <div className="flex-1 min-w-0">
              <span className="text-[10px] uppercase font-bold text-stone-400 block tracking-wider">Pickup Region</span>
              <select
                value={selectedLocation}
                onChange={(e) => setSelectedLocation(e.target.value)}
                className="bg-transparent text-xs font-bold text-stone-800 outline-none w-full cursor-pointer"
              >
                <option value="Bangalore Central">Bangalore Central (Richmond / MG Road)</option>
                <option value="Koramangala">Koramangala & Indiranagar</option>
                <option value="Bellandur">Bellandur & Tech Corridor</option>
                <option value="Malleshwaram">Malleshwaram & Rajajinagar</option>
              </select>
            </div>
          </div>

          {/* Search Input */}
          <div className="md:col-span-6 flex items-center gap-2.5 px-3.5 py-3 rounded-2xl bg-[#FAFAF6] border border-stone-200/70">
            <Search className="w-4 h-4 text-stone-400 shrink-0" />
            <input
              type="text"
              placeholder="Search surplus by dish name, cuisine, hotel, bakery, hostel, or donor..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-transparent text-xs text-stone-800 placeholder:text-stone-400 outline-none w-full"
            />
          </div>

          {/* Find Button */}
          <div className="md:col-span-3">
            <button
              onClick={() => onNavigate('discover')}
              className="w-full py-3.5 px-4 rounded-2xl bg-[#103B2D] hover:bg-[#0B261D] text-white text-xs font-bold shadow-sm transition-all flex items-center justify-center gap-2"
            >
              <span>Explore Available Lots</span>
              <ArrowRight className="w-4 h-4 text-emerald-300" />
            </button>
          </div>
        </div>
      </section>

      {/* 3. SURPLUS FOOD CATEGORIES WITH AUTHENTIC PHOTOGRAPHY */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-emerald-800">
              <UtensilsCrossed className="w-3.5 h-3.5" />
              <span>Explore by Surplus Type</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold font-display text-stone-900 mt-1">
              Carefully categorized for rapid distribution.
            </h2>
          </div>
          <button
            onClick={() => onNavigate('discover')}
            className="text-xs font-bold text-emerald-800 hover:text-emerald-950 flex items-center gap-1"
          >
            <span>View All Categories</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {categories.map((cat) => (
            <div
              key={cat.id}
              onClick={() => {
                onSelectCategory(cat.id);
                onNavigate('discover');
              }}
              className="group bg-white rounded-3xl overflow-hidden border border-stone-200/80 shadow-subtle hover:shadow-card transition-all duration-300 cursor-pointer flex flex-col hover:-translate-y-1"
            >
              <div className="relative h-44 w-full overflow-hidden bg-stone-100">
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full text-[10px] font-bold bg-black/60 text-white backdrop-blur-md">
                  {cat.tag}
                </div>
              </div>

              <div className="p-5 flex-1 flex flex-col justify-between space-y-3">
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold font-display text-base text-stone-900 group-hover:text-emerald-800 transition-colors">
                      {cat.name}
                    </h3>
                    <span className="text-[11px] font-mono text-stone-500">{cat.count}</span>
                  </div>
                  <p className="text-xs text-stone-500 line-clamp-2 leading-relaxed">
                    {cat.description}
                  </p>
                </div>

                <div className="flex items-center gap-1 text-xs font-bold text-emerald-700 pt-1 group-hover:translate-x-1 transition-transform">
                  <span>Browse category</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. "A SECOND CHANCE FOR EVERY MEAL" - FEATURED LIVE MULTI-ITEM GRID */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-amber-700">
              <Sparkles className="w-3.5 h-3.5" />
              <span>A Second Chance for Every Meal</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold font-display text-stone-900 mt-1">
              Active surplus consignments across Bangalore.
            </h2>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
            {['ALL', 'Cooked Meals', 'Bakery', 'Produce', 'Dairy'].map((tab) => (
              <button
                key={tab}
                onClick={() => setSelectedCategoryTab(tab)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  selectedCategoryTab === tab
                    ? 'bg-[#103B2D] text-white shadow-xs'
                    : 'bg-white border border-stone-200 text-stone-600 hover:bg-stone-50'
                }`}
              >
                {tab === 'ALL' ? 'All Surplus Lots' : tab}
              </button>
            ))}
          </div>
        </div>

        {/* Multi-Item Diverse Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {activeDonations.slice(0, 8).map((don) => {
            const hoursRemaining = Math.max(
              0,
              (new Date(don.pickup_deadline).getTime() - new Date().getTime()) / (3600 * 1000)
            );

            return (
              <div
                key={don.id}
                className="bg-white rounded-3xl overflow-hidden border border-stone-200/80 shadow-subtle hover:shadow-card transition-all duration-300 flex flex-col justify-between group"
              >
                <div>
                  {/* Food Photograph with Fallback */}
                  <div className="relative h-44 w-full bg-stone-100 overflow-hidden">
                    <img
                      src={don.image_url || 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80'}
                      alt={don.food_title}
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80';
                      }}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-3 left-3">
                      <StatusBadge status={don.status} />
                    </div>
                    <div className="absolute bottom-3 right-3 px-2 py-0.5 rounded-full text-[10px] font-mono bg-black/70 text-white backdrop-blur-md">
                      {don.quantity_value} {don.quantity_unit}
                    </div>
                  </div>

                  {/* Card Content */}
                  <div className="p-4 sm:p-5 space-y-2.5">
                    <h3 className="font-bold font-display text-sm text-stone-900 line-clamp-1 group-hover:text-emerald-800 transition-colors">
                      {don.food_title}
                    </h3>
                    
                    <div className="space-y-1 text-xs text-stone-500">
                      <div className="flex items-center gap-1.5 truncate">
                        <Building2 className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                        <span className="font-semibold text-stone-700 truncate">{don.donor_name}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                        <span className={hoursRemaining < 1.5 ? 'text-amber-700 font-bold' : ''}>
                          Deadline: {hoursRemaining.toFixed(1)}h left
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                        <span className="truncate">{don.donor_address}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card Action Footer */}
                <div className="p-4 pt-0 flex items-center gap-2">
                  <button
                    onClick={() => onSelectDonation(don)}
                    className="flex-1 py-2 rounded-xl border border-stone-300 text-stone-700 hover:bg-stone-50 text-xs font-semibold transition-colors"
                  >
                    Details
                  </button>
                  <button
                    onClick={() => onNavigate('matches', don.id)}
                    className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-[#103B2D] hover:bg-[#0B261D] text-white text-xs font-bold shadow-xs transition-colors"
                  >
                    <Sparkles className="w-3 h-3 text-emerald-300" />
                    <span>Match</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {activeDonations.length > 8 && (
          <div className="text-center pt-2">
            <button
              onClick={() => onNavigate('discover')}
              className="px-6 py-2.5 rounded-xl border border-stone-300 bg-white text-stone-800 text-xs font-bold hover:bg-stone-50 transition-colors inline-flex items-center gap-2"
            >
              <span>Explore all {donations.length} surplus lots</span>
              <ArrowRight className="w-3.5 h-3.5 text-stone-500" />
            </button>
          </div>
        )}
      </section>

      {/* 5. HOW IT WORKS - 3 SIMPLE STEPS */}
      <section className="bg-white p-8 sm:p-12 rounded-3xl border border-stone-200/80 shadow-subtle space-y-10">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-800">
            Frictionless Execution
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold font-display text-stone-900">
            Rescuing edible surplus in three verified steps.
          </h2>
          <p className="text-xs sm:text-sm text-stone-500">
            Eliminating manual phone calls and group chats with deterministic safety guardrails and policy classification.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          {/* Step 1 */}
          <div className="space-y-3.5 p-6 rounded-2xl bg-[#FAFAF6] border border-stone-200/70 relative">
            <div className="w-10 h-10 rounded-xl bg-[#103B2D] text-white flex items-center justify-center font-bold text-sm">
              1
            </div>
            <h3 className="text-base font-bold font-display text-stone-900">
              Donor Registers Surplus in 60s
            </h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Kitchens, banquets, and cafeterias input food quantity, holding temperature, preparation time, and safe pickup deadline. A 4-digit verification code is generated.
            </p>
          </div>

          {/* Step 2 */}
          <div className="space-y-3.5 p-6 rounded-2xl bg-[#FAFAF6] border border-stone-200/70 relative">
            <div className="w-10 h-10 rounded-xl bg-emerald-700 text-white flex items-center justify-center font-bold text-sm">
              2
            </div>
            <h3 className="text-base font-bold font-display text-stone-900">
              Strands Decider 2B Safe Routing
            </h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Seven deterministic safety gates verify distance, intake capacity, and cold-chain compliance before Strands Decider 2B policy-classifies candidates into APPROVE, REJECT, or HUMAN_REVIEW.
            </p>
          </div>

          {/* Step 3 */}
          <div className="space-y-3.5 p-6 rounded-2xl bg-[#FAFAF6] border border-stone-200/70 relative">
            <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center font-bold text-sm">
              3
            </div>
            <h3 className="text-base font-bold font-display text-stone-900">
              Handover Code Handshake & Impact
            </h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Drivers or NGO volunteers provide the 4-digit OTP at pickup. Only verified collections advance to the impact analytics ledger, preventing uncollected offers from inflating statistics.
            </p>
          </div>
        </div>
      </section>

      {/* 6. AI MATCHING TECHNICAL SHOWCASE PREVIEW */}
      <section className="bg-gradient-to-br from-[#103B2D] via-[#164E3D] to-[#0B261D] text-white p-8 sm:p-12 rounded-3xl shadow-elevated border border-emerald-900/60 relative overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 space-y-5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-emerald-300 text-xs font-semibold">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>Technical Architecture Showcase</span>
            </div>

            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold font-display tracking-tight text-white leading-tight">
              Pairing lightweight policy classification with generative explanations.
            </h2>

            <p className="text-xs sm:text-sm text-stone-200/90 leading-relaxed max-w-xl">
              Unlike generic chatbot wrappers, Nexmeal combines rigid deterministic safety checks, the Strands Decider 2B decision engine for rapid sub-5ms classification, and Amazon Bedrock for explainable dispatch recommendations.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2 text-xs">
              <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                <span className="text-[10px] uppercase font-bold text-emerald-300 block">Classifier</span>
                <span className="font-bold text-white text-sm">Strands Decider 2B</span>
                <span className="text-[11px] text-stone-300 block mt-0.5">3.0ms avg latency</span>
              </div>
              <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                <span className="text-[10px] uppercase font-bold text-amber-300 block">Generative AI</span>
                <span className="font-bold text-white text-sm">Amazon Bedrock</span>
                <span className="text-[11px] text-stone-300 block mt-0.5">Claude 3 Haiku LLM</span>
              </div>
              <div className="p-3 rounded-xl bg-white/5 border border-white/10 col-span-2 sm:col-span-1">
                <span className="text-[10px] uppercase font-bold text-teal-300 block">Benchmark</span>
                <span className="font-bold text-white text-sm">100% Accuracy</span>
                <span className="text-[11px] text-stone-300 block mt-0.5">+28.6% vs baseline</span>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => onNavigate('matches')}
                className="px-6 py-3.5 rounded-xl bg-white text-[#103B2D] hover:bg-stone-100 text-xs font-bold shadow-card transition-all flex items-center gap-2"
              >
                <span>Launch Interactive Matching Hub</span>
                <ArrowRight className="w-4 h-4 text-[#103B2D]" />
              </button>
            </div>
          </div>

          {/* Visual AI Decision Card Simulation */}
          <div className="lg:col-span-5 bg-black/30 backdrop-blur-md rounded-2xl p-5 border border-white/10 space-y-4 text-xs font-mono">
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <span className="text-emerald-300 font-bold flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" />
                POLICY DECISION: APPROVE (96%)
              </span>
              <span className="text-stone-400 text-[10px]">3.8ms</span>
            </div>

            <div className="space-y-1.5 text-stone-300 font-sans text-xs">
              <p className="font-bold text-white">Hope Community Kitchen (0.8 km)</p>
              <div className="flex items-center gap-2 text-[11px] text-stone-400">
                <span className="text-emerald-400">✓ Deadline buffer: 3.5h</span>
                <span>•</span>
                <span className="text-emerald-400">✓ Intake capacity free: 160 kg</span>
              </div>
            </div>

            {/* Simulated Bedrock Explanation */}
            <div className="bg-white/10 p-3 rounded-xl border border-white/10 text-stone-200 text-xs font-sans leading-relaxed">
              <span className="text-amber-300 font-bold block text-[10px] uppercase tracking-wider mb-1">
                Amazon Bedrock Natural-Language Synthesis:
              </span>
              "Recommended for immediate allocation. Hope Community Kitchen is within 0.8 km with adequate refrigerated intake storage. Collection window is safe and verified driver logistics are available."
            </div>
          </div>
        </div>
      </section>

      {/* 7. TRANSPARENT IMPACT SECTION */}
      <section className="space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-1.5">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-800">
            Measurable Community Impact
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold font-display text-stone-900">
            Strict isolation of completed physical handovers.
          </h2>
          <p className="text-xs text-stone-500">
            Notice: All metrics reflect simulated demo datasets adhering strictly to Section 9 isolation rules.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-subtle text-center space-y-1">
            <span className="text-xs uppercase font-bold text-stone-400 block tracking-wider">Surplus Rescued</span>
            <span className="text-3xl font-bold font-display text-[#103B2D] block">
              {impact?.total_kg_rescued ?? 95.0} kg
            </span>
            <span className="text-[11px] text-stone-500">Across {impact?.completed_pickups ?? 2} verified handovers</span>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-subtle text-center space-y-1">
            <span className="text-xs uppercase font-bold text-stone-400 block tracking-wider">Meals Provided</span>
            <span className="text-3xl font-bold font-display text-amber-600 block">
              {impact?.estimated_meals_served?.toLocaleString() ?? '237'}
            </span>
            <span className="text-[11px] text-stone-500">Based on standard 400g serving</span>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-subtle text-center space-y-1">
            <span className="text-xs uppercase font-bold text-stone-400 block tracking-wider">CO2e Diverted</span>
            <span className="text-3xl font-bold font-display text-teal-700 block">
              {impact?.co2_avoided_kg ?? 237.5} kg
            </span>
            <span className="text-[11px] text-stone-500">EPA greenhouse gas avoidance factor</span>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-subtle text-center space-y-1">
            <span className="text-xs uppercase font-bold text-stone-400 block tracking-wider">Fulfilled Collection</span>
            <span className="text-3xl font-bold font-display text-emerald-700 block">
              {impact?.collection_rate_percent ?? 100}%
            </span>
            <span className="text-[11px] text-stone-500">Zero food-safety protocol violations</span>
          </div>
        </div>

        <div className="text-center pt-2">
          <button
            onClick={() => onNavigate('impact')}
            className="text-xs font-bold text-emerald-800 hover:text-emerald-950 inline-flex items-center gap-1.5"
          >
            <span>View Full ESG Impact & Bedrock Reports</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </section>

      {/* 8. DUAL CONVERSION SECTION FOR DONORS & NGOS */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* For Donors */}
        <div className="bg-white p-8 rounded-3xl border border-stone-200/80 shadow-subtle space-y-5 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center font-bold">
              <Building2 className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-bold font-display text-stone-900">
              For Food Donors
            </h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Restaurants, caterers, cafeterias, and wedding planners: turn excess edible prep into community goodwill, measurable ESG sustainability credits, and zero landfill waste.
            </p>
            <ul className="space-y-1.5 text-xs text-stone-600 pt-2">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Automated pickup coordination within safe time limit</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Verified 4-digit handover codes ensure chain-of-custody</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Tax & corporate sustainability reporting receipts</span>
              </li>
            </ul>
          </div>

          <div className="pt-4">
            <button
              onClick={() => onNavigate('donor')}
              className="w-full py-3 rounded-xl bg-stone-900 hover:bg-black text-white text-xs font-bold transition-colors flex items-center justify-center gap-2"
            >
              <span>Access Donor Portal</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* For NGOs */}
        <div className="bg-white p-8 rounded-3xl border border-stone-200/80 shadow-subtle space-y-5 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              <HeartHandshake className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-bold font-display text-stone-900">
              For Verified NGOs & Shelters
            </h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Community kitchens, children shelters, and emergency food banks: receive predictable batches of wholesome food aligned precisely with your refrigeration and daily serving capacity.
            </p>
            <ul className="space-y-1.5 text-xs text-stone-600 pt-2">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Advance notifications before dispatch arrival</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Strict capacity limits prevent kitchen spoilage</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Verified dietary labeling (vegetarian, halal, allergens)</span>
              </li>
            </ul>
          </div>

          <div className="pt-4">
            <button
              onClick={() => onNavigate('ngo')}
              className="w-full py-3 rounded-xl bg-[#103B2D] hover:bg-[#0B261D] text-white text-xs font-bold transition-colors flex items-center justify-center gap-2"
            >
              <span>Access NGO Intake Portal</span>
              <ArrowRight className="w-3.5 h-3.5 text-emerald-300" />
            </button>
          </div>
        </div>
      </section>

      {/* 9. COMMUNITY STORIES */}
      <section className="space-y-6">
        <div className="text-center max-w-xl mx-auto space-y-1">
          <span className="text-xs font-bold uppercase tracking-wider text-stone-500">
            Real Voices from the Community
          </span>
          <h2 className="text-xl sm:text-2xl font-bold font-display text-stone-900">
            Stories behind rescued meals.
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-subtle space-y-3">
            <p className="text-xs text-stone-600 italic leading-relaxed">
              "We used to throw away 40 to 60 kg of fresh banquet biryani after large weddings. Nexmeal matched us with Hope Kitchen in 8 minutes, and it was picked up before midnight."
            </p>
            <div className="pt-2 border-t border-stone-100 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs">
                VM
              </div>
              <div>
                <span className="text-xs font-bold text-stone-900 block">Chef Vikram Malhotra</span>
                <span className="text-[10px] text-stone-400">The Royal Palace Banquet</span>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-subtle space-y-3">
            <p className="text-xs text-stone-600 italic leading-relaxed">
              "Knowing our refrigerator capacity is never exceeded is a lifesaver. The AI checks our intake room before offering food, so we never have to turn away expired surplus."
            </p>
            <div className="pt-2 border-t border-stone-100 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center font-bold text-xs">
                AS
              </div>
              <div>
                <span className="text-xs font-bold text-stone-900 block">Anita Sharma</span>
                <span className="text-[10px] text-stone-400">Director, Hope Community Kitchen</span>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-subtle space-y-3">
            <p className="text-xs text-stone-600 italic leading-relaxed">
              "The 4-digit code gives us complete peace of mind. Both the banquet staff and our volunteer drivers confirm the code before the vehicle leaves the gate."
            </p>
            <div className="pt-2 border-t border-stone-100 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-teal-100 text-teal-800 flex items-center justify-center font-bold text-xs">
                KS
              </div>
              <div>
                <span className="text-xs font-bold text-stone-900 block">Karan Singh</span>
                <span className="text-[10px] text-stone-400">Volunteer Fleet Courier</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
