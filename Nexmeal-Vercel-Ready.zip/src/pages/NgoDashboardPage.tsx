import React, { useState } from 'react';
import { 
  HeartHandshake, 
  CheckCircle, 
  Clock, 
  MapPin, 
  ShieldCheck, 
  Sparkles, 
  Truck, 
  ArrowRight,
  Snowflake,
  AlertCircle,
  KeyRound,
  Check,
  Building2,
  Calendar
} from 'lucide-react';
import { Donation, Recipient, UserProfile } from '../types';
import { StatusBadge } from '../components/StatusBadge';

interface Props {
  donations: Donation[];
  recipients: Recipient[];
  currentUser: UserProfile;
  onNavigate: (tab: string, contextId?: string) => void;
  onAcceptOffer: (matchId: string) => Promise<void>;
  onOpenConfirmPickup: (donationId: string) => void;
  onSelectDonation: (donation: Donation) => void;
}

export const NgoDashboardPage: React.FC<Props> = ({
  donations,
  recipients,
  currentUser,
  onNavigate,
  onAcceptOffer,
  onOpenConfirmPickup,
  onSelectDonation,
}) => {
  const [acceptingId, setAcceptingId] = useState<string | null>(null);

  // Active NGO profile (default to Hope Community Kitchen or find by entityId)
  const currentNgo = recipients.find((r) => r.id === (currentUser.entityId || 'rec-001')) || recipients[0];

  const capacityUsed = currentNgo ? currentNgo.current_capacity_used_kg : 40;
  const dailyCapacity = currentNgo ? currentNgo.daily_capacity_kg : 200;
  const capacityPercent = Math.min(100, Math.round((capacityUsed / dailyCapacity) * 100));
  const freeCapacity = Math.max(0, dailyCapacity - capacityUsed);

  // Donations relevant for intake
  const incomingOffers = donations.filter((d) => d.status === 'MATCHED' || d.status === 'PROPOSED');
  const scheduledDeliveries = donations.filter((d) => d.status === 'ACCEPTED' || d.status === 'IN_TRANSIT');
  const pastDeliveries = donations.filter((d) => d.status === 'COLLECTED');

  const handleAccept = async (donationId: string) => {
    setAcceptingId(donationId);
    try {
      await onAcceptOffer(`match-${donationId}-${currentNgo.id}`);
    } catch (err) {
      console.error('Accept error:', err);
    } finally {
      setAcceptingId(null);
    }
  };

  return (
    <div className="space-y-8 pb-12 animate-fade-in">
      {/* Header Banner */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200/80 shadow-subtle flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
            <HeartHandshake className="w-3.5 h-3.5" />
            <span>NGO Intake Console • {currentNgo?.name || 'Community Partner'}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold font-display text-stone-900 tracking-tight">
            Surplus Intake & Distribution Management
          </h1>
          <p className="text-xs sm:text-sm text-stone-500 max-w-xl">
            Review incoming surplus matches vetted by Strands Decider 2B for safe kitchen capacity, cold-chain standards, and pickup deadlines.
          </p>
        </div>

        {/* Capability Chips */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <div className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-[#FAFAF6] border border-stone-200 text-xs text-stone-700">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Verified NGO</span>
          </div>
          <div className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-[#FAFAF6] border border-stone-200 text-xs text-stone-700">
            <Snowflake className="w-4 h-4 text-blue-600" />
            <span>Cold Chain Ready</span>
          </div>
        </div>
      </div>

      {/* KPI & Intake Capacity Gauges */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Daily Capacity Meter */}
        <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-subtle space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold uppercase tracking-wider text-stone-500">Daily Intake Capacity</span>
            <span className="font-bold text-stone-900 font-mono">{capacityUsed} / {dailyCapacity} kg</span>
          </div>
          
          {/* Progress Bar */}
          <div className="w-full h-3 rounded-full bg-stone-100 overflow-hidden">
            <div 
              className={`h-full rounded-full transition-all duration-500 ${
                capacityPercent > 80 ? 'bg-amber-500' : 'bg-emerald-600'
              }`}
              style={{ width: `${capacityPercent}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-[11px] text-stone-500 pt-1">
            <span>Free intake headroom: <strong className="text-emerald-800">{freeCapacity} kg</strong></span>
            <span>{capacityPercent}% committed</span>
          </div>
        </div>

        {/* Scheduled Arrivals */}
        <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-subtle space-y-1">
          <div className="flex items-center justify-between text-stone-400 text-xs font-bold uppercase tracking-wider">
            <span>Scheduled Courier Deliveries</span>
            <Truck className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-3xl font-bold font-display text-indigo-700 pt-1">
            {scheduledDeliveries.length} <span className="text-sm font-normal text-stone-400">batches</span>
          </div>
          <p className="text-[11px] text-stone-500">Currently accepted or en route via vehicle</p>
        </div>

        {/* Completed Rescued */}
        <div className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-subtle space-y-1">
          <div className="flex items-center justify-between text-stone-400 text-xs font-bold uppercase tracking-wider">
            <span>Total Rescued & Served</span>
            <CheckCircle className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-3xl font-bold font-display text-emerald-800 pt-1">
            {pastDeliveries.reduce((sum, d) => sum + d.quantity_value, 0).toFixed(0)} <span className="text-sm font-normal text-stone-400">kg</span>
          </div>
          <p className="text-[11px] text-stone-500">Distributed to community kitchen beneficiaries</p>
        </div>
      </div>

      {/* Scheduled In-Transit Consignments Waiting for Handshake */}
      {scheduledDeliveries.length > 0 && (
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-indigo-100 shadow-subtle space-y-4">
          <div className="flex items-center justify-between border-b border-stone-100 pb-3">
            <div className="flex items-center gap-2">
              <Truck className="w-5 h-5 text-indigo-600" />
              <h2 className="text-base font-bold font-display text-stone-900">
                Incoming Deliveries Pending Physical Handover
              </h2>
            </div>
            <span className="text-xs font-bold text-indigo-700">Requires Handshake Verification</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {scheduledDeliveries.map((don) => (
              <div 
                key={don.id}
                className="p-5 rounded-2xl bg-indigo-50/40 border border-indigo-100/80 space-y-3 flex flex-col justify-between"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-sm text-stone-900">{don.food_title}</h3>
                    <StatusBadge status={don.status} />
                  </div>
                  <p className="text-xs text-stone-600">
                    From: <strong>{don.donor_name}</strong> • Qty: <strong>{don.quantity_value} {don.quantity_unit}</strong>
                  </p>
                  <p className="text-[11px] text-stone-400">
                    Pickup Deadline: {new Date(don.pickup_deadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>

                <div className="flex items-center gap-2 pt-2 border-t border-indigo-100">
                  <button
                    onClick={() => onSelectDonation(don)}
                    className="py-2 px-3 rounded-xl border border-stone-300 text-stone-700 hover:bg-white text-xs font-semibold"
                  >
                    Inspect
                  </button>
                  <button
                    onClick={() => onOpenConfirmPickup(don.id)}
                    className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs"
                  >
                    <KeyRound className="w-3.5 h-3.5" />
                    <span>Enter Handover Code</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recommended Matched Surplus Offers */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200/80 shadow-subtle space-y-6">
        <div className="flex items-center justify-between border-b border-stone-100 pb-4">
          <div>
            <h2 className="text-lg font-bold font-display text-stone-900">
              Matching Surplus Offers Ready to Accept
            </h2>
            <p className="text-xs text-stone-500">Algorithmically validated against your refrigeration and intake limits</p>
          </div>
          <button
            onClick={() => onNavigate('matches')}
            className="text-xs font-bold text-emerald-800 hover:text-emerald-950 flex items-center gap-1"
          >
            <span>Open AI Matching Engine</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {incomingOffers.length === 0 ? (
          <div className="p-8 text-center text-stone-400 text-xs">
            No incoming pending offers right now. Check back when donors register new surplus.
          </div>
        ) : (
          <div className="space-y-4">
            {incomingOffers.map((don) => (
              <div
                key={don.id}
                className="p-5 rounded-2xl bg-[#FAFAF6] border border-stone-200/80 hover:border-stone-300 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="flex items-start gap-4">
                  <img
                    src={don.image_url || 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80'}
                    alt={don.food_title}
                    className="w-16 h-16 rounded-xl object-cover shrink-0 border border-stone-200"
                  />
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-bold font-display text-sm text-stone-900">{don.food_title}</h3>
                      <StatusBadge status={don.status} />
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                        Fits Capacity
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-stone-500 flex-wrap">
                      <span>Donor: <strong>{don.donor_name}</strong></span>
                      <span>•</span>
                      <span>Volume: <strong>{don.quantity_value} {don.quantity_unit}</strong></span>
                      <span>•</span>
                      <span>Category: <strong>{don.food_category}</strong></span>
                    </div>
                    <p className="text-[11px] text-stone-400">
                      Address: {don.donor_address}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2.5 shrink-0 self-end md:self-center">
                  <button
                    onClick={() => onSelectDonation(don)}
                    className="px-4 py-2 rounded-xl border border-stone-300 text-stone-700 hover:bg-white text-xs font-semibold transition-colors"
                  >
                    Review Details
                  </button>
                  <button
                    onClick={() => handleAccept(don.id)}
                    disabled={acceptingId === don.id}
                    className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-[#103B2D] hover:bg-[#0B261D] text-white text-xs font-bold shadow-xs transition-colors disabled:opacity-50"
                  >
                    <Check className="w-4 h-4 text-emerald-300" />
                    <span>{acceptingId === don.id ? 'Accepting...' : 'Accept & Claim Lot'}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
