import React, { useState, useEffect } from 'react';
import {
  UtensilsCrossed,
  CheckCircle,
  Clock,
  ArrowRight,
  Sparkles,
  RefreshCw,
  AlertCircle,
  Truck,
  Leaf,
  MapPin,
  ChevronRight,
  ShieldCheck,
  Activity,
  Layers,
  Check
} from 'lucide-react';
import { Donation, ImpactMetrics, AuditLogItem } from '../types';
import { api } from '../api/client';
import { StatusBadge } from '../components/StatusBadge';

interface Props {
  onNavigate: (tab: string, contextId?: string) => void;
}

export const DashboardPage: React.FC<Props> = ({ onNavigate }) => {
  const [donations, setDonations] = useState<Donation[]>([]);
  const [impact, setImpact] = useState<ImpactMetrics | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [filter, setFilter] = useState<string>('ALL');

  const loadData = async () => {
    try {
      setLoading(true);
      const [dons, imp, logs] = await Promise.all([
        api.listDonations(),
        api.getImpactMetrics(),
        api.getAuditLogs(10),
      ]);
      setDonations(dons);
      setImpact(imp);
      setAuditLogs(logs);
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const filteredDonations =
    filter === 'ALL'
      ? donations
      : donations.filter((d) => d.status === filter);

  return (
    <div className="space-y-8 pb-12">
      {/* Hero Command Section (Apple-inspired) */}
      <div className="relative overflow-hidden bg-gradient-to-br from-white via-stone-50 to-emerald-50/30 p-6 sm:p-10 rounded-3xl border border-stone-200/80 shadow-sm backdrop-blur-xl">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="space-y-3 max-w-3xl">
            {/* Live System Indicator */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200/80 text-emerald-800 text-xs font-medium">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span>Live AI Allocation Network • Real-time Dispatch Active</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 tracking-tight leading-tight">
              Nexmeal Command Center
            </h1>

            <p className="text-base sm:text-lg text-slate-600 leading-relaxed font-normal">
              Autonomous surplus food coordination orchestrating rapid pickup dispatch, Decider 2B safety validation, and automated NGO route delivery.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={loadData}
              disabled={loading}
              className="p-3.5 text-slate-600 hover:text-slate-900 rounded-2xl bg-white/90 hover:bg-white backdrop-blur-xl border border-stone-200/90 shadow-sm hover:shadow transition-all duration-200 disabled:opacity-50 cursor-pointer"
              title="Refresh Dashboard Data"
              aria-label="Refresh Dashboard Data"
            >
              <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin text-emerald-600' : ''}`} />
            </button>

            <button
              onClick={() => onNavigate('donate')}
              className="group flex items-center gap-2.5 px-6 py-3.5 bg-gradient-to-br from-emerald-600 to-teal-500 hover:from-emerald-700 hover:to-teal-600 text-white rounded-2xl text-sm font-semibold shadow-lg shadow-emerald-600/20 hover:shadow-xl hover:shadow-emerald-600/30 transition-all duration-300 cursor-pointer"
            >
              <UtensilsCrossed className="w-4 h-4 transition-transform duration-300 group-hover:rotate-12" />
              <span>Register Surplus</span>
              <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
            </button>
          </div>
        </div>

        {/* Ambient subtle background decorative glow */}
        <div className="absolute -top-24 -right-24 w-80 h-80 bg-emerald-200/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-80 h-80 bg-amber-200/20 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Impact Metrics Row (4 Cards) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Card 1: Completed Pickups */}
        <div className="bg-white p-6 rounded-2xl border border-stone-200/80 shadow-sm hover:shadow-lg transition-all duration-300 relative overflow-hidden group">
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-emerald-500 to-teal-400" />
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Completed Pickups
            </span>
            <div className="w-11 h-11 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center transition-transform duration-300 group-hover:scale-110">
              <CheckCircle className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight">
              {impact?.completed_pickups ?? 0}
            </div>
            <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-2 font-medium">
              <span>Collection Rate:</span>
              <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-bold border border-emerald-200/60">
                {impact?.collection_rate_percent ?? 0}%
              </span>
            </div>
          </div>
        </div>

        {/* Card 2: Rescued Surplus */}
        <div className="bg-white p-6 rounded-2xl border border-stone-200/80 shadow-sm hover:shadow-lg transition-all duration-300 relative overflow-hidden group">
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-teal-500 to-emerald-400" />
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Rescued Surplus
            </span>
            <div className="w-11 h-11 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center transition-transform duration-300 group-hover:scale-110">
              <Leaf className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight flex items-baseline gap-1.5">
              <span>{impact?.total_kg_rescued ?? 0}</span>
              <span className="text-base font-normal text-slate-500">kg</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-2 font-medium">
              <span>Avoided CO2e:</span>
              <strong className="text-teal-700 font-semibold">
                {impact?.co2_avoided_kg ?? 0} kg
              </strong>
            </div>
          </div>
        </div>

        {/* Card 3: Est. Meals Served */}
        <div className="bg-white p-6 rounded-2xl border border-stone-200/80 shadow-sm hover:shadow-lg transition-all duration-300 relative overflow-hidden group">
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-500 to-orange-400" />
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Est. Meals Served
            </span>
            <div className="w-11 h-11 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center transition-transform duration-300 group-hover:scale-110">
              <UtensilsCrossed className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight">
              {impact?.estimated_meals_served?.toLocaleString() ?? 0}
            </div>
            <p className="text-xs text-slate-500 mt-2 font-medium truncate">
              Basis:{' '}
              <strong className="text-slate-700 font-semibold">
                {impact?.serving_size_assumed_kg ? impact.serving_size_assumed_kg * 1000 : 400}g
              </strong>{' '}
              portion
            </p>
          </div>
        </div>

        {/* Card 4: Active Pipeline */}
        <div className="bg-white p-6 rounded-2xl border border-stone-200/80 shadow-sm hover:shadow-lg transition-all duration-300 relative overflow-hidden group">
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 to-indigo-400" />
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Active Pipeline
            </span>
            <div className="w-11 h-11 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center transition-transform duration-300 group-hover:scale-110">
              <Truck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight">
              {(impact?.pending_offers ?? 0) + (impact?.in_transit ?? 0)}
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-500 mt-2 font-medium">
              <span>Transit:</span>
              <strong className="text-blue-700 font-semibold">{impact?.in_transit ?? 0}</strong>
              <span className="text-stone-300">•</span>
              <span>Pending:</span>
              <strong className="text-purple-700 font-semibold">{impact?.pending_offers ?? 0}</strong>
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid: Pipeline & Decision Audit Log */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Surplus Food Pipeline */}
        <div className="lg:col-span-2 bg-white rounded-3xl border border-stone-200/80 shadow-sm overflow-hidden flex flex-col">
          {/* Header & Filter Controls */}
          <div className="p-6 border-b border-stone-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900 tracking-tight">
                  Surplus Food Pipeline
                </h2>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-stone-100 text-slate-700 border border-stone-200/60">
                  {filteredDonations.length} items
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Real-time tracking through donor submission, matching, transit, and verification.
              </p>
            </div>

            {/* Filter Pills */}
            <div className="flex flex-wrap items-center gap-1.5 p-1 rounded-full bg-stone-100/90 border border-stone-200/60 text-xs">
              {(['ALL', 'PROPOSED', 'ACCEPTED', 'IN_TRANSIT', 'COLLECTED'] as const).map((f) => {
                const isActive = filter === f;
                return (
                  <button
                    key={f}
                    onClick={() => setFilter(f)}
                    className={`px-3 py-1.5 rounded-full font-semibold transition-all duration-200 cursor-pointer ${
                      isActive
                        ? 'bg-slate-900 text-white shadow-sm'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-stone-200/60'
                    }`}
                  >
                    {f.replace('_', ' ')}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Donations List Container */}
          <div className="divide-y divide-stone-100 flex-1 overflow-y-auto max-h-[580px]">
            {filteredDonations.length === 0 ? (
              <div className="py-16 px-6 text-center space-y-3">
                <div className="w-14 h-14 mx-auto rounded-2xl bg-stone-100 text-slate-400 flex items-center justify-center">
                  <UtensilsCrossed className="w-7 h-7" />
                </div>
                <h3 className="text-sm font-semibold text-slate-800">No surplus donations match</h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  {filter === 'ALL'
                    ? 'No food items are currently in the system. Register a surplus batch to start matching.'
                    : `No items currently in '${filter.replace('_', ' ')}' status.`}
                </p>
                <button
                  onClick={() => onNavigate('donate')}
                  className="inline-flex items-center gap-2 mt-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-all"
                >
                  <UtensilsCrossed className="w-3.5 h-3.5" />
                  Register Surplus Food
                </button>
              </div>
            ) : (
              filteredDonations.map((don) => (
                <div
                  key={don.id}
                  className="p-5 sm:p-6 hover:bg-stone-50/80 transition-all duration-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4 group"
                >
                  {/* Left: Donation Info */}
                  <div className="space-y-2 flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2.5">
                      <h3 className="font-bold text-slate-900 text-base group-hover:text-emerald-700 transition-colors">
                        {don.food_title}
                      </h3>
                      <StatusBadge status={don.status} />
                      <span className="text-[11px] font-semibold text-slate-600 bg-stone-100 px-2 py-0.5 rounded-md border border-stone-200/60">
                        {don.food_category}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600">
                      <span>
                        Donor:{' '}
                        <strong className="text-slate-800 font-semibold">{don.donor_name}</strong>{' '}
                        <span className="text-slate-400 font-normal">({don.donor_type})</span>
                      </span>
                      <span className="text-stone-300">•</span>
                      <span>
                        Quantity:{' '}
                        <strong className="text-slate-900 font-bold">
                          {don.quantity_value} {don.quantity_unit}
                        </strong>
                      </span>
                      <span className="text-stone-300">•</span>
                      <span className="capitalize text-slate-500 font-medium">
                        {don.dietary_type.toLowerCase()}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-400">
                      <span className="flex items-center gap-1.5 text-slate-500">
                        <Clock className="w-3.5 h-3.5 text-amber-500" />
                        <span>
                          Pickup Deadline:{' '}
                          <strong className="text-slate-700 font-medium">
                            {new Date(don.pickup_deadline).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </strong>
                        </span>
                      </span>

                      <span className="text-stone-300">•</span>

                      <span className="flex items-center gap-1.5 truncate max-w-xs text-slate-500">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">{don.donor_address}</span>
                      </span>
                    </div>
                  </div>

                  {/* Right: Action Buttons & Verification Code */}
                  <div className="flex flex-row sm:flex-col items-center sm:items-end justify-between sm:justify-center gap-2.5 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-stone-100">
                    {don.status === 'PROPOSED' && (
                      <button
                        onClick={() => onNavigate('matches', don.id)}
                        className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-semibold shadow-sm hover:shadow transition-all cursor-pointer"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Match AI</span>
                      </button>
                    )}

                    {don.status === 'ACCEPTED' && (
                      <button
                        onClick={() => onNavigate('pickups', don.id)}
                        className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-sm hover:shadow transition-all cursor-pointer"
                      >
                        <Truck className="w-3.5 h-3.5" />
                        <span>Track Pickup</span>
                      </button>
                    )}

                    {don.status === 'IN_TRANSIT' && (
                      <button
                        onClick={() => onNavigate('pickups', don.id)}
                        className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-sm hover:shadow transition-all cursor-pointer"
                      >
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>Verify Code</span>
                      </button>
                    )}

                    {don.pickup_verification_code && don.status !== 'COLLECTED' && (
                      <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-stone-100 border border-stone-200/90 text-slate-700 font-mono text-xs">
                        <span className="text-[10px] text-slate-400 uppercase tracking-wider font-sans font-semibold">
                          Code:
                        </span>
                        <span className="font-bold tracking-wider">
                          {don.pickup_verification_code}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right 1 Col: Decision & Safety Audit Log */}
        <div className="bg-white rounded-3xl border border-stone-200/80 shadow-sm p-6 flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-stone-100">
            <div>
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-600" />
                <h2 className="text-base font-bold text-slate-900 tracking-tight">
                  Decision & Safety Audit Log
                </h2>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Immutable trace of AI decisions & overrides
              </p>
            </div>

            <button
              onClick={() => onNavigate('reviews')}
              className="group flex items-center gap-1 text-xs font-semibold text-emerald-600 hover:text-emerald-700 transition-colors"
            >
              <span>Queue</span>
              <ArrowRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-0.5" />
            </button>
          </div>

          {/* Audit Timeline */}
          <div className="mt-5 space-y-4 flex-1 overflow-y-auto max-h-[520px] pr-1">
            {auditLogs.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-xs">
                No recent audit events recorded.
              </div>
            ) : (
              auditLogs.map((log, index) => {
                const isAI =
                  log.actor_role?.toLowerCase().includes('decider') ||
                  log.actor_role?.toLowerCase().includes('bedrock') ||
                  log.actor_role?.toLowerCase().includes('ai');
                const isHuman = log.actor_role?.toLowerCase().includes('human');

                return (
                  <div key={log.id || index} className="relative pl-6 pb-4 last:pb-0">
                    {/* Vertical timeline line */}
                    {index !== auditLogs.length - 1 && (
                      <div className="absolute left-2.5 top-3.5 bottom-0 w-px bg-stone-200" />
                    )}

                    {/* Timeline dot */}
                    <div
                      className={`absolute left-1 top-1.5 w-3.5 h-3.5 rounded-full border-2 border-white shadow-xs ${
                        isAI
                          ? 'bg-emerald-500'
                          : isHuman
                          ? 'bg-amber-500'
                          : 'bg-blue-500'
                      }`}
                    />

                    {/* Content Box */}
                    <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200/70 hover:border-stone-300 transition-all space-y-1.5">
                      <div className="flex items-center justify-between gap-2">
                        <span
                          className={`text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-md border ${
                            isAI
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                              : isHuman
                              ? 'bg-amber-50 text-amber-800 border-amber-200'
                              : 'bg-white text-slate-700 border-stone-200'
                          }`}
                        >
                          {log.actor_role}
                        </span>

                        <span className="text-[10px] text-slate-400 font-mono">
                          {new Date(log.created_at).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                            second: '2-digit',
                          })}
                        </span>
                      </div>

                      <p className="text-xs text-slate-700 leading-relaxed font-medium">
                        {log.details}
                      </p>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
