import React, { useState, useEffect } from 'react';
import { 
  Truck, 
  CheckCircle2, 
  Clock, 
  ShieldCheck, 
  KeyRound, 
  AlertCircle, 
  RefreshCw,
  MapPin,
  Phone,
  Package,
  Calendar,
  ArrowRight,
  Copy,
  Check,
  Snowflake,
  Info,
  CheckCircle,
  ChevronRight,
  ShieldAlert,
  Sparkles
} from 'lucide-react';
import { Donation } from '../types';
import { api } from '../api/client';
import { StatusBadge } from '../components/StatusBadge';

interface Props {
  initialDonationId?: string;
  onNavigate: (tab: string, id?: string) => void;
}

export const PickupTrackerPage: React.FC<Props> = ({ initialDonationId, onNavigate }) => {
  const [donations, setDonations] = useState<Donation[]>([]);
  const [selected, setSelected] = useState<Donation | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [updating, setUpdating] = useState<boolean>(false);
  const [verificationCode, setVerificationCode] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);

  const loadDonations = async () => {
    try {
      setLoading(true);
      const data = await api.listDonations();
      setDonations(data);
      
      if (initialDonationId) {
        const found = data.find((d) => d.id === initialDonationId);
        if (found) {
          setSelected(found);
          return;
        }
      }

      // Default selection
      if (!selected && data.length > 0) {
        const active = data.find((d) => d.status === 'IN_TRANSIT' || d.status === 'ACCEPTED') || data[0];
        setSelected(active);
      } else if (selected) {
        const refreshed = data.find((d) => d.id === selected.id);
        if (refreshed) {
          setSelected(refreshed);
        }
      }
    } catch (err: any) {
      console.error('Failed to load donations:', err);
      setError(err.message || 'Failed to fetch donations');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDonations();
  }, []);

  useEffect(() => {
    if (initialDonationId && donations.length > 0) {
      const match = donations.find((d) => d.id === initialDonationId);
      if (match) setSelected(match);
    }
  }, [initialDonationId, donations]);

  const handleSelect = (donation: Donation) => {
    setSelected(donation);
    setError(null);
    setSuccessMsg(null);
    setVerificationCode('');
  };

  const handleStatusUpdate = async (newStatus: string) => {
    if (!selected) return;
    try {
      setUpdating(true);
      setError(null);
      setSuccessMsg(null);
      const updated = await api.updateDonationStatus(
        selected.id,
        newStatus,
        newStatus === 'COLLECTED' ? verificationCode : undefined
      );
      setSuccessMsg(`Status transitioned to ${newStatus.replace('_', ' ')} successfully!`);
      setVerificationCode('');
      setSelected(updated);
      await loadDonations();
    } catch (err: any) {
      setError(err.message || 'Status transition failed. Please check the 4-digit verification code.');
    } finally {
      setUpdating(false);
    }
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  // 5 Step Visual Custody Progression Pipeline
  const steps = [
    { key: 'PROPOSED', label: 'Registered', desc: 'Surplus posted by donor' },
    { key: 'MATCHED', label: 'AI Evaluated', desc: 'Strands Decider 2B match' },
    { key: 'ACCEPTED', label: 'Offer Accepted', desc: 'Recipient NGO claimed' },
    { key: 'IN_TRANSIT', label: 'In Transit', desc: 'Driver en route to pickup' },
    { key: 'COLLECTED', label: 'Verified & Collected', desc: 'OTP handshake validated' },
  ];

  const getStepIndex = (status: string) => {
    switch (status) {
      case 'PROPOSED': return 0;
      case 'MATCHED': return 1;
      case 'ACCEPTED': return 2;
      case 'IN_TRANSIT': return 3;
      case 'COLLECTED': return 4;
      default: return -1;
    }
  };

  const currentStepIdx = selected ? getStepIndex(selected.status) : 0;

  // Filter donations
  const filteredDonations = donations.filter((d) => {
    if (statusFilter === 'ALL') return true;
    return d.status === statusFilter;
  });

  const countAccepted = donations.filter((d) => d.status === 'ACCEPTED').length;
  const countInTransit = donations.filter((d) => d.status === 'IN_TRANSIT').length;
  const countCollected = donations.filter((d) => d.status === 'COLLECTED').length;

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12">
      {/* Header Section */}
      <div className="bg-white rounded-3xl border border-stone-200 p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold">
              <Truck className="w-3.5 h-3.5 text-indigo-600" />
              <span>Chain of Custody Protocol</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900">
              Pickup & Collection Tracker
            </h1>
            <p className="text-sm sm:text-base text-slate-600 max-w-2xl leading-relaxed">
              Real-time dispatch telemetry and secure 4-digit cryptographic OTP handshakes from recipient acceptance to certified donor collection.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={loadDonations}
              disabled={loading}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-stone-100 hover:bg-stone-200 text-slate-700 font-semibold text-xs border border-stone-200 transition-colors"
              title="Refresh Donations"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
          </div>
        </div>
      </div>

      {/* Alert Messages */}
      {error && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 flex items-center justify-between text-rose-800 text-sm font-medium shadow-xs">
          <div className="flex items-center gap-2.5">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
            <span>{error}</span>
          </div>
          <button
            onClick={() => setError(null)}
            className="text-xs font-semibold underline hover:text-rose-900 ml-4"
          >
            Dismiss
          </button>
        </div>
      )}

      {successMsg && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-between text-emerald-800 text-sm font-medium shadow-xs">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{successMsg}</span>
          </div>
          <button
            onClick={() => setSuccessMsg(null)}
            className="text-xs font-semibold underline hover:text-emerald-900 ml-4"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Main Split Layout: Left List + Right Detail */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Filter Tabs & Donation Cards (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          {/* Status Filter Tabs */}
          <div className="bg-white rounded-2xl border border-stone-200 p-2 shadow-sm space-y-2">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-400 px-2 pt-1">
              Filter by Pipeline Status
            </div>
            <div className="grid grid-cols-2 gap-1.5 text-xs font-semibold">
              <button
                onClick={() => setStatusFilter('ALL')}
                className={`py-2 px-3 rounded-xl transition-all ${
                  statusFilter === 'ALL'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-stone-50'
                }`}
              >
                All ({donations.length})
              </button>
              <button
                onClick={() => setStatusFilter('ACCEPTED')}
                className={`py-2 px-3 rounded-xl transition-all ${
                  statusFilter === 'ACCEPTED'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-indigo-700 hover:bg-indigo-50'
                }`}
              >
                Accepted ({countAccepted})
              </button>
              <button
                onClick={() => setStatusFilter('IN_TRANSIT')}
                className={`py-2 px-3 rounded-xl transition-all ${
                  statusFilter === 'IN_TRANSIT'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-blue-700 hover:bg-blue-50'
                }`}
              >
                In Transit ({countInTransit})
              </button>
              <button
                onClick={() => setStatusFilter('COLLECTED')}
                className={`py-2 px-3 rounded-xl transition-all ${
                  statusFilter === 'COLLECTED'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-emerald-700 hover:bg-emerald-50'
                }`}
              >
                Collected ({countCollected})
              </button>
            </div>
          </div>

          {/* List of Donation Cards */}
          <div className="space-y-3 max-h-[750px] overflow-y-auto pr-1">
            {filteredDonations.length === 0 ? (
              <div className="bg-white rounded-2xl border border-stone-200 p-8 text-center text-slate-400 text-xs">
                No donations found matching "{statusFilter}".
              </div>
            ) : (
              filteredDonations.map((d) => {
                const isSelected = selected?.id === d.id;
                return (
                  <div
                    key={d.id}
                    onClick={() => handleSelect(d)}
                    className={`rounded-2xl p-4 border transition-all duration-200 cursor-pointer text-left ${
                      isSelected
                        ? 'bg-emerald-50/40 border-emerald-400 ring-2 ring-emerald-400/30 shadow-md'
                        : 'bg-white border-stone-200 hover:border-stone-300 hover:shadow-sm'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="font-bold text-slate-900 text-sm leading-snug truncate">
                        {d.food_title}
                      </h4>
                      <StatusBadge status={d.status} />
                    </div>

                    <p className="text-xs text-slate-600 mt-1 font-medium truncate">
                      {d.donor_name}
                    </p>

                    <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-stone-100 text-[11px] text-slate-400">
                      <span className="font-semibold text-slate-700">
                        {d.quantity_value} {d.quantity_unit} • {d.food_category}
                      </span>
                      <span className="flex items-center gap-1 font-mono">
                        <Clock className="w-3 h-3" />
                        {new Date(d.pickup_deadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column: Selected Donation Detail & Action Workflow (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          {selected ? (
            <>
              {/* Visual Timeline Card */}
              <div className="bg-white rounded-3xl border border-stone-200 p-6 sm:p-8 shadow-sm">
                <div className="flex items-center justify-between pb-6 border-b border-stone-100">
                  <div>
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      Live Dispatch Pipeline
                    </span>
                    <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 mt-0.5">
                      {selected.food_title}
                    </h2>
                  </div>
                  <StatusBadge status={selected.status} />
                </div>

                {/* Connected Visual Pipeline */}
                <div className="mt-8 px-2 sm:px-6">
                  <div className="relative">
                    {/* Background line */}
                    <div className="absolute top-4 sm:top-5 left-6 right-6 h-1 bg-stone-200 rounded-full" />
                    {/* Active progress line */}
                    <div
                      className="absolute top-4 sm:top-5 left-6 h-1 bg-emerald-500 rounded-full transition-all duration-500"
                      style={{
                        width: `${Math.max(0, Math.min(100, (currentStepIdx / (steps.length - 1)) * 100))}%`,
                      }}
                    />

                    <div className="grid grid-cols-5 relative z-10 text-center gap-1">
                      {steps.map((step, idx) => {
                        const isCompleted = idx < currentStepIdx;
                        const isCurrent = idx === currentStepIdx;
                        const isFuture = idx > currentStepIdx;

                        return (
                          <div key={step.key} className="flex flex-col items-center">
                            <div
                              className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-300 ${
                                isCurrent
                                  ? 'bg-amber-500 text-white ring-4 ring-amber-400/30 shadow-md shadow-amber-500/30 animate-pulse'
                                  : isCompleted
                                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                                  : 'bg-white border-2 border-stone-300 text-stone-400'
                              }`}
                            >
                              {isCompleted ? (
                                <CheckCircle2 className="w-5 h-5" />
                              ) : isCurrent ? (
                                <span className="font-mono text-sm">{idx + 1}</span>
                              ) : (
                                <span className="font-mono text-xs">{idx + 1}</span>
                              )}
                            </div>
                            <span className={`text-xs font-bold mt-2.5 transition-colors line-clamp-1 ${
                              isCurrent
                                ? 'text-amber-700'
                                : isCompleted
                                ? 'text-emerald-700'
                                : 'text-slate-400'
                            }`}>
                              {step.label}
                            </span>
                            <span className="hidden sm:block text-[10px] text-slate-400 mt-0.5 line-clamp-1 max-w-[90px]">
                              {step.desc}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>

              {/* Donation Details & Handoff Action Grid */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                {/* Full Details Specs (7 cols) */}
                <div className="md:col-span-7 bg-white rounded-3xl border border-stone-200 p-6 sm:p-8 shadow-sm space-y-6">
                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      Consignment Specifications
                    </h3>
                    <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                      <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200/70 space-y-1">
                        <span className="text-slate-400 font-medium flex items-center gap-1.5">
                          <Package className="w-3.5 h-3.5 text-slate-500" />
                          Volume & Category
                        </span>
                        <p className="text-sm font-bold text-slate-900">
                          {selected.quantity_value} {selected.quantity_unit}
                        </p>
                        <p className="text-slate-600 font-medium">{selected.food_category}</p>
                      </div>

                      <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200/70 space-y-1">
                        <span className="text-slate-400 font-medium flex items-center gap-1.5">
                          <Snowflake className="w-3.5 h-3.5 text-cyan-600" />
                          Storage & Diet
                        </span>
                        <p className="text-sm font-bold text-slate-900">
                          {selected.storage_requirement}
                        </p>
                        <p className="text-slate-600 font-medium">{selected.dietary_type || 'Regular'}</p>
                      </div>
                    </div>
                  </div>

                  {/* Donor Contact Card */}
                  <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200/70 space-y-2 text-xs">
                    <span className="text-slate-400 font-bold uppercase tracking-wider text-[10px] block">
                      Donor Pickup Location & Contact
                    </span>
                    <div className="space-y-1">
                      <p className="text-sm font-bold text-slate-900">{selected.donor_name}</p>
                      <p className="text-slate-600 flex items-start gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                        <span>{selected.donor_address}</span>
                      </p>
                      <p className="text-slate-600 flex items-center gap-1.5 pt-0.5">
                        <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="font-mono text-slate-700 font-medium">{selected.donor_contact}</span>
                      </p>
                    </div>
                  </div>

                  {/* Preparation & Deadline Timestamps */}
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="space-y-0.5">
                      <span className="text-slate-400 font-medium">Prepared At:</span>
                      <p className="font-semibold text-slate-800">
                        {new Date(selected.preparation_time).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                      </p>
                    </div>
                    <div className="space-y-0.5">
                      <span className="text-slate-400 font-medium">Safe Pickup Deadline:</span>
                      <p className="font-semibold text-amber-800">
                        {new Date(selected.pickup_deadline).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                      </p>
                    </div>
                  </div>

                  {selected.handling_instructions && (
                    <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200 text-xs text-slate-600">
                      <strong className="text-slate-800 block mb-0.5">Special Handling Guidelines:</strong>
                      <span>{selected.handling_instructions}</span>
                    </div>
                  )}

                  {selected.status === 'COLLECTED' && selected.collected_at && (
                    <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-800 space-y-2">
                      <div className="flex items-center gap-2 font-bold text-emerald-900 text-sm">
                        <ShieldCheck className="w-5 h-5 text-emerald-600" />
                        <span>Rescued & Verified Collection Complete!</span>
                      </div>
                      <p className="leading-relaxed">
                        Confirmed with cryptographic OTP verification on {new Date(selected.collected_at).toLocaleString()}. All surplus metrics have been credited towards zero food waste impact.
                      </p>
                    </div>
                  )}
                </div>

                {/* Transporter Handoff Actions & OTP Code (5 cols) */}
                <div className="md:col-span-5 bg-white rounded-3xl border border-stone-200 p-6 sm:p-8 shadow-sm flex flex-col justify-between space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      Physical Custody Verification
                    </h3>

                    {/* Prominent Verification Code Box */}
                    {selected.pickup_verification_code && selected.status !== 'COLLECTED' && (
                      <div className="rounded-2xl bg-gradient-to-br from-emerald-50 via-teal-50 to-emerald-50 border-2 border-emerald-300 p-5 text-center space-y-2 shadow-xs">
                        <span className="text-[11px] font-bold uppercase text-emerald-800 tracking-wider flex items-center justify-center gap-1.5">
                          <KeyRound className="w-3.5 h-3.5 text-emerald-700" />
                          Donor Pickup Verification Code
                        </span>

                        <div className="flex items-center justify-center gap-2">
                          <div className="font-mono text-4xl sm:text-5xl font-extrabold tracking-widest text-emerald-950 bg-white px-5 py-2.5 rounded-2xl border border-emerald-300 shadow-inner">
                            {selected.pickup_verification_code}
                          </div>
                          <button
                            onClick={() => copyCode(selected.pickup_verification_code!)}
                            className="p-2.5 text-emerald-700 hover:text-emerald-900 hover:bg-emerald-100 rounded-xl transition-colors"
                            title="Copy Code"
                          >
                            <Copy className="w-5 h-5" />
                          </button>
                        </div>

                        {copiedCode && (
                          <span className="text-xs font-semibold text-emerald-700 block animate-fade-in">
                            Copied to clipboard!
                          </span>
                        )}

                        <p className="text-[11px] text-emerald-900/80 leading-tight pt-1">
                          The transport driver presents this code to the donor upon physical arrival.
                        </p>
                      </div>
                    )}

                    {/* Status Action Workflow Buttons */}
                    <div className="space-y-3 pt-2">
                      {selected.status === 'ACCEPTED' && (
                        <div className="space-y-2">
                          <p className="text-xs text-slate-500">
                            Recipient NGO has claimed this offer. Dispatch driver to initiate transport.
                          </p>
                          <button
                            onClick={() => handleStatusUpdate('IN_TRANSIT')}
                            disabled={updating}
                            className="w-full flex items-center justify-center gap-2 py-3 px-5 bg-gradient-to-br from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-2xl text-xs sm:text-sm font-semibold shadow-md shadow-blue-600/20 hover:shadow-lg transition-all duration-300 disabled:opacity-50"
                          >
                            <Truck className="w-4 h-4" />
                            <span>{updating ? 'Updating Dispatch...' : 'Mark Driver In Transit'}</span>
                          </button>
                        </div>
                      )}

                      {selected.status === 'IN_TRANSIT' && (
                        <div className="space-y-3 pt-1">
                          <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-2">
                            <label className="block text-xs font-bold text-amber-900">
                              Enter Donor's 4-Digit Pickup Code:
                            </label>
                            <input
                              type="text"
                              maxLength={6}
                              value={verificationInputFormatted(verificationCode)}
                              onChange={(e) => setVerificationCode(e.target.value.trim())}
                              placeholder="e.g. 8491"
                              className="w-full py-2.5 px-4 text-center text-2xl font-mono tracking-widest font-extrabold text-slate-900 bg-white border-2 border-amber-300 rounded-xl focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/20 focus:outline-none"
                            />
                            <p className="text-[11px] text-amber-800">
                              Verified against donor cryptographic signature before custody is finalized.
                            </p>
                          </div>

                          <button
                            onClick={() => handleStatusUpdate('COLLECTED')}
                            disabled={updating || !verificationCode.trim()}
                            className="w-full flex items-center justify-center gap-2 py-3.5 px-5 bg-gradient-to-br from-emerald-600 to-teal-500 hover:from-emerald-700 hover:to-teal-600 text-white rounded-2xl text-xs sm:text-sm font-semibold shadow-md shadow-emerald-600/20 hover:shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            <CheckCircle2 className="w-4 h-4" />
                            <span>{updating ? 'Validating Handshake...' : 'Confirm Collection Handshake'}</span>
                          </button>
                        </div>
                      )}

                      {selected.status === 'COLLECTED' && (
                        <button
                          onClick={() => onNavigate('impact')}
                          className="w-full flex items-center justify-center gap-2 py-3.5 px-5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-2xl text-xs sm:text-sm font-semibold transition-colors shadow-xs"
                        >
                          <Sparkles className="w-4 h-4 text-emerald-600" />
                          <span>View Rescued Food in Impact Hub &rarr;</span>
                        </button>
                      )}

                      {selected.status === 'PROPOSED' && (
                        <button
                          onClick={() => onNavigate('matches', selected.id)}
                          className="w-full flex items-center justify-center gap-2 py-3 px-5 bg-stone-100 hover:bg-stone-200 text-slate-800 border border-stone-300 rounded-2xl text-xs font-semibold transition-colors"
                        >
                          <span>Evaluate in AI Matching Hub &rarr;</span>
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="pt-4 border-t border-stone-100 text-[11px] text-slate-400 space-y-1">
                    <p className="flex items-center gap-1.5 font-medium text-slate-500">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                      Tamper-evident immutable audit log recorded
                    </p>
                    <p>Only verified recipients & drivers are permitted to conclude custody transitions.</p>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="bg-white rounded-3xl border border-stone-200 p-16 text-center space-y-3 shadow-sm">
              <Truck className="w-10 h-10 text-slate-300 mx-auto" />
              <h3 className="text-base font-bold text-slate-800">No Donation Selected</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Select a consignment from the left list or filter options to review custody progression and enter handoff OTP verification.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Helper for display
function verificationInputFormatted(val: string): string {
  return val;
}
