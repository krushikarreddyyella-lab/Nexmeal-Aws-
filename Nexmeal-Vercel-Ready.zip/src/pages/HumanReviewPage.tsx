import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Sparkles, 
  Clock, 
  UserCheck, 
  RefreshCw,
  History,
  Info,
  MapPin,
  Building2,
  Package,
  ShieldCheck,
  Check,
  ArrowRight,
  Filter,
  FileText,
  Scale
} from 'lucide-react';
import { HumanReviewCase, AuditLogItem } from '../types';
import { api } from '../api/client';
import { DecisionBadge } from '../components/DecisionBadge';

export const HumanReviewPage: React.FC = () => {
  const [reviewCases, setReviewCases] = useState<HumanReviewCase[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [resolving, setResolving] = useState<string | null>(null);
  const [reviewNotes, setReviewNotes] = useState<Record<string, string>>({});
  const [notification, setNotification] = useState<{ text: string; isError?: boolean } | null>(null);
  const [auditFilter, setAuditFilter] = useState<string>('ALL');

  const loadData = async () => {
    try {
      setLoading(true);
      const [queueData, logs] = await Promise.all([
        api.getHumanReviewQueue(),
        api.getAuditLogs(50),
      ]);
      setReviewCases(queueData);
      setAuditLogs(logs);
    } catch (err: any) {
      console.error('Failed to load human review queue:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleResolve = async (matchId: string, action: 'APPROVE' | 'REJECT') => {
    const notes = reviewNotes[matchId] || (
      action === 'APPROVE'
        ? 'Approved after manual coordinator verification.'
        : 'Rejected by coordinator safety review.'
    );

    try {
      setResolving(matchId);
      setNotification(null);
      const res = await api.resolveHumanReview(matchId, action, notes);
      setNotification({ text: res.message || `Match ${action === 'APPROVE' ? 'Approved' : 'Rejected'} successfully.` });
      
      // Clean notes for resolved case
      setReviewNotes((prev) => {
        const next = { ...prev };
        delete next[matchId];
        return next;
      });

      await loadData();
    } catch (err: any) {
      setNotification({ text: err.message || 'Failed to resolve review case', isError: true });
    } finally {
      setResolving(null);
    }
  };

  const filteredLogs = auditLogs.filter((log) => {
    if (auditFilter === 'ALL') return true;
    return log.actor_role === auditFilter || log.event_type.includes(auditFilter);
  });

  return (
    <div className="space-y-10 max-w-7xl mx-auto pb-12">
      {/* Page Header */}
      <div className="bg-white rounded-3xl border border-stone-200 p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-semibold">
              <ShieldAlert className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
              <span>Policy Escalation & Safety Review</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900">
              Human Review Queue
            </h1>
            <p className="text-sm sm:text-base text-slate-600 max-w-2xl leading-relaxed">
              Escalated low-confidence, borderline proximity, or tight-deadline matches requiring human coordinator authorization before physical dispatch.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-amber-50 border border-amber-200">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
              <span className="text-xs font-bold text-amber-900">
                {reviewCases.length} Pending {reviewCases.length === 1 ? 'Case' : 'Cases'}
              </span>
            </div>

            <button
              onClick={loadData}
              disabled={loading}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-stone-100 hover:bg-stone-200 text-slate-700 font-semibold text-xs border border-stone-200 transition-colors"
              title="Refresh Review Data"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
          </div>
        </div>
      </div>

      {/* Notifications */}
      {notification && (
        <div className={`p-4 rounded-2xl flex items-center justify-between text-sm font-medium shadow-xs ${
          notification.isError
            ? 'bg-rose-50 text-rose-800 border border-rose-200'
            : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
        }`}>
          <div className="flex items-center gap-2.5">
            {notification.isError ? (
              <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
            ) : (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            )}
            <span>{notification.text}</span>
          </div>
          <button
            onClick={() => setNotification(null)}
            className="text-xs font-semibold underline ml-4 hover:opacity-80"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Active Escalation Cases Section */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold tracking-tight text-slate-900 flex items-center gap-2.5">
              <span>Pending Coordinator Decisions</span>
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 border border-amber-200">
                {reviewCases.length}
              </span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              Review AI reasoning factors, verify local logistics readiness, and record approval rationale.
            </p>
          </div>
        </div>

        {loading ? (
          <div className="bg-white rounded-3xl border border-stone-200 p-16 text-center space-y-3 shadow-sm">
            <RefreshCw className="w-8 h-8 text-amber-600 animate-spin mx-auto" />
            <p className="text-sm font-semibold text-slate-800">Loading escalation cases...</p>
          </div>
        ) : reviewCases.length === 0 ? (
          /* Celebratory Empty State */
          <div className="bg-white rounded-3xl border border-emerald-200 p-16 text-center space-y-4 shadow-sm">
            <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <div className="space-y-1.5 max-w-md mx-auto">
              <h3 className="text-xl font-bold text-slate-900">Human Review Queue is Clear!</h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                All surplus food allocations satisfied Strands Decider 2B automated confidence standards. No pending manual escalations require coordinator sign-off.
              </p>
            </div>
            <div className="pt-2">
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-full border border-emerald-200">
                <ShieldCheck className="w-4 h-4" />
                Zero-Spill Guardrails Active
              </span>
            </div>
          </div>
        ) : (
          /* Escalation Case Cards */
          <div className="space-y-6">
            {reviewCases.map((c) => {
              const isResolvingThis = resolving === c.match_id;
              const confidencePercent = Math.round(c.decider_confidence * 100);

              return (
                <div
                  key={c.match_id}
                  className="bg-white rounded-3xl border-2 border-amber-300 shadow-sm hover:shadow-md p-6 sm:p-8 space-y-6 transition-all duration-300 relative overflow-hidden"
                >
                  {/* Card Header Bar */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 border-b border-stone-100">
                    <div className="flex items-center gap-3">
                      <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-lg bg-stone-100 text-slate-700 border border-stone-200">
                        Case #{c.match_id.slice(0, 8)}
                      </span>
                      <DecisionBadge decision={c.decider_decision} confidence={c.decider_confidence} />
                    </div>

                    <div className="flex items-center gap-3 text-xs text-slate-400 font-mono">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span>
                        Escalated {new Date(c.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} ({new Date(c.created_at).toLocaleDateString([], { month: 'short', day: 'numeric' })})
                      </span>
                    </div>
                  </div>

                  {/* 3-Section Grid: Left Donation | Center Recipient | Right Decision Context */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                    {/* Left: Donation Information (4 cols) */}
                    <div className="lg:col-span-4 rounded-2xl bg-stone-50 border border-stone-200/80 p-5 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                          Surplus Consignment
                        </span>
                        <span className="text-[11px] font-mono text-slate-400">ID: {c.donation_id.slice(0, 8)}</span>
                      </div>

                      <div className="space-y-1">
                        <h4 className="text-base font-bold text-slate-900 leading-snug">
                          {c.donation_title}
                        </h4>
                        <div className="flex items-center gap-2 pt-1 text-xs text-slate-600 font-semibold">
                          <span className="px-2 py-0.5 rounded-md bg-white border border-stone-200">
                            {c.quantity}
                          </span>
                          <span className="px-2 py-0.5 rounded-md bg-white border border-stone-200">
                            {c.food_category}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Center: Recipient & Physical Match (4 cols) */}
                    <div className="lg:col-span-4 rounded-2xl bg-stone-50 border border-stone-200/80 p-5 space-y-3">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                        Candidate Recipient
                      </span>

                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h4 className="text-base font-bold text-slate-900">
                            {c.recipient_name}
                          </h4>
                        </div>
                        <p className="text-xs text-slate-500 font-medium">
                          {c.recipient_type}
                        </p>

                        <div className="pt-2 flex items-center justify-between text-xs">
                          <span className="flex items-center gap-1 font-semibold text-slate-700">
                            <MapPin className="w-3.5 h-3.5 text-slate-400" />
                            {c.distance_km.toFixed(1)} km away
                          </span>

                          <span className={`inline-flex items-center gap-1 font-semibold text-[11px] px-2 py-0.5 rounded-md border ${
                            c.safety_check_passed
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              : 'bg-amber-50 text-amber-700 border-amber-200'
                          }`}>
                            {c.safety_check_passed ? <Check className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                            {c.safety_check_passed ? 'Safety Passed' : 'Safety Check Warning'}
                          </span>
                        </div>

                        {/* Confidence Meter Bar */}
                        <div className="pt-2 space-y-1">
                          <div className="flex items-center justify-between text-[11px] font-semibold text-slate-600">
                            <span>Policy Model Confidence</span>
                            <span className="font-mono">{confidencePercent}%</span>
                          </div>
                          <div className="w-full h-2 bg-stone-200 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-amber-500 rounded-full transition-all duration-500"
                              style={{ width: `${confidencePercent}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Right: AI Decision Context & Advisory (4 cols) */}
                    <div className="lg:col-span-4 space-y-3">
                      {/* Decider Rationale */}
                      <div className="p-4 rounded-2xl bg-amber-50/50 border border-amber-200/80 space-y-1.5 text-xs">
                        <span className="font-bold text-amber-900 flex items-center gap-1.5">
                          <AlertTriangle className="w-3.5 h-3.5 text-amber-700" />
                          Strands Decider 2B Trigger Factors
                        </span>
                        <p className="text-amber-800 leading-relaxed font-medium">
                          {c.decider_rationale}
                        </p>
                      </div>

                      {/* Bedrock Advisory */}
                      {c.bedrock_explanation && (
                        <div className="p-4 rounded-2xl bg-gradient-to-br from-stone-50 to-white border border-stone-200 space-y-1 text-xs">
                          <span className="font-bold text-slate-800 flex items-center gap-1.5">
                            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                            Amazon Bedrock Advisory
                          </span>
                          <blockquote className="text-slate-600 italic leading-relaxed pt-0.5">
                            "{c.bedrock_explanation}"
                          </blockquote>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Coordinator Action Area: Notes & Resolution Buttons */}
                  <div className="pt-4 border-t border-stone-100 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
                    <div className="flex-1">
                      <input
                        type="text"
                        placeholder="Coordinator review notes (e.g. Phone confirmed dedicated driver en route, kitchen ready)..."
                        value={reviewNotes[c.match_id] || ''}
                        onChange={(e) => setReviewNotes({ ...reviewNotes, [c.match_id]: e.target.value })}
                        className="w-full px-4 py-3 text-xs sm:text-sm bg-stone-50 border border-stone-300 rounded-2xl focus:bg-white focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none transition-all placeholder:text-slate-400"
                      />
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <button
                        onClick={() => handleResolve(c.match_id, 'REJECT')}
                        disabled={isResolvingThis}
                        className="flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 font-semibold text-xs sm:text-sm transition-all shadow-xs disabled:opacity-50"
                      >
                        <XCircle className="w-4 h-4" />
                        <span>Reject Match</span>
                      </button>

                      <button
                        onClick={() => handleResolve(c.match_id, 'APPROVE')}
                        disabled={isResolvingThis}
                        className="flex items-center justify-center gap-2 px-6 py-3 rounded-2xl bg-gradient-to-br from-emerald-600 to-teal-500 hover:from-emerald-700 hover:to-teal-600 text-white font-semibold text-xs sm:text-sm shadow-md shadow-emerald-600/20 hover:shadow-lg transition-all disabled:opacity-50"
                      >
                        {isResolvingThis ? (
                          <>
                            <RefreshCw className="w-4 h-4 animate-spin" />
                            <span>Processing...</span>
                          </>
                        ) : (
                          <>
                            <UserCheck className="w-4 h-4" />
                            <span>Approve & Dispatch Offer</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Audit Log Trail Section */}
      <div className="bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-stone-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-stone-100 text-slate-700 flex items-center justify-center">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 tracking-tight">
                System Audit Trail & Governance Log
              </h3>
              <p className="text-xs text-slate-500">
                Immutable record of every AI decision, coordinator override, and chain-of-custody event.
              </p>
            </div>
          </div>

          {/* Actor Role Filter */}
          <div className="flex items-center gap-2">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={auditFilter}
              onChange={(e) => setAuditFilter(e.target.value)}
              className="px-3 py-1.5 text-xs font-semibold rounded-xl bg-stone-50 border border-stone-200 text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
            >
              <option value="ALL">All Event Types ({auditLogs.length})</option>
              <option value="COORDINATOR">Coordinator Actions</option>
              <option value="SYSTEM">System Automations</option>
              <option value="DRIVER">Driver Actions</option>
              <option value="ADMIN">Admin Events</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-stone-50 text-slate-500 font-semibold uppercase tracking-wider text-[10px] border-b border-stone-200">
              <tr>
                <th className="py-3.5 px-6">Timestamp</th>
                <th className="py-3.5 px-4">Actor</th>
                <th className="py-3.5 px-4">Event Type</th>
                <th className="py-3.5 px-4">Entity</th>
                <th className="py-3.5 px-6">Audit Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredLogs.slice(0, 30).map((log) => {
                const isCoordinator = log.actor_role === 'COORDINATOR';
                const isSystem = log.actor_role === 'SYSTEM';
                const isDriver = log.actor_role === 'DRIVER';

                return (
                  <tr key={log.id} className="hover:bg-stone-50/60 transition-colors">
                    <td className="py-3.5 px-6 font-mono text-slate-400 whitespace-nowrap">
                      {new Date(log.created_at).toLocaleString([], { dateStyle: 'short', timeStyle: 'medium' })}
                    </td>
                    <td className="py-3.5 px-4">
                      <span className={`inline-block px-2.5 py-0.5 rounded-full font-bold text-[10px] uppercase border ${
                        isCoordinator
                          ? 'bg-amber-50 text-amber-800 border-amber-200'
                          : isSystem
                          ? 'bg-purple-50 text-purple-800 border-purple-200'
                          : isDriver
                          ? 'bg-blue-50 text-blue-800 border-blue-200'
                          : 'bg-stone-100 text-slate-700 border-stone-200'
                      }`}>
                        {log.actor_role}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-slate-800 whitespace-nowrap">
                      {log.event_type}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                      {log.entity_type} ({log.entity_id.slice(0, 8)})
                    </td>
                    <td className="py-3.5 px-6 text-slate-600 max-w-md truncate font-medium">
                      {log.details || '—'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
