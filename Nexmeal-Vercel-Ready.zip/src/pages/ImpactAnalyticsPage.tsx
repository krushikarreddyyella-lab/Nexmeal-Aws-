import React, { useState, useEffect } from 'react';
import {
  Leaf,
  UtensilsCrossed,
  Truck,
  BarChart3,
  FileText,
  Sparkles,
  RefreshCw,
  CheckCircle,
  ArrowRight,
  Info,
  TrendingUp,
  ShieldCheck,
  Scale,
  Calendar,
  CheckCircle2,
  Clock,
  Layers,
  ChevronRight
} from 'lucide-react';
import { ImpactMetrics, BedrockImpactReport } from '../types';
import { api } from '../api/client';

export const ImpactAnalyticsPage: React.FC = () => {
  const [metrics, setMetrics] = useState<ImpactMetrics | null>(null);
  const [report, setReport] = useState<BedrockImpactReport | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [reportLoading, setReportLoading] = useState<boolean>(false);
  const [servingSize, setServingSize] = useState<number>(0.40);

  const loadMetrics = async (size: number) => {
    try {
      setLoading(true);
      const data = await api.getImpactMetrics(size);
      setMetrics(data);
    } catch (err) {
      console.error('Failed to load impact metrics:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadReport = async () => {
    try {
      setReportLoading(true);
      const rep = await api.getBedrockImpactReport(servingSize);
      setReport(rep);
    } catch (err) {
      console.error('Failed to generate Bedrock impact report:', err);
    } finally {
      setReportLoading(false);
    }
  };

  useEffect(() => {
    loadMetrics(servingSize);
  }, [servingSize]);

  // Color mapping for donation lifecycle statuses
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'COLLECTED':
        return {
          bar: 'bg-emerald-500',
          text: 'text-emerald-700',
          bg: 'bg-emerald-50',
          border: 'border-emerald-200',
        };
      case 'IN_TRANSIT':
        return {
          bar: 'bg-blue-500',
          text: 'text-blue-700',
          bg: 'bg-blue-50',
          border: 'border-blue-200',
        };
      case 'ACCEPTED':
        return {
          bar: 'bg-indigo-500',
          text: 'text-indigo-700',
          bg: 'bg-indigo-50',
          border: 'border-indigo-200',
        };
      case 'MATCHED':
        return {
          bar: 'bg-teal-500',
          text: 'text-teal-700',
          bg: 'bg-teal-50',
          border: 'border-teal-200',
        };
      case 'PROPOSED':
        return {
          bar: 'bg-amber-500',
          text: 'text-amber-700',
          bg: 'bg-amber-50',
          border: 'border-amber-200',
        };
      case 'REJECTED':
        return {
          bar: 'bg-rose-500',
          text: 'text-rose-700',
          bg: 'bg-rose-50',
          border: 'border-rose-200',
        };
      case 'EXPIRED':
        return {
          bar: 'bg-stone-400',
          text: 'text-stone-700',
          bg: 'bg-stone-100',
          border: 'border-stone-300',
        };
      default:
        return {
          bar: 'bg-stone-400',
          text: 'text-stone-700',
          bg: 'bg-stone-100',
          border: 'border-stone-200',
        };
    }
  };

  const totalDonations = metrics?.total_donations || 1;
  const totalRescuedKg = metrics?.total_kg_rescued ?? 0;

  return (
    <div className="space-y-8 pb-12">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-white via-white to-stone-50/60 p-6 sm:p-10 border border-stone-200/80 shadow-sm">
        {/* Subtle decorative background gradient circles */}
        <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-emerald-500/5 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-96 h-96 rounded-full bg-amber-500/5 blur-3xl pointer-events-none" />

        <div className="relative flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200/80">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>Section 9 Verified Isolation Guarantee</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="p-3 bg-gradient-to-br from-emerald-500 to-teal-600 text-white rounded-2xl shadow-sm">
                <Leaf className="w-7 h-7" />
              </div>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-slate-900">
                Impact Analytics
              </h1>
            </div>
            <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
              Measuring rescued food, meals served, and environmental sustainability. Strictly isolates verified collections to eliminate false or premature impact reporting.
            </p>
          </div>

          {/* Serving Size Parameter Selector & Refresh */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 bg-white/90 backdrop-blur-xl p-4 sm:p-5 rounded-2xl border border-stone-200 shadow-sm shrink-0">
            <div className="space-y-2">
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700">
                  <Scale className="w-3.5 h-3.5 text-amber-500" />
                  <span>Serving Assumption</span>
                </div>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-md bg-stone-100 text-slate-900 border border-stone-200">
                  {(servingSize * 1000).toFixed(0)}g / meal
                </span>
              </div>

              {/* Slider Control */}
              <div className="flex items-center gap-3">
                <input
                  type="range"
                  min="0.25"
                  max="0.60"
                  step="0.05"
                  value={servingSize}
                  onChange={(e) => setServingSize(parseFloat(e.target.value))}
                  className="w-36 sm:w-44 accent-emerald-600 cursor-pointer"
                  aria-label="Serving size in kg"
                />
              </div>

              {/* Quick Presets */}
              <div className="flex items-center gap-1.5 pt-0.5">
                {[0.30, 0.40, 0.50].map((preset) => (
                  <button
                    key={preset}
                    onClick={() => setServingSize(preset)}
                    className={`px-2 py-0.5 text-[10px] font-medium rounded transition-all ${
                      servingSize === preset
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'bg-stone-100 text-slate-600 hover:bg-stone-200'
                    }`}
                  >
                    {(preset * 1000).toFixed(0)}g
                  </button>
                ))}
              </div>
            </div>

            <div className="hidden sm:block w-px h-12 bg-stone-200 mx-1" />

            <button
              onClick={() => loadMetrics(servingSize)}
              disabled={loading}
              title="Refresh Analytics"
              className="flex items-center justify-center p-3 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-xl border border-stone-200 transition-all self-end sm:self-center"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-emerald-600' : ''}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Key Metrics Row (Apple Keynote Style) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Card 1: Rescued Surplus Food */}
        <div className="relative group bg-white p-6 rounded-2xl border border-stone-200/90 shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-emerald-500 to-teal-500" />
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Total Rescued Food
              </span>
              <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-600 group-hover:scale-110 transition-transform">
                <Leaf className="w-5 h-5" />
              </div>
            </div>
            <div className="mt-4 flex items-baseline gap-2">
              <span className="text-4xl sm:text-5xl font-extrabold tracking-tight text-slate-900 font-sans">
                {metrics?.total_kg_rescued?.toLocaleString() ?? 0}
              </span>
              <span className="text-lg font-medium text-slate-400">kg</span>
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between text-xs">
            <span className="text-slate-500">Verified Completed Pickups</span>
            <span className="inline-flex items-center gap-1 font-semibold text-emerald-600">
              <CheckCircle className="w-3.5 h-3.5" /> 100% Isolated
            </span>
          </div>
        </div>

        {/* Card 2: Estimated Meals Served */}
        <div className="relative group bg-white p-6 rounded-2xl border border-stone-200/90 shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-amber-500 to-orange-500" />
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Estimated Meals Served
              </span>
              <div className="p-2.5 rounded-xl bg-amber-50 text-amber-600 group-hover:scale-110 transition-transform">
                <UtensilsCrossed className="w-5 h-5" />
              </div>
            </div>
            <div className="mt-4 flex items-baseline gap-2">
              <span className="text-4xl sm:text-5xl font-extrabold tracking-tight text-amber-600 font-sans">
                {metrics?.estimated_meals_served?.toLocaleString() ?? 0}
              </span>
              <span className="text-xs font-medium text-amber-700/70 uppercase tracking-wider">
                meals
              </span>
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between text-xs">
            <span className="text-slate-500">Portion Model</span>
            <span className="font-mono text-slate-700 font-semibold">
              {(servingSize * 1000).toFixed(0)}g / portion
            </span>
          </div>
        </div>

        {/* Card 3: CO2e Landfill Diverted */}
        <div className="relative group bg-white p-6 rounded-2xl border border-stone-200/90 shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-teal-500 to-emerald-600" />
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                CO2e Landfill Diverted
              </span>
              <div className="p-2.5 rounded-xl bg-teal-50 text-teal-600 group-hover:scale-110 transition-transform">
                <TrendingUp className="w-5 h-5" />
              </div>
            </div>
            <div className="mt-4 flex items-baseline gap-2">
              <span className="text-4xl sm:text-5xl font-extrabold tracking-tight text-slate-900 font-sans">
                {metrics?.co2_avoided_kg?.toLocaleString() ?? 0}
              </span>
              <span className="text-lg font-medium text-slate-400">kg</span>
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between text-xs">
            <span className="text-slate-500">EPA Standard Ratio</span>
            <span className="font-semibold text-teal-700">2.5 kg CO2e / kg food</span>
          </div>
        </div>

        {/* Card 4: Collection Rate */}
        <div className="relative group bg-white p-6 rounded-2xl border border-stone-200/90 shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-indigo-500 to-purple-600" />
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Collection Rate
              </span>
              <div className="p-2.5 rounded-xl bg-indigo-50 text-indigo-600 group-hover:scale-110 transition-transform">
                <CheckCircle className="w-5 h-5" />
              </div>
            </div>
            <div className="mt-4 flex items-baseline gap-2">
              <span className="text-4xl sm:text-5xl font-extrabold tracking-tight text-slate-900 font-sans">
                {metrics?.collection_rate_percent ?? 0}
              </span>
              <span className="text-2xl font-bold text-indigo-600">%</span>
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between text-xs">
            <span className="text-slate-500">Pickups Finalized</span>
            <span className="font-semibold text-slate-800">
              {metrics?.completed_pickups ?? 0} of {(metrics?.completed_pickups ?? 0) + (metrics?.rejected_or_expired ?? 0)}
            </span>
          </div>
        </div>
      </div>

      {/* Operational Pipeline Ledger */}
      <div className="bg-white rounded-2xl border border-stone-200 shadow-sm p-5 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-stone-100">
          <div className="flex items-center gap-2.5">
            <Layers className="w-4 h-4 text-emerald-600" />
            <h3 className="text-sm font-bold text-slate-900">
              Lifecycle Stage Isolation Ledger
            </h3>
          </div>
          <span className="text-xs text-slate-500">
            Total Donations Tracked: <strong className="text-slate-900 font-mono">{metrics?.total_donations ?? 0}</strong>
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4">
          <div className="p-3.5 rounded-xl bg-stone-50 border border-stone-200/80">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span>Verified Rescued</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
            </div>
            <div className="text-xl font-bold text-slate-900 mt-1 font-mono">
              {metrics?.completed_pickups ?? 0}
            </div>
            <p className="text-[11px] text-emerald-700 font-medium mt-0.5">
              Included in impact metrics
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-stone-50 border border-stone-200/80">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span>Active Pipeline</span>
              <span className="w-2 h-2 rounded-full bg-amber-500" />
            </div>
            <div className="text-xl font-bold text-slate-900 mt-1 font-mono">
              {metrics?.pending_offers ?? 0}
            </div>
            <p className="text-[11px] text-amber-700 font-medium mt-0.5">
              Pending Decider/Recipient
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-stone-50 border border-stone-200/80">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span>In Transit Fleet</span>
              <span className="w-2 h-2 rounded-full bg-blue-500" />
            </div>
            <div className="text-xl font-bold text-slate-900 mt-1 font-mono">
              {metrics?.in_transit ?? 0}
            </div>
            <p className="text-[11px] text-blue-700 font-medium mt-0.5">
              Excluded until verification
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-stone-50 border border-stone-200/80">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span>Rejected / Expired</span>
              <span className="w-2 h-2 rounded-full bg-rose-500" />
            </div>
            <div className="text-xl font-bold text-slate-900 mt-1 font-mono">
              {metrics?.rejected_or_expired ?? 0}
            </div>
            <p className="text-[11px] text-rose-700 font-medium mt-0.5">
              Safety gate exclusions
            </p>
          </div>
        </div>
      </div>

      {/* Status Breakdown & Category Breakdown Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Status Distribution */}
        <div className="bg-white rounded-2xl border border-stone-200 shadow-sm p-6 space-y-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Donation Status Distribution
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Visual distribution across all donation lifecycle states.
                </p>
              </div>
              <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-stone-100 text-slate-700">
                {metrics?.total_donations ?? 0} donations
              </span>
            </div>

            <div className="space-y-3.5 mt-5">
              {metrics?.status_breakdown &&
                Object.entries(metrics.status_breakdown).map(([status, count]) => {
                  const pct = Math.round((count / totalDonations) * 100);
                  const colors = getStatusColor(status);

                  return (
                    <div key={status} className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <span className={`px-2 py-0.5 rounded text-[11px] font-semibold ${colors.bg} ${colors.text} border ${colors.border}`}>
                            {status}
                          </span>
                          {status === 'COLLECTED' && (
                            <span className="text-[10px] text-emerald-700 font-medium">
                              (Impact Counted)
                            </span>
                          )}
                        </div>
                        <span className="font-mono text-slate-600 font-medium">
                          {count} <span className="text-slate-400">({pct}%)</span>
                        </span>
                      </div>
                      <div className="w-full h-2.5 bg-stone-100 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-500 ${colors.bar}`}
                          style={{ width: `${Math.max(pct, count > 0 ? 3 : 0)}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>

          <div className="p-4 bg-stone-50 rounded-xl border border-stone-200/80 text-xs text-slate-600 flex items-start gap-2.5 mt-4">
            <Info className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              <strong>Section 9 Isolation Rule:</strong> Estimated meals served is an analytical approximation based on {(servingSize * 1000).toFixed(0)}g portions. In-transit items and pending offers are strictly excluded from rescued impact metrics until verified collection handoff.
            </p>
          </div>
        </div>

        {/* Rescued Categories Breakdown */}
        <div className="bg-white rounded-2xl border border-stone-200 shadow-sm p-6 space-y-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Rescued Food By Category
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Verified collected quantities and estimated portions.
                </p>
              </div>
              <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                Completed Pickups Only
              </span>
            </div>

            <div className="space-y-3.5 mt-5">
              {metrics?.category_breakdown &&
              Object.keys(metrics.category_breakdown).length > 0 ? (
                Object.entries(metrics.category_breakdown).map(([category, kg]) => {
                  const pct = totalRescuedKg > 0 ? Math.round((kg / totalRescuedKg) * 100) : 0;
                  const estimatedMeals = Math.round(kg / servingSize);

                  return (
                    <div
                      key={category}
                      className="p-4 rounded-xl bg-stone-50/70 border border-stone-200/80 hover:bg-stone-50 transition-colors space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-slate-900 text-sm">
                            {category}
                          </span>
                          <span className="text-xs text-slate-400 font-mono">
                            {pct}% of volume
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-emerald-700 font-mono">
                            {kg} kg
                          </span>
                          <span className="text-xs text-slate-500 font-mono bg-white px-2 py-0.5 rounded border border-stone-200">
                            ~{estimatedMeals.toLocaleString()} meals
                          </span>
                        </div>
                      </div>

                      {/* Visual Category Bar */}
                      <div className="w-full h-1.5 bg-stone-200/70 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 transition-all duration-500"
                          style={{ width: `${Math.max(pct, 4)}%` }}
                        />
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-12 px-4 rounded-xl border border-dashed border-stone-200 space-y-3">
                  <div className="w-12 h-12 mx-auto rounded-full bg-stone-100 flex items-center justify-center text-slate-400">
                    <UtensilsCrossed className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-slate-800">
                      No Rescued Category Records
                    </h3>
                    <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                      Completed pickup records will automatically populate category volume metrics here.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="pt-2 text-xs text-slate-400 flex items-center justify-between border-t border-stone-100">
            <span>Aggregated across all recipient partners</span>
            <span className="font-mono text-slate-600 font-semibold">Total: {totalRescuedKg} kg</span>
          </div>
        </div>
      </div>

      {/* Amazon Bedrock Impact Report Section */}
      <div className="bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden">
        {/* Header Bar */}
        <div className="p-6 sm:p-8 bg-gradient-to-b from-stone-50/80 to-white border-b border-stone-200/80">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-50 text-amber-800 border border-amber-200">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                <span>Amazon Bedrock Foundation Model Synthesis</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
                Executive Impact & ESG Report
              </h2>
              <p className="text-xs sm:text-sm text-slate-500">
                Automated generative synthesis of community outcomes, portion narratives, and stakeholder ESG advisories.
              </p>
            </div>

            <button
              onClick={loadReport}
              disabled={reportLoading}
              className="flex items-center justify-center gap-2 px-5 py-3 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white rounded-xl text-xs sm:text-sm font-semibold shadow-sm hover:shadow-md transition-all disabled:opacity-60 shrink-0"
            >
              <Sparkles className={`w-4 h-4 ${reportLoading ? 'animate-spin' : ''}`} />
              <span>{reportLoading ? 'Synthesizing with Bedrock...' : report ? 'Regenerate AI Report' : 'Generate AI Report'}</span>
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8">
          {report ? (
            <div className="space-y-6">
              {/* Report Metadata */}
              <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500 pb-2 border-b border-stone-100">
                <div className="flex items-center gap-2">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>Generated: <strong className="text-slate-700">{report.generated_at}</strong></span>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                      report.is_live_bedrock
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'bg-stone-100 text-slate-700 border border-stone-200'
                    }`}
                  >
                    <span className={`w-1.5 h-1.5 rounded-full ${report.is_live_bedrock ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'}`} />
                    {report.is_live_bedrock ? 'AWS Bedrock Live (Claude 3 Haiku)' : 'Deterministic Bedrock Fallback'}
                  </span>
                </div>
              </div>

              {/* Executive Summary Blockquote Card */}
              <div className="relative p-6 sm:p-7 rounded-2xl bg-amber-50/50 border border-amber-200/90 shadow-xs space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-800">
                  <FileText className="w-4 h-4 text-amber-600" />
                  <span>Executive Impact Summary</span>
                </div>
                <blockquote className="text-sm sm:text-base text-slate-800 leading-relaxed font-serif italic">
                  "{report.executive_summary}"
                </blockquote>
              </div>

              {/* Two Column: Operational Highlights & ESG Recommendations */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Highlights */}
                <div className="p-5 sm:p-6 rounded-2xl bg-stone-50 border border-stone-200 space-y-4">
                  <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Operational Highlights</span>
                  </div>
                  <ul className="space-y-3">
                    {report.highlights.map((highlight, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-600">
                        <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                        <span className="leading-snug">{highlight}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* ESG Recommendations */}
                <div className="p-5 sm:p-6 rounded-2xl bg-stone-50 border border-stone-200 space-y-4">
                  <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
                    <ArrowRight className="w-4 h-4 text-amber-600" />
                    <span>ESG & Logistics Recommendations</span>
                  </div>
                  <ol className="space-y-3">
                    {report.esg_recommendations.map((rec, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-600">
                        <span className="flex items-center justify-center w-5 h-5 rounded-full bg-amber-100 text-amber-800 font-bold text-[11px] shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <span className="leading-snug">{rec}</span>
                      </li>
                    ))}
                  </ol>
                </div>
              </div>

              {/* Meals Narrative */}
              <div className="p-5 sm:p-6 rounded-2xl bg-emerald-50/60 border border-emerald-200 text-xs sm:text-sm text-emerald-900 flex items-start gap-3">
                <UtensilsCrossed className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h4 className="font-bold text-emerald-950">Meals Equivalent Narrative</h4>
                  <p className="leading-relaxed text-emerald-900/90">{report.meals_served_narrative}</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="py-12 px-6 text-center rounded-2xl border border-dashed border-stone-200 space-y-4">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center">
                <Sparkles className="w-7 h-7" />
              </div>
              <div className="max-w-md mx-auto space-y-1">
                <h3 className="text-base font-bold text-slate-900">
                  Ready to Synthesize AI Impact Narrative
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Generate a publication-ready ESG narrative based on verified pickup metrics, portion modeling, and environmental carbon diversion formulas.
                </p>
              </div>
              <button
                onClick={loadReport}
                disabled={reportLoading}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white rounded-xl text-xs font-semibold shadow-sm transition-all"
              >
                <Sparkles className="w-4 h-4" />
                <span>Generate Narrative Now</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ImpactAnalyticsPage;
