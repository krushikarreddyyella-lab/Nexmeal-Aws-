import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { SystemModeBanner } from './components/SystemModeBanner';
import { HomePage } from './pages/HomePage';
import { DiscoverPage } from './pages/DiscoverPage';
import { DonorDashboardPage } from './pages/DonorDashboardPage';
import { NgoDashboardPage } from './pages/NgoDashboardPage';
import { MatchingHubPage } from './pages/MatchingHubPage';
import { RecipientDirectoryPage } from './pages/RecipientDirectoryPage';
import { PickupTrackerPage } from './pages/PickupTrackerPage';
import { HumanReviewPage } from './pages/HumanReviewPage';
import { ImpactAnalyticsPage } from './pages/ImpactAnalyticsPage';
import { EvaluationPage } from './pages/EvaluationPage';
import { DonationDetailModal } from './components/DonationDetailModal';
import { QuickDonateModal } from './components/QuickDonateModal';
import { RoleSwitcherModal } from './components/RoleSwitcherModal';
import { PickupOtpModal } from './components/PickupOtpModal';
import { DeveloperModal } from './components/DeveloperModal';
import { Donation, Recipient, ImpactMetrics, UserProfile } from './types';
import { api } from './api/client';
import { mockUserProfiles } from './api/mockData';
import { NexmealLogo } from './components/NexmealLogo';
import { CheckCircle2, AlertCircle, HeartHandshake, ShieldCheck, Sparkles, Cpu, ArrowRight, Code2 } from 'lucide-react';

export function App() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [contextId, setContextId] = useState<string | undefined>();
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  // App Data State
  const [donations, setDonations] = useState<Donation[]>([]);
  const [recipients, setRecipients] = useState<Recipient[]>([]);
  const [impact, setImpact] = useState<ImpactMetrics | null>(null);
  const [reviewCount, setReviewCount] = useState<number>(0);
  const [isLiveBedrock, setIsLiveBedrock] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);

  // Active User Profile State
  const [currentUser, setCurrentUser] = useState<UserProfile>(mockUserProfiles[0]);

  // Modal States
  const [selectedDonation, setSelectedDonation] = useState<Donation | null>(null);
  const [isDonateModalOpen, setIsDonateModalOpen] = useState<boolean>(false);
  const [isRoleSwitcherOpen, setIsRoleSwitcherOpen] = useState<boolean>(false);
  const [otpModalDonationId, setOtpModalDonationId] = useState<string | null>(null);
  const [isDeveloperModalOpen, setIsDeveloperModalOpen] = useState<boolean>(false);

  // Toast State
  const [toast, setToast] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToast({ text, type });
    setTimeout(() => setToast(null), 4500);
  };

  // Load All System Data
  const refreshData = async () => {
    try {
      const [dons, recs, imp, queue, status] = await Promise.all([
        api.listDonations(),
        api.listRecipients(),
        api.getImpactMetrics(),
        api.getHumanReviewQueue(),
        api.getSystemStatus().catch(() => null),
      ]);
      setDonations(dons);
      setRecipients(recs);
      setImpact(imp);
      setReviewCount(queue.length);
      if (status?.ai_engine) {
        setIsLiveBedrock(Boolean(status.ai_engine.is_live_bedrock));
      }
    } catch (err) {
      console.warn('Data load error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshData();
    const interval = setInterval(refreshData, 30000);
    return () => clearInterval(interval);
  }, []);

  // Smooth scroll to top on tab change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeTab]);

  const handleNavigate = (tab: string, id?: string) => {
    if (id) setContextId(id);
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Action: Register Donation
  const handleCreateDonation = async (data: Partial<Donation>): Promise<Donation> => {
    const created = await api.createDonation(data);
    showToast(`Surplus registered! Handover OTP: ${created.pickup_verification_code}`, 'success');
    await refreshData();
    return created;
  };

  // Action: Accept Offer
  const handleAcceptMatch = async (matchId: string) => {
    try {
      const res = await api.acceptMatch(matchId);
      showToast(`Offer accepted! Handover verification code is ${res.pickup_verification_code}.`, 'success');
      await refreshData();
    } catch (err: any) {
      showToast(err?.message || 'Could not accept offer.', 'error');
    }
  };

  // Action: Confirm Pickup with OTP
  const handleConfirmPickup = async (donationId: string, code: string) => {
    try {
      await api.updateDonationStatus(donationId, 'COLLECTED', code);
      showToast('Pickup verified! Handover completed and impact logged.', 'success');
      await refreshData();
    } catch (err: any) {
      throw err;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAFAF6] text-[#17211C] font-sans selection:bg-[#E4F4EE] selection:text-[#103B2D]">
      {/* Toast Notification Banner */}
      {toast && (
        <div className="fixed top-24 right-4 z-50 max-w-md animate-fade-in">
          <div className={`p-4 rounded-2xl shadow-elevated border flex items-center gap-3 ${
            toast.type === 'success'
              ? 'bg-[#103B2D] text-white border-emerald-700'
              : 'bg-rose-900 text-white border-rose-700'
          }`}>
            {toast.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-5 h-5 text-rose-300 shrink-0" />
            )}
            <span className="text-xs sm:text-sm font-semibold">{toast.text}</span>
          </div>
        </div>
      )}

      {/* Top System Status Ribbon */}
      <SystemModeBanner isLiveBedrock={isLiveBedrock} />

      {/* Glassmorphic Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={(t) => {
          setActiveTab(t);
          setContextId(undefined);
        }}
        reviewCount={reviewCount}
        currentUser={currentUser}
        onOpenDonateModal={() => setIsDonateModalOpen(true)}
        onOpenRoleSwitcher={() => setIsRoleSwitcherOpen(true)}
        onOpenDeveloperModal={() => setIsDeveloperModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
        {/* 1. Flagship Homepage */}
        {activeTab === 'home' && (
          <HomePage
            donations={donations}
            impact={impact}
            onNavigate={handleNavigate}
            onOpenDonateModal={() => setIsDonateModalOpen(true)}
            onSelectDonation={(d) => setSelectedDonation(d)}
            onSelectCategory={(cat) => {
              setSelectedCategory(cat);
              handleNavigate('discover');
            }}
          />
        )}

        {/* 2. Swiggy/Zomato-grade Food Rescue Discovery */}
        {activeTab === 'discover' && (
          <DiscoverPage
            donations={donations}
            initialCategory={selectedCategory}
            onNavigate={handleNavigate}
            onSelectDonation={(d) => setSelectedDonation(d)}
            onOpenDonateModal={() => setIsDonateModalOpen(true)}
          />
        )}

        {/* 3. Donor Dashboard */}
        {activeTab === 'donor' && (
          <DonorDashboardPage
            donations={donations}
            currentUser={currentUser}
            onNavigate={handleNavigate}
            onOpenDonateModal={() => setIsDonateModalOpen(true)}
            onSelectDonation={(d) => setSelectedDonation(d)}
          />
        )}

        {/* 4. NGO Dashboard */}
        {activeTab === 'ngo' && (
          <NgoDashboardPage
            donations={donations}
            recipients={recipients}
            currentUser={currentUser}
            onNavigate={handleNavigate}
            onAcceptOffer={handleAcceptMatch}
            onOpenConfirmPickup={(id) => setOtpModalDonationId(id)}
            onSelectDonation={(d) => setSelectedDonation(d)}
          />
        )}

        {/* 5. AI Matching Hub (Strands Decider 2B & Amazon Bedrock showcase) */}
        {activeTab === 'matches' && (
          <MatchingHubPage
            initialDonationId={contextId}
            onNavigate={handleNavigate}
          />
        )}

        {/* 6. Pickup & Chain-of-Custody Tracker */}
        {activeTab === 'pickups' && (
          <PickupTrackerPage
            initialDonationId={contextId}
            onNavigate={handleNavigate}
          />
        )}

        {/* 7. Human Review Escalation Queue */}
        {activeTab === 'reviews' && <HumanReviewPage />}

        {/* 8. Verified NGO Directory */}
        {activeTab === 'recipients' && <RecipientDirectoryPage />}

        {/* 9. Impact Analytics & ESG Reports */}
        {activeTab === 'impact' && <ImpactAnalyticsPage />}

        {/* 10. Benchmark Evaluation */}
        {activeTab === 'eval' && <EvaluationPage />}

        {/* Legacy Donate Route Fallback */}
        {activeTab === 'donate' && (
          <DonorDashboardPage
            donations={donations}
            currentUser={currentUser}
            onNavigate={handleNavigate}
            onOpenDonateModal={() => setIsDonateModalOpen(true)}
            onSelectDonation={(d) => setSelectedDonation(d)}
          />
        )}
      </main>

      {/* Global Modals */}
      <DonationDetailModal
        donation={selectedDonation}
        onClose={() => setSelectedDonation(null)}
        onMatch={(id) => handleNavigate('matches', id)}
        onTrackPickup={(id) => handleNavigate('pickups', id)}
        onConfirmHandover={(id) => setOtpModalDonationId(id)}
      />

      <QuickDonateModal
        isOpen={isDonateModalOpen}
        onClose={() => setIsDonateModalOpen(false)}
        onSubmit={handleCreateDonation}
        onSuccessNavigate={(newId) => handleNavigate('matches', newId)}
      />

      <RoleSwitcherModal
        isOpen={isRoleSwitcherOpen}
        onClose={() => setIsRoleSwitcherOpen(false)}
        currentUser={currentUser}
        onSelectUser={(u) => {
          setCurrentUser(u);
          showToast(`Switched active perspective to ${u.name} (${u.role.toUpperCase()})`);
        }}
      />

      <PickupOtpModal
        isOpen={!!otpModalDonationId}
        onClose={() => setOtpModalDonationId(null)}
        donationId={otpModalDonationId || ''}
        expectedCode={donations.find((d) => d.id === otpModalDonationId)?.pickup_verification_code}
        onConfirm={handleConfirmPickup}
      />

      {/* Developer Profile Modal */}
      <DeveloperModal
        isOpen={isDeveloperModalOpen}
        onClose={() => setIsDeveloperModalOpen(false)}
      />

      {/* Premium Footer */}
      <footer className="mt-auto bg-white border-t border-stone-200/80">
        <div className="h-0.5 w-full bg-gradient-to-r from-transparent via-[#103B2D]/40 to-transparent" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 lg:gap-12">
            {/* Column 1: Brand & Purpose */}
            <div className="lg:col-span-5 space-y-4">
              <NexmealLogo size="md" tagline={true} />

              <p className="text-xs text-stone-600 leading-relaxed max-w-sm">
                Empowering kitchens, caterers, hotels, and banquets to divert edible surplus into local communities before pickup deadlines. Powered by Strands Decider 2B and Amazon Bedrock.
              </p>

              <div className="pt-1 flex flex-wrap items-center gap-2">
                <button
                  onClick={() => setIsDeveloperModalOpen(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-[#E4F4EE] text-stone-800 hover:text-[#103B2D] text-xs font-bold transition-all border border-stone-200/80 shadow-2xs cursor-pointer"
                >
                  <Code2 className="w-3.5 h-3.5 text-emerald-700" />
                  <span>About Developer: KRUSHIKAR REDDY YELLA</span>
                </button>
              </div>

              <div className="pt-1 text-[11px] text-[#103B2D] font-medium">
                Surplus today. Sustenance tomorrow.
              </div>
            </div>

            {/* Column 2: Navigation */}
            <div className="lg:col-span-3 space-y-3">
              <h4 className="text-xs font-bold font-display uppercase tracking-wider text-stone-900">
                Platform Navigation
              </h4>
              <ul className="space-y-2 text-xs text-stone-600">
                <li><button onClick={() => handleNavigate('home')} className="hover:text-emerald-800 transition-colors">Home Page</button></li>
                <li><button onClick={() => handleNavigate('discover')} className="hover:text-emerald-800 transition-colors">Surplus Food Discovery</button></li>
                <li><button onClick={() => handleNavigate('donor')} className="hover:text-emerald-800 transition-colors">Donor Portal</button></li>
                <li><button onClick={() => handleNavigate('ngo')} className="hover:text-emerald-800 transition-colors">NGO Intake Hub</button></li>
                <li><button onClick={() => handleNavigate('impact')} className="hover:text-emerald-800 transition-colors">Impact Analytics & ESG</button></li>
              </ul>
            </div>

            {/* Column 3: AI & Safety Architecture */}
            <div className="lg:col-span-4 space-y-3">
              <h4 className="text-xs font-bold font-display uppercase tracking-wider text-stone-900">
                Technical Stack & Safety
              </h4>
              <div className="space-y-2 text-xs text-stone-600">
                <div className="p-3 rounded-xl bg-[#FAFAF6] border border-stone-200/80 space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-stone-800 text-[11px]">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    <span>7 Deterministic Safety Guardrails</span>
                  </div>
                  <p className="text-[10px] text-stone-500 leading-tight">
                    Hard gates enforce deadline buffers, holding temperatures, recipient NGO verification, and intake room.
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-[#FAFAF6] border border-stone-200/80 space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-stone-800 text-[11px]">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    <span>Strands Decider 2B & Amazon Bedrock</span>
                  </div>
                  <p className="text-[10px] text-stone-500 leading-tight">
                    Sub-5ms policy classification paired with generative natural-language dispatch synthesis.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="mt-12 pt-8 border-t border-stone-100 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-400">
            <span>Nexmeal • Surplus today. Sustenance tomorrow.</span>
            <span className="font-mono text-[11px] text-stone-400">
              Demo Notice: Test organizations and donation lots are fictional for simulation.
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
