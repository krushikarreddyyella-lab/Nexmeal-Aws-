/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Plus Jakarta Sans"', 'Inter', 'sans-serif'],
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      colors: {
        forest: {
          50: '#F0F9F5',
          100: '#E4F4EE',
          200: '#C2E5D7',
          300: '#94D0BC',
          400: '#5FB49B',
          500: '#28886C',
          600: '#1E6B54',
          700: '#164E3D',
          800: '#103B2D',
          900: '#0B261D',
          950: '#051510',
        },
        ivory: {
          50: '#FAFAF6',
          100: '#F5F4EC',
          200: '#EAE7DA',
          300: '#DEDAC9',
        },
        brand: {
          50: '#ecfdf5',
          100: '#d1fae5',
          200: '#a7f3d0',
          300: '#6ee7b7',
          400: '#34d399',
          500: '#10b981',
          600: '#059669',
          700: '#047857',
          800: '#065f46',
          900: '#064e3b',
        },
        accent: {
          50: '#fffbeb',
          100: '#fef3c7',
          200: '#fde68a',
          300: '#fcd34d',
          400: '#fbbf24',
          500: '#f59e0b',
          600: '#d97706',
          700: '#b45309',
          800: '#92400e',
        },
        citrus: {
          500: '#EA580C',
          600: '#C2410C',
        },
        warm: {
          50: '#fafaf6',
          100: '#f5f4ec',
          200: '#eae7da',
        },
        charcoal: '#17211C',
      },
      boxShadow: {
        'subtle': '0 1px 3px rgba(16, 59, 45, 0.05), 0 1px 2px rgba(16, 59, 45, 0.03)',
        'card': '0 4px 20px -2px rgba(16, 59, 45, 0.06), 0 2px 6px -1px rgba(16, 59, 45, 0.04)',
        'elevated': '0 14px 38px -4px rgba(16, 59, 45, 0.12), 0 4px 12px -2px rgba(16, 59, 45, 0.05)',
      },
      animation: {
        'fade-in': 'fadeIn 0.5s ease-out forwards',
        'slide-up': 'slideUp 0.5s ease-out forwards',
        'slide-down': 'slideDown 0.3s ease-out forwards',
        'scale-in': 'scaleIn 0.3s ease-out forwards',
        'pulse-glow': 'pulseGlow 2s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        slideDown: {
          '0%': { opacity: '0', transform: 'translateY(-10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        scaleIn: {
          '0%': { opacity: '0', transform: 'scale(0.96)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
        pulseGlow: {
          '0%, 100%': { opacity: '1', transform: 'scale(1)' },
          '50%': { opacity: '0.85', transform: 'scale(1.02)' },
        },
      },
      borderRadius: {
        'xl': '0.75rem',
        '2xl': '1rem',
        '3xl': '1.5rem',
      },
    },
  },
  plugins: [],
};
